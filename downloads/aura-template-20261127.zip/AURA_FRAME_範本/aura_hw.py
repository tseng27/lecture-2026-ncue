#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AURA FRAME 硬體偵測（只用 Python 標準函式庫）
偵測顯示卡／VRAM、系統記憶體、硬碟空間、作業系統，判斷各功能能不能在這台電腦上自架。

單獨執行：python aura_hw.py           → 在視窗印出報告
          python aura_hw.py --json    → 輸出 JSON
          python aura_hw.py --popup   → 不適合時跳出 Windows 提醒視窗
門檻可在 config/hardware.json 修改。
"""

import json
import os
import platform
import re
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
CFG_FILE = BASE_DIR / "config" / "hardware.json"

TOL = 0.6  # 標示 16GB 的卡／記憶體，系統常回報 15.6～15.9GB，給一點容差

# 預設門檻（GB）。min = 低於就不能用；rec = 建議值，低於會提醒「可用但會慢或不穩」
DEFAULT_RULES = {
    "features": [
        {"id": "image", "name": "文生圖／LoRA 風格／參考圖改圖（SD1.5）", "vram_min": 4, "vram_rec": 8, "ram_min": 8, "ram_rec": 16, "disk_min": 15, "nvidia": False},
        {"id": "photo", "name": "寫實攝影模型（Z-Image／Flux）", "vram_min": 12, "vram_rec": 16, "ram_min": 16, "ram_rec": 32, "disk_min": 30, "nvidia": True},
        {"id": "video", "name": "圖生影片／漫劇分鏡", "vram_min": 16, "vram_rec": 24, "ram_min": 32, "ram_rec": 64, "disk_min": 60, "nvidia": True},
        {"id": "talk", "name": "對嘴說話／角色參考影片", "vram_min": 16, "vram_rec": 24, "ram_min": 32, "ram_rec": 64, "disk_min": 80, "nvidia": True}
    ],
    "tips": [
        "只做圖片功能：SD1.5 模型 6–8GB VRAM 就能跑。",
        "降低解析度與影片秒數（例如 448×800、2–3 秒）。",
        "讓學校一台夠力的電腦當主機，其他電腦用區網模式從瀏覽器連進來（見安裝說明的「校內區網模式」）。",
        "租用雲端 GPU 架設 ComfyUI（需留意費用與學生資料）。"
    ]
}


def _run(cmd, timeout=8):
    try:
        flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=flags,
                           encoding="utf-8", errors="replace")
        return r.stdout if r.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def _gpus_nvidia_smi():
    exe = shutil.which("nvidia-smi")
    if not exe and os.name == "nt":
        p = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "nvidia-smi.exe"
        exe = str(p) if p.exists() else None
    if not exe:
        return []
    out = _run([exe, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
    gpus = []
    for line in out.splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 2 and parts[1].replace(".", "").isdigit():
            gpus.append({"name": parts[0], "vram_gb": round(float(parts[1]) / 1024, 1), "vendor": "nvidia", "source": "nvidia-smi"})
    return gpus


def _gpus_comfy(comfy_url):
    """ComfyUI 已啟動時，/system_stats 會回報它實際使用的顯示卡與 VRAM（最準）。"""
    if not comfy_url:
        return []
    try:
        with urllib.request.urlopen(comfy_url.rstrip("/") + "/system_stats", timeout=2) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception:
        return []
    gpus = []
    for d in data.get("devices", []):
        if d.get("type") in ("cpu",):
            continue
        name = re.sub(r"^cuda:\d+\s*", "", str(d.get("name", ""))).split(" : ")[0].strip() or str(d.get("type"))
        vendor = "nvidia" if "nvidia" in name.lower() or d.get("type") == "cuda" else ("apple" if d.get("type") == "mps" else "other")
        gpus.append({"name": name, "vram_gb": round((d.get("vram_total") or 0) / 1024 ** 3, 1), "vendor": vendor, "source": "ComfyUI"})
    return gpus


def _gpus_windows():
    # AdapterRAM 最多只能表示 4GB，所以改讀登錄檔的 qwMemorySize；讀不到就只回報名稱
    ps = ("$ErrorActionPreference='SilentlyContinue';"
          "Get-ItemProperty 'HKLM:\\SYSTEM\\ControlSet001\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}\\0*' |"
          " ForEach-Object { if ($_.DriverDesc) { $m=$_.'HardwareInformation.qwMemorySize'; if (-not $m) { $m=$_.'HardwareInformation.MemorySize' };"
          " if ($m -is [byte[]]) { $m=[BitConverter]::ToUInt32($m,0) }; '{0}|{1}' -f $_.DriverDesc,$m } }")
    out = _run(["powershell", "-NoProfile", "-Command", ps], timeout=12)
    gpus, seen = [], set()
    for line in out.splitlines():
        if "|" not in line:
            continue
        name, mem = line.rsplit("|", 1)
        name = name.strip()
        if not name or name in seen or re.search(r"basic display|remote|virtual|parsec|meta", name, re.I):
            continue
        seen.add(name)
        vram = round(int(mem) / 1024 ** 3, 1) if mem.strip().isdigit() and int(mem) > 0 else None
        low = name.lower()
        vendor = "nvidia" if "nvidia" in low else "amd" if ("amd" in low or "radeon" in low) else "intel" if "intel" in low else "other"
        gpus.append({"name": name, "vram_gb": vram, "vendor": vendor, "source": "Windows"})
    return gpus


def _gpus_mac():
    out = _run(["sysctl", "-n", "machdep.cpu.brand_string"])
    if "Apple" in out:
        return [{"name": out.strip() + "（統一記憶體）", "vram_gb": None, "vendor": "apple", "source": "macOS"}]
    return []


def _ram_gb():
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys / 1024 ** 3, 1)
        if sys.platform == "darwin":
            return round(int(_run(["sysctl", "-n", "hw.memsize"]).strip()) / 1024 ** 3, 1)
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return round(int(line.split()[1]) / 1024 ** 2, 1)
    except Exception:
        pass
    return None


def _disk(path):
    try:
        p = Path(path)
        while not p.exists() and p != p.parent:
            p = p.parent
        u = shutil.disk_usage(str(p))
        return {"path": str(p.anchor or p), "free_gb": round(u.free / 1024 ** 3, 1), "total_gb": round(u.total / 1024 ** 3, 1)}
    except OSError:
        return None


def load_rules():
    try:
        user = json.loads(CFG_FILE.read_text(encoding="utf-8-sig"))
        rules = dict(DEFAULT_RULES)
        rules.update({k: v for k, v in user.items() if k in ("features", "tips")})
        return rules
    except (OSError, ValueError):
        return DEFAULT_RULES


def detect(comfy_url=None, comfy_dir=None):
    gpus = _gpus_comfy(comfy_url) or _gpus_nvidia_smi()
    if not gpus:
        gpus = _gpus_windows() if os.name == "nt" else _gpus_mac() if sys.platform == "darwin" else []
    ram = _ram_gb()
    disk = _disk(comfy_dir or BASE_DIR)
    best = max(gpus, key=lambda g: (g.get("vendor") == "nvidia", g.get("vram_gb") or 0)) if gpus else None
    vram = best.get("vram_gb") if best else None
    is_nv = bool(best and best.get("vendor") == "nvidia")
    if best and best.get("vendor") == "apple" and ram:
        vram = round(ram * 0.65, 1)  # Apple 晶片和系統共用記憶體，約 2/3 可給 GPU

    rules = load_rules()
    feats = []
    for f in rules["features"]:
        level, why = "ok", []
        if best is None:
            level = "no"; why.append("沒有偵測到獨立顯示卡")
        else:
            if f.get("nvidia") and not is_nv:
                level = "no"; why.append("需要 NVIDIA 顯示卡（CUDA）")
            if vram is None:
                if level == "ok":
                    level = "unknown"; why.append("讀不到顯示卡記憶體大小，請手動確認")
            elif vram + TOL < f["vram_min"]:
                level = "no"; why.append(f"VRAM {vram:g}GB，至少要 {f['vram_min']}GB")
            elif vram + TOL < f["vram_rec"] and level == "ok":
                level = "slow"; why.append(f"VRAM {vram:g}GB，建議 {f['vram_rec']}GB 以上")
        if ram is not None:
            if ram + TOL < f["ram_min"]:
                level = "no" if level != "unknown" else level; why.append(f"記憶體 {ram:g}GB，至少要 {f['ram_min']}GB")
            elif ram + TOL < f["ram_rec"] and level == "ok":
                level = "slow"; why.append(f"記憶體 {ram:g}GB，建議 {f['ram_rec']}GB 以上")
        if disk and disk["free_gb"] < f.get("disk_min", 0):
            why.append(f"硬碟剩 {disk['free_gb']:g}GB，放模型需要約 {f['disk_min']}GB")
            if level == "ok":
                level = "slow"
        feats.append({"id": f["id"], "name": f["name"], "level": level, "reasons": why})

    levels = [f["level"] for f in feats]
    overall = "ok" if all(l == "ok" for l in levels) else ("no" if feats and feats[0]["level"] == "no" else "partial")
    return {
        "os": f"{platform.system()} {platform.release()}",
        "machine": platform.machine(),
        "gpus": gpus, "gpu": best, "vram_gb": vram, "ram_gb": ram, "disk": disk,
        "features": feats, "overall": overall, "tips": rules.get("tips", []),
    }


def summary_text(r):
    lv = {"ok": "✔ 可以", "slow": "△ 可以但會慢／不穩", "no": "✘ 不建議", "unknown": "？ 無法判斷"}
    g = r["gpu"]
    gtxt = "未偵測到"
    if g:
        gtxt = g["name"] + ("（%gGB）" % g["vram_gb"] if g.get("vram_gb") else "")
    lines = [
        f"作業系統：{r['os']}",
        f"顯示卡：{gtxt}",
        f"系統記憶體：{r['ram_gb']:g}GB" if r["ram_gb"] else "系統記憶體：讀不到",
        f"硬碟剩餘：{r['disk']['free_gb']:g}GB（{r['disk']['path']}）" if r["disk"] else "硬碟：讀不到",
        "",
    ]
    for f in r["features"]:
        lines.append(f"{lv[f['level']]}  {f['name']}" + (f"：{'；'.join(f['reasons'])}" if f["reasons"] else ""))
    return "\n".join(lines)


def popup(r):
    """硬體不適合時在 Windows 跳出提醒視窗（其他系統只印在終端機）。"""
    if r["overall"] == "ok":
        return
    title = "AURA FRAME：這台電腦的硬體提醒"
    head = "這台電腦可能無法執行 AURA 的 AI 功能。" if r["overall"] == "no" else "這台電腦只能使用部分功能。"
    body = head + "\n\n" + summary_text(r) + "\n\n建議：\n・" + "\n・".join(r["tips"])
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, body, title, 0x30 | 0x40000)  # 警告圖示＋最上層
            return
        except Exception:
            pass
    print(title + "\n" + body)


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    res = detect(os.environ.get("COMFY_URL", "http://127.0.0.1:8188"))
    if "--json" in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    elif "--popup" in sys.argv:
        popup(res)
    else:
        print(summary_text(res))
