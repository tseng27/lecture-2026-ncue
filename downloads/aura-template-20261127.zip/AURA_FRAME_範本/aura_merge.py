# -*- coding: utf-8 -*-
"""
分段對嘴：把多段 MP4 接成一支影片（含聲音）。
需要 PyAV（av）與 numpy。ComfyUI 免安裝版的 python_embeded 已內建，用「啟動AURA.bat」開啟時就能使用。
"""

from fractions import Fraction


_AVAILABLE = None


def available():
    global _AVAILABLE
    if _AVAILABLE is None:
        try:
            import av  # noqa: F401
            import numpy  # noqa: F401
            _AVAILABLE = True
        except ImportError:
            _AVAILABLE = False
    return _AVAILABLE


def _read_segment(path, keep_seconds):
    """讀一段影片（只取前 keep_seconds 秒）：回傳 (影格 list[ndarray HxWx3], fps, 音訊 ndarray[ch, n] 或 None, 取樣率)。"""
    import av
    import numpy as np
    frames, audio, sr = [], [], 48000
    with av.open(str(path)) as c:
        vs = c.streams.video[0]
        fps = vs.average_rate or vs.guessed_rate or Fraction(24)
        keep_frames = max(1, int(round(float(keep_seconds) * float(fps)))) if keep_seconds else None
        for f in c.decode(video=0):
            frames.append(f.to_ndarray(format="rgb24"))
            if keep_frames and len(frames) >= keep_frames:
                break
    with av.open(str(path)) as c:
        if c.streams.audio:
            rs = av.AudioResampler(format="fltp", layout="stereo", rate=sr)
            for f in c.decode(audio=0):
                for g in rs.resample(f):
                    audio.append(g.to_ndarray())
            for g in rs.resample(None):
                audio.append(g.to_ndarray())
    a = np.concatenate(audio, axis=1) if audio else None
    return frames, fps, a, sr


def merge(segments, out_path, transition=4):
    """segments: [(mp4 路徑, 要保留的秒數 或 None)]。transition: 段與段之間的淡入格數（0 = 直接切）。
    回傳 (總秒數, 影格數)。"""
    import av
    import numpy as np
    if not segments:
        raise ValueError("沒有可合併的片段")
    out = av.open(str(out_path), "w")
    vstream = astream = None
    fps = None
    total_frames = 0
    pcm = []
    prev_last = None
    try:
        for path, keep in segments:
            frames, sfps, a, sr = _read_segment(path, keep)
            if not frames:
                raise ValueError(f"讀不到影格：{path}")
            if vstream is None:
                fps = Fraction(sfps).limit_denominator(1001)
                h, w = frames[0].shape[:2]
                vstream = out.add_stream("libx264", rate=fps)
                vstream.width, vstream.height, vstream.pix_fmt = w - w % 2, h - h % 2, "yuv420p"
                vstream.options = {"crf": "18", "preset": "veryfast"}
                astream = out.add_stream("aac", rate=sr)
                astream.layout = "stereo"
            n = len(frames)
            for i, img in enumerate(frames):
                if img.shape[0] != vstream.height or img.shape[1] != vstream.width:
                    img = _fit(img, vstream.width, vstream.height)
                if prev_last is not None and i < transition:
                    t = (i + 1) / (transition + 1)
                    img = (prev_last.astype(np.float32) * (1 - t) + img.astype(np.float32) * t).astype(np.uint8)
                for p in vstream.encode(av.VideoFrame.from_ndarray(img, format="rgb24")):
                    out.mux(p)
            prev_last = frames[-1] if frames[-1].shape[:2] == (vstream.height, vstream.width) else _fit(frames[-1], vstream.width, vstream.height)
            total_frames += n
            # 每段的聲音剪成和影格一樣長，避免越接越不同步
            need = int(round(n / float(fps) * sr))
            seg = np.zeros((2, need), dtype=np.float32)
            if a is not None:
                m = min(need, a.shape[1])
                seg[:, :m] = a[:, :m]
            pcm.append(seg)
        for p in vstream.encode():
            out.mux(p)
        audio = np.concatenate(pcm, axis=1)
        step = 1024
        for i in range(0, audio.shape[1], step):
            f = av.AudioFrame.from_ndarray(np.ascontiguousarray(audio[:, i:i + step]), format="fltp", layout="stereo")
            f.sample_rate = astream.rate
            f.pts = i
            for p in astream.encode(f):
                out.mux(p)
        for p in astream.encode():
            out.mux(p)
    finally:
        out.close()
    return total_frames / float(fps), total_frames


def _fit(img, w, h):
    """尺寸不一致時，置中裁切或補黑邊成 w×h。"""
    import numpy as np
    canvas = np.zeros((h, w, 3), dtype=np.uint8)
    ih, iw = img.shape[:2]
    y0, x0 = max(0, (ih - h) // 2), max(0, (iw - w) // 2)
    crop = img[y0:y0 + h, x0:x0 + w]
    ch, cw = crop.shape[:2]
    canvas[(h - ch) // 2:(h - ch) // 2 + ch, (w - cw) // 2:(w - cw) // 2 + cw] = crop
    return canvas
