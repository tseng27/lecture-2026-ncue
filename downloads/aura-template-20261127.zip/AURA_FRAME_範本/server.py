#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AURA FRAME Local Server
本機 Python 標準函式庫伺服器，提供前端並同源代理到本機 ComfyUI (預設 http://127.0.0.1:8188)
不呼叫任何雲端生圖或影片 API。
"""

import http.server
import socketserver
import json
import os
import urllib.request
import urllib.parse
import urllib.error
import uuid
import argparse
import sys
import subprocess
import copy
import hmac
import random
import re
import sqlite3
import threading
import time
import socket
import base64
import struct
import mimetypes

# ComfyUI 的 python_embeded 不會自動把程式所在資料夾放進 sys.path，要自己加才找得到 aura_merge.py
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pathlib import Path
from datetime import datetime
import aura_hw  # 硬體偵測（標準函式庫）
HW_CACHE = None

# 設定
BASE_DIR = Path(__file__).parent.resolve()
STATIC_DIR = BASE_DIR / "static"
FLOWS_DIR = BASE_DIR / "flows"
FLOWS_DIR.mkdir(exist_ok=True)

COMFY_URL = os.environ.get("COMFY_URL", "http://127.0.0.1:8188").rstrip("/")
HOST = "127.0.0.1"
PORT = 8000
LORAS_DIR = None   # ComfyUI models/loras（--loras-dir 或自動偵測）
OUTPUT_DIR = None  # ComfyUI output 資料夾（--output-dir 或自動偵測）
ACCESS_CODE = None  # 若設定，則需要 ?code= 、Header X-Access-Code 或登入後的 Cookie
MAX_BODY = 25 * 1024 * 1024  # POST 上限 25MB（參考圖上傳）
LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")
SAFE_NAME_RE = re.compile(r"^[^/\\]+\.json$")
USER_RE = re.compile(r"[A-Za-z0-9-]{8,64}")
DB_PATH = BASE_DIR / "data" / "aura.db"
DB_LOCK = threading.Lock()
OUTPUT_KEYS = ("images", "gifs", "videos", "video", "audio")
AURA_CLIENT_ID = "aura-" + uuid.uuid4().hex[:12]  # 所有工作用同一個 client_id，才收得到 ComfyUI 的進度訊息
PROGRESS = {}        # prompt_id → {"value", "max", "node", "done", "total", "t"}
PROGRESS_LOCK = threading.Lock()
JOB_NODES = {}       # prompt_id → 工作流節點數（算整體進度用）
TEACHER_PIN = None   # config/teacher.json 的 pin；設定後老師模式需要密碼
LAN_MODE = False     # --host 非本機時為 True：每人同時只能排 1 件


def _code_ok(given):
    return bool(given) and ACCESS_CODE is not None and hmac.compare_digest(str(given), ACCESS_CODE)


def safe_flow_path(name):
    """只允許 flows/ 底層的 .json，防止路徑穿越。"""
    name = urllib.parse.unquote(name or "")
    if not SAFE_NAME_RE.match(name) or name.startswith("."):
        return None
    fp = (FLOWS_DIR / name).resolve()
    if fp.parent != FLOWS_DIR.resolve():
        return None
    return fp


def coerce(value, ftype):
    if ftype == "int":
        return int(float(value))
    if ftype == "float":
        return float(value)
    return value if isinstance(value, (int, float, bool)) else str(value)


def seconds_to_frames(sec, spec, values):
    """秒數 → 合法影格數。frame_rule=[base, step] 代表 base + step*k（MiniMax H3：5+17k；Wan：1+4k）。"""
    try:
        sec = float(sec)
    except (TypeError, ValueError):
        raise ValueError(f"「{spec.get('label', '秒數')}」需為數字")
    lo, hi = float(spec.get("min", 1)), float(spec.get("max", 8))
    if not (lo <= sec <= hi):
        raise ValueError(f"「{spec.get('label', '秒數')}」需介於 {lo:g}–{hi:g} 秒（16GB 顯卡建議上限）")
    try:
        fps = float(values.get("fps") or spec.get("fps", 24))
    except (TypeError, ValueError):
        fps = float(spec.get("fps", 24))
    base, step = (spec.get("frame_rule") or [1, 4])[:2]
    need = max(base, round(sec * fps))
    return int(base + step * -(-(need - base) // step))


def wav_seconds(data):
    import io, wave
    try:
        with wave.open(io.BytesIO(data)) as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return None


# 前端只能選這幾種（白名單），不接受任意 SSML 參數
VOICE_STYLES = {
    "cartoon_m": ("Zhiwei", "+30%", "0.95"),
    "natural_m": ("Zhiwei", "+0%", "1.0"),
    "female": ("Yating", "+10%", "1.0"),
    "kid": ("Hanhan", "+40%", "1.0"),
}

TTS_SCRIPT = BASE_DIR / "tools" / "tts_windows.ps1"


def synthesize_tts(text, voice="Zhiwei", pitch="+30%", rate="0.95"):
    """本機離線 TTS（Windows 內建 OneCore 中文語音，不連網）。回傳 wav bytes。"""
    import subprocess, tempfile, html
    if os.name != "nt" or not TTS_SCRIPT.is_file():
        raise RuntimeError("本機 TTS 只支援 Windows（內建中文語音）。請改用上傳音檔。")
    text = text.strip()
    if not text or len(text) > 200:
        raise ValueError("台詞需為 1–200 字")
    ssml = ("<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='zh-TW'>"
            f"<prosody pitch='{pitch}' rate='{rate}'>{html.escape(text)}</prosody></speak>")
    with tempfile.TemporaryDirectory() as td:
        sp, op = Path(td) / "line.ssml", Path(td) / "line.wav"
        sp.write_text(ssml, encoding="utf-8")
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(TTS_SCRIPT),
                            "-Ssml", str(sp), "-Out", str(op), "-Voice", voice],
                           capture_output=True, timeout=60)
        if not op.is_file() or op.stat().st_size < 1000:
            raise RuntimeError("TTS 失敗：" + r.stdout.decode("utf-8", "ignore")[-300:] + r.stderr.decode("utf-8", "ignore")[-300:])
        return op.read_bytes()


def _load_cfg(name, default):
    try:
        return json.loads((BASE_DIR / "config" / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


_LORA_META_CACHE = {}


def lora_base_meta(rel):
    """讀 safetensors 標頭的底模資訊（只讀前幾 KB，不載入權重）。"""
    if LORAS_DIR is None:
        return ""
    p = (LORAS_DIR / rel)
    try:
        st = p.stat()
    except OSError:
        return ""
    key = (str(p), st.st_mtime)
    if key in _LORA_META_CACHE:
        return _LORA_META_CACHE[key]
    val = ""
    try:
        with open(p, "rb") as fh:
            n = int.from_bytes(fh.read(8), "little")
            if 0 < n < 50_000_000:
                hdr = json.loads(fh.read(n).decode("utf-8", "ignore"))
                md = hdr.get("__metadata__") or {}
                val = " ".join(str(md.get(k, "")) for k in ("ss_base_model_version", "modelspec.architecture", "ss_sd_model_name", "ss_v2"))
                if not val.strip():
                    keys = " ".join(list(hdr.keys())[:200])
                    if "double_blocks" in keys or "single_blocks" in keys:
                        val = "flux"
                    elif "lora_te2_" in keys or "lora_unet_input_blocks_7_1_transformer_blocks_9" in keys:
                        val = "sdxl"
                    elif "transformer_blocks" in keys and "lora_unet_" not in keys:
                        val = "dit"
    except (OSError, ValueError):
        pass
    _LORA_META_CACHE[key] = val.lower()
    return val.lower()


def _st_header(p):
    try:
        with open(p, "rb") as fh:
            n = int.from_bytes(fh.read(8), "little")
            if 0 < n < 100_000_000:
                return json.loads(fh.read(n).decode("utf-8", "ignore"))
    except (OSError, ValueError):
        pass
    return {}


_FAM_CACHE = {}


def model_family(path, kind):
    """回傳 sd15 / sdxl / sd2 / flux1 / flux2 / zimage / other（只讀 safetensors 標頭）。"""
    name = Path(path).name.lower()
    try:
        key = (str(path), Path(path).stat().st_mtime)
    except OSError:
        key = None
    if key in _FAM_CACHE:
        return _FAM_CACHE[key]
    fam = ""
    if re.search(r"minimax|(^|[_-])h3[_-]|qwen|hunyuan|wan2|ltx|lightning", name):
        fam = "other"
    elif re.search(r"flux[_-]?2|klein", name):
        fam = "flux2"
    elif re.search(r"z[-_]?image|zimage", name):
        fam = "zimage"
    hdr = _st_header(path) if not fam and str(path).lower().endswith(".safetensors") else {}
    if not fam and hdr:
        md = hdr.get("__metadata__") or {}
        meta = " ".join(str(md.get(k, "")) for k in ("ss_base_model_version", "modelspec.architecture", "ss_sd_model_name")).lower()
        keys = [k for k in hdr if k != "__metadata__"]
        ks = " ".join(keys[:4000])
        if "flux" in meta or "double_blocks" in ks or "single_blocks" in ks:
            fam = "flux1"
        elif "lumina" in meta or "z-image" in meta or "zimage" in meta:
            fam = "zimage"
        elif "xl" in meta or "conditioner.embedders.1" in ks or "lora_te2_" in ks:
            fam = "sdxl"
        elif "sd_v2" in meta or "v2-" in meta or "cond_stage_model.model." in ks:
            fam = "sd2"
        elif "sd_v1" in meta or "v1-" in meta or "cond_stage_model.transformer" in ks or "lora_unet_" in ks or "lora_te_" in ks:
            fam = "sd15"
        elif re.search(r"(^|\.)layers\.\d+\.(attention|adaln|feed_forward)", ks, re.I) or "context_refiner" in ks or "noise_refiner" in ks:
            fam = "zimage"
        elif "transformer_blocks" in ks:
            fam = "other"
    if not fam:
        fam = "sd15" if kind == "ckpt" else "unknown"
    if key:
        _FAM_CACHE[key] = fam
    return fam


def lora_display_name(rel, names):
    stem = re.split(r"[\\/]", rel)[-1].rsplit(".", 1)[0]
    if names.get(stem):
        return names[stem]
    t = re.sub(r"(?i)(^|[_\- ])(lora|lycoris|locon)(?=$|[_\- .])", " ", stem)
    for _ in range(3):
        t = re.sub(r"(?i)[_\- ]*v\d+(\.\d+)*\b|[_\- ]*\d{4,}\b|[_\- ]*(final|ema|bf16|fp16|fp32)\b|[_\- ]+s\d+\b", "", t)
    t = re.sub(r"[_\-.]+", " ", t).strip()
    return " ".join(w.capitalize() if w.islower() else w for w in t.split()) or stem


def load_lora_info():
    """讀 flows/lora_info.json（另一個安裝工具維護，AURA 只讀不寫）。容忍多種格式。"""
    try:
        raw = json.loads((FLOWS_DIR / "lora_info.json").read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}
    items = raw.get("loras", raw.get("styles", raw)) if isinstance(raw, dict) else raw
    if isinstance(items, dict):
        items = [dict(v, _key=k) if isinstance(v, dict) else {"_key": k, "label": str(v)} for k, v in items.items() if not k.startswith("_")]
    out = {}
    for it in items if isinstance(items, list) else []:
        if not isinstance(it, dict):
            continue
        key = it.get("file") or it.get("filename") or it.get("lora") or it.get("lora_name") or it.get("_key") or it.get("id") or ""
        stem = re.split(r"[\\/]", str(key))[-1].rsplit(".safetensors", 1)[0]
        if not stem:
            continue
        label = next((it[k] for k in ("zh", "name_zh", "zh_name", "chinese", "label", "display", "title", "name") if it.get(k)), "")
        trig = next((it[k] for k in ("trigger", "triggers", "trigger_words", "trigger_word", "keywords") if it.get(k)), "")
        if isinstance(trig, list):
            trig = ", ".join(map(str, trig))
        out[stem.lower()] = {"label": str(label), "trigger": str(trig), "strength": it.get("strength") or it.get("weight")}
    return out


def filter_loras(all_loras):
    cfg = _load_cfg("lora_filter.json", {})
    names = _load_cfg("lora_names.json", {})
    linfo = load_lora_info()
    allow = set(cfg.get("allow", []))
    pats = [re.compile(p, re.I) for p in cfg.get("hide_patterns", ["elara"])]
    bases = [b.lower() for b in cfg.get("hide_bases", [])]
    out = []
    for rel in all_loras:
        stem = re.split(r"[\\/]", rel)[-1].rsplit(".", 1)[0]
        if re.search("elara", rel, re.I):  # 一律不顯示（白名單也不例外）
            continue
        if rel not in allow and stem not in allow and any(p.search(rel) for p in pats):
            continue
        fam = model_family((LORAS_DIR / rel) if LORAS_DIR is not None else Path(rel), "lora")
        if fam in bases and rel not in allow and stem not in allow:
            continue
        li = linfo.get(stem.lower(), {})
        item = {"name": rel, "family": fam, "label": li.get("label") or lora_display_name(rel, names), "preview": find_lora_preview(rel) is not None,
                "trigger": li.get("trigger", ""), "featured": bool(re.search(r"(^|[\\/])aura_styles[\\/]", rel, re.I))}
        if isinstance(li.get("strength"), (int, float)):
            item["strength"] = li["strength"]
        out.append(item)
    out.sort(key=lambda x: (not x["featured"], x["label"].lower()))
    return out


def find_lora_preview(rel):
    stem_rel = rel.rsplit(".", 1)[0]
    stem = re.split(r"[\\/]", stem_rel)[-1]
    cands = []
    if LORAS_DIR is not None:
        cands += [LORAS_DIR / (stem_rel + e) for e in (".preview.png", ".png", ".jpg", ".jpeg", ".webp")]
    cands += [BASE_DIR / "previews" / (stem + e) for e in (".png", ".jpg", ".webp")]
    for c in cands:
        try:
            if c.is_file():
                return c
        except OSError:
            pass
    return None


MODEL_INFO_DEFAULT = {
    "default": "dreamshaper_8.safetensors",
    "hide_patterns": ["elara", "inpaint", "refiner", "pix2pix", "instruct"],
    "names": {}, "order": [], "sizes": {}, "photo": {}, "photo_suffix": "", "safety_negative": "", "blocked_words": []}


def load_model_info():
    d = dict(MODEL_INFO_DEFAULT)
    try:
        d.update(json.loads((FLOWS_DIR / "model_info.json").read_text(encoding="utf-8-sig")))
    except (OSError, ValueError) as e:
        print("model_info.json 讀取失敗，用預設值:", e)
    return d


def pick_available(cands, available):
    for c in cands or []:
        if c in available:
            return c
    return None


def list_main_models(info, comps):
    """學生可選的主模型卡片：SD 檢查點 + 本機可用的寫實攝影家族。"""
    mi = load_model_info()
    pats = [re.compile(p, re.I) for p in mi.get("hide_patterns", [])]
    ckdir = OUTPUT_DIR.parent / "models" / "checkpoints" if OUTPUT_DIR is not None else None
    out = []
    for c in comps.get("checkpoints", []):
        if re.search("elara", c, re.I) or any(p.search(c) for p in pats):
            continue
        fam = model_family((ckdir / c) if ckdir is not None else Path(c), "ckpt")
        if fam not in ("sd15", "sdxl"):
            continue
        stem = re.split(r"[\\/]", c)[-1].rsplit(".", 1)[0]
        out.append({"id": c, "family": fam, "kind": "ckpt", "tag": "SDXL" if fam == "sdxl" else "SD1.5",
                    "group": "插畫·藝術風格", "label": mi.get("names", {}).get(c) or mi.get("names", {}).get(stem) or lora_display_name(c, {}),
                    "preview": find_model_preview(c) is not None})
    for fid, spec in (mi.get("photo") or {}).items():
        if spec.get("disabled"):
            continue
        ok = pick_available(spec.get("unet"), comps.get("unet", [])) and pick_available(spec.get("vae"), comps.get("vae", []))
        clips = spec.get("clip") or []
        ok = ok and (all(c in comps.get("clip", []) for c in clips) if spec.get("dual") else pick_available(clips, comps.get("clip", [])))
        if ok:
            pid = "photo:" + fid
            out.append({"id": pid, "family": spec.get("family", fid), "kind": "photo", "tag": spec.get("tag", fid), "group": "寫實攝影",
                        "label": spec.get("label", fid), "preview": find_model_preview(pid) is not None})
    order = mi.get("order") or []
    show = mi.get("show") or []
    if show:
        out = [m for m in out if m["id"] in show or m["id"].rsplit(".", 1)[0] in show]
    for m in out:
        if m["kind"] == "ckpt" and (m["id"] in mi.get("photo_ckpts", []) or m["id"].rsplit(".", 1)[0] in mi.get("photo_ckpts", [])):
            m["group"] = "寫實攝影"
    out.sort(key=lambda m: (order.index(m["id"]) if m["id"] in order else len(order), m["kind"] != "photo", m["label"].lower()))
    return out, mi


def find_model_preview(mid):
    stem = re.sub(r"[^\w.-]+", "_", mid.replace("photo:", "photo_")).rsplit(".safetensors", 1)[0]
    cands = [BASE_DIR / "previews" / f"model_{stem}{e}" for e in (".png", ".jpg", ".webp")]
    if not mid.startswith("photo:") and OUTPUT_DIR is not None:
        base = OUTPUT_DIR.parent / "models" / "checkpoints" / mid.rsplit(".", 1)[0]
        cands = [Path(str(base) + e) for e in (".preview.png", ".png", ".jpg")] + cands
    for c in cands:
        try:
            if c.is_file():
                return c
        except OSError:
            pass
    return None


def build_photo_flow(fid, kind, comps, mi):
    """寫實攝影家族（Z-Image / Flux）：在伺服器端組出 API 工作流，學生看到的仍是同一個創作方式。"""
    sp = mi["photo"][fid]
    fam = sp.get("family", fid)
    unet = pick_available(sp["unet"], comps["unet"])
    vae = pick_available(sp["vae"], comps["vae"])
    p = {"1": {"class_type": "UNETLoader", "inputs": {"unet_name": unet, "weight_dtype": sp.get("weight_dtype", "default")}},
         "3": {"class_type": "VAELoader", "inputs": {"vae_name": vae}}}
    if sp.get("dual"):
        p["2"] = {"class_type": "DualCLIPLoader", "inputs": {"clip_name1": sp["clip"][0], "clip_name2": sp["clip"][1], "type": sp.get("clip_type", "flux")}}
    else:
        p["2"] = {"class_type": "CLIPLoader", "inputs": {"clip_name": pick_available(sp["clip"], comps["clip"]), "type": sp.get("clip_type", "lumina2")}}
    model = ["1", 0]
    m = {"positive": "4.inputs.text", "negative": "5.inputs.text", "seed": "9.inputs.seed", "steps": "9.inputs.steps", "cfg": "9.inputs.cfg"}
    if kind == "lora":
        p["20"] = {"class_type": "LoraLoaderModelOnly", "inputs": {"model": model, "lora_name": "", "strength_model": 0.8}}
        model = ["20", 0]
        m["lora"] = "20.inputs.lora_name"; m["lora_strength"] = "20.inputs.strength_model"
    if fam == "zimage":
        p["7"] = {"class_type": "ModelSamplingAuraFlow", "inputs": {"model": model, "shift": float(sp.get("shift", 3))}}
        model = ["7", 0]
    p["4"] = {"class_type": "CLIPTextEncode", "inputs": {"text": "", "clip": ["2", 0]}}
    p["5"] = {"class_type": "CLIPTextEncode", "inputs": {"text": "", "clip": ["2", 0]}}
    pos = ["4", 0]
    if fam == "flux1":
        p["6"] = {"class_type": "FluxGuidance", "inputs": {"conditioning": pos, "guidance": float(sp.get("guidance", 3.5))}}
        pos = ["6", 0]
    if kind == "img2img":
        p["11"] = {"class_type": "LoadImage", "inputs": {"image": ""}}
        p["12"] = {"class_type": "ImageScaleToTotalPixels", "inputs": {"image": ["11", 0], "upscale_method": "lanczos", "megapixels": float(sp.get("img2img_megapixels", 1.0)), "resolution_steps": 1}}  # resolution_steps：新版 ComfyUI 必填，舊版會忽略
        p["8"] = {"class_type": "VAEEncode", "inputs": {"pixels": ["12", 0], "vae": ["3", 0]}}
        m["image"] = "11.inputs.image"; m["denoise"] = "9.inputs.denoise"
    else:
        p["8"] = {"class_type": "EmptySD3LatentImage", "inputs": {"width": 1024, "height": 1024, "batch_size": 1}}
        m["width"] = "8.inputs.width"; m["height"] = "8.inputs.height"
    p["9"] = {"class_type": "KSampler", "inputs": {"seed": 0, "steps": int(sp.get("steps", 8)), "cfg": float(sp.get("cfg", 1)), "sampler_name": sp.get("sampler", "euler"),
                                                  "scheduler": sp.get("scheduler", "simple"), "denoise": 1.0, "model": model, "positive": pos, "negative": ["5", 0], "latent_image": ["8", 0]}}
    p["10"] = {"class_type": "VAEDecode", "inputs": {"samples": ["9", 0], "vae": ["3", 0]}}
    p["13"] = {"class_type": "SaveImage", "inputs": {"filename_prefix": "AuraFrame_Photo", "images": ["10", 0]}}
    return p, m, sp


_MJ_FLAG = re.compile(r"(?:^|\s)--(?:ar|aspect|v|version|style|stylize|s|q|quality|chaos|c|niji|seed|no|iw|sref|cref|tile|raw|weird|w|p|personalize|r|repeat|stop|hd|test|testp|uplight|upbeta)\b(?:\s+(?!--)[^\s,]+)?", re.I)


def strip_mj_flags(text):
    """移除 Midjourney 類指令（--ar 16:9、--v 6 …），比例請用介面按鈕。"""
    t = _MJ_FLAG.sub(" ", text)
    t = re.sub(r"(?:^|\s)--[a-z]+\b", " ", t, flags=re.I)
    return re.sub(r"\s{2,}", " ", t).strip(" ,")


def apply_sd_quality(workflow, mapping, mi, mode):
    """SD 檢查點：dpmpp_2m karras；精細 = 兩階段放大（hires fix）。"""
    q = mi.get("sd_quality", {})
    seed_t = mapping.get("seed")
    ks_id = (seed_t if isinstance(seed_t, str) else seed_t[0]).split(".")[0]
    ks = workflow[ks_id]["inputs"]
    ks["sampler_name"], ks["scheduler"] = q.get("sampler", "dpmpp_2m"), q.get("scheduler", "karras")
    if not mode.get("hires"):
        return
    dec = next((k for k, n in workflow.items() if n.get("class_type") == "VAEDecode" and n["inputs"].get("samples") == [ks_id, 0]), None)
    if not dec:
        return
    workflow["90"] = {"class_type": "LatentUpscaleBy", "inputs": {"samples": [ks_id, 0], "upscale_method": q.get("hires_method", "bislerp"), "scale_by": float(q.get("hires_scale", 1.75))}}
    k2 = dict(ks); k2.update(latent_image=["90", 0], denoise=float(q.get("hires_denoise", 0.5)), steps=int(q.get("hires_steps", 15)))
    workflow["91"] = {"class_type": "KSampler", "inputs": k2}
    workflow[dec]["inputs"]["samples"] = ["91", 0]


def detect_output_dir():
    """自動找 ComfyUI 的 output 資料夾。"""
    here = Path(__file__).resolve().parent
    cands = [Path(r"D:\ComfyUI_windows_portable\ComfyUI\output"), Path(r"C:\ComfyUI_windows_portable\ComfyUI\output"),
             Path(r"E:\ComfyUI_windows_portable\ComfyUI\output"), here.parent / "ComfyUI_windows_portable" / "ComfyUI" / "output",
             here.parent / "ComfyUI" / "output", Path.home() / "ComfyUI" / "output"]
    for c in cands:
        try:
            if c.is_dir():
                return c.resolve()
        except OSError:
            pass
    return None


# ---------- 自動啟動本機 ComfyUI ----------
COMFY_PATH_FILE = BASE_DIR / "config" / "comfy_path.txt"
COMFY_PROC = None     # 由 AURA 啟動的 ComfyUI 行程（AURA 結束時一併關閉）
COMFY_STATE = {"phase": "unknown", "dir": None, "message": ""}  # phase: unknown/running/starting/not_found/failed/disabled


def _comfy_layout(p):
    """判斷資料夾是否為 ComfyUI；回傳 (工作目錄, 指令列表, ComfyUI 主資料夾) 或 None。
    支援：Windows 免安裝版（含 python_embeded）、git clone 版（venv/.venv 或系統 Python）。"""
    try:
        p = Path(p).expanduser().resolve()
    except (OSError, RuntimeError):
        return None
    if p.is_file():
        p = p.parent
    exe = "python.exe" if os.name == "nt" else "python"
    # 免安裝版根目錄：python_embeded + ComfyUI/main.py；或使用者指到內層 ComfyUI 資料夾
    for root in (p, p.parent):
        emb = root / "python_embeded" / exe
        if emb.is_file() and (root / "ComfyUI" / "main.py").is_file():
            return root, [str(emb), "-s", str(Path("ComfyUI") / "main.py"), "--windows-standalone-build"], root / "ComfyUI"
    if (p / "main.py").is_file() and (p / "comfy").is_dir():
        for venv in ("venv", ".venv"):
            py = p / venv / ("Scripts" if os.name == "nt" else "bin") / exe
            if py.is_file():
                return p, [str(py), "main.py"], p
        return p, [sys.executable, "main.py"], p
    return None


def find_comfy_dir(explicit=None):
    """依序找：--comfy-dir、環境變數 COMFY_DIR、config/comfy_path.txt、AURA 旁邊、各磁碟常見位置、使用者資料夾。"""
    cands = []
    if explicit:
        cands.append(Path(explicit))
    if os.environ.get("COMFY_DIR"):
        cands.append(Path(os.environ["COMFY_DIR"]))
    try:
        line = next((l.strip().strip('"') for l in COMFY_PATH_FILE.read_text(encoding="utf-8-sig").splitlines()
                     if l.strip() and not l.strip().startswith("#")), "")
        if line:
            cands.append(Path(line))
    except OSError:
        pass
    bases = [BASE_DIR, BASE_DIR.parent]
    if os.name == "nt":
        for d in "CDEFGH":
            root = Path(f"{d}:\\")
            bases += [root, root / "AI"]
    home = Path.home()
    bases += [home, home / "Desktop", home / "Documents", home / "Downloads"]
    for b in bases:
        try:
            if not b.is_dir():
                continue
            cands += sorted(c for c in b.glob("ComfyUI*") if c.is_dir())
        except OSError:
            pass
    seen = set()
    for c in cands:
        key = str(c).lower()
        if key in seen:
            continue
        seen.add(key)
        lay = _comfy_layout(c)
        if lay:
            return lay
    return None


def comfy_alive(timeout=2):
    try:
        with urllib.request.urlopen(COMFY_URL + "/system_stats", timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def start_comfy(layout, wait=600):
    """在背景啟動 ComfyUI，並等到可以連線（第一次啟動、載入節點可能需要數分鐘）。"""
    global COMFY_PROC
    import time
    cwd, cmd, main_dir = layout
    port = urllib.parse.urlparse(COMFY_URL).port or 8188
    cmd = cmd + ["--listen", "127.0.0.1", "--port", str(port)]
    COMFY_STATE.update(phase="starting", dir=str(main_dir), message="ComfyUI 啟動中，第一次需要 1–3 分鐘…")
    print(f"正在啟動 ComfyUI：{cwd}")
    try:
        if os.name == "nt":
            # 開在獨立視窗，老師可看到 ComfyUI 的訊息
            COMFY_PROC = subprocess.Popen(cmd, cwd=str(cwd), creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            log = open(BASE_DIR / "comfyui.log", "ab")
            COMFY_PROC = subprocess.Popen(cmd, cwd=str(cwd), stdout=log, stderr=subprocess.STDOUT)
    except OSError as e:
        COMFY_STATE.update(phase="failed", message=f"ComfyUI 無法啟動：{e}")
        print(COMFY_STATE["message"])
        return
    t0 = time.time()
    while time.time() - t0 < wait:
        if COMFY_PROC.poll() is not None:
            COMFY_STATE.update(phase="failed", message="ComfyUI 啟動後就結束了，請看 ComfyUI 視窗的錯誤訊息")
            print(COMFY_STATE["message"])
            return
        if comfy_alive():
            COMFY_STATE.update(phase="running", message="")
            print(f"ComfyUI 已就緒（{int(time.time() - t0)} 秒）")
            return
        time.sleep(2)
    COMFY_STATE.update(phase="failed", message="ComfyUI 等了 10 分鐘仍未就緒，請看 ComfyUI 視窗")
    print(COMFY_STATE["message"])


def stop_comfy():
    if COMFY_PROC is not None and COMFY_PROC.poll() is None:
        print("正在關閉 ComfyUI…")
        COMFY_PROC.terminate()
        try:
            COMFY_PROC.wait(timeout=15)
        except Exception:
            COMFY_PROC.kill()


def apply_av_options(workflow, flow_data, values, frames):
    """依「聲音」開關與背景音樂調整影片工作流的音軌。"""
    av = flow_data.get("av")
    if not av:
        return
    out_node, sound_src = av["video_node"], av["sound_source"]
    sound_on = str(values.get("sound", True)).lower() not in ("false", "0", "off", "no")
    music = values.get("music")
    src = list(sound_src) if sound_on else None
    if music:
        if not isinstance(music, str) or not re.fullmatch(r"[\w\-. /\u4e00-\u9fff]{1,200}", music) or ".." in music:
            raise ValueError("音樂檔名不合法")
        try:
            vol = max(-40, min(6, int(values.get("music_volume", -10))))
        except (TypeError, ValueError):
            vol = -10
        workflow["50"] = {"class_type": "LoadAudio", "inputs": {"audio": music}}
        workflow["51"] = {"class_type": "TrimAudioDuration", "inputs": {"audio": ["50", 0], "start_index": 0.0,
                                                                     "duration": round((frames or 73) / float(values.get("fps", 24) or 24), 3)}}
        workflow["52"] = {"class_type": "AudioAdjustVolume", "inputs": {"audio": ["51", 0], "volume": vol}}
        if src:
            workflow["53"] = {"class_type": "AudioMerge", "inputs": {"audio1": src, "audio2": ["52", 0], "merge_method": "add"}}
            src = ["53", 0]
        else:
            src = ["52", 0]
    if src:
        workflow[out_node]["inputs"]["audio"] = src
    else:
        workflow[out_node]["inputs"].pop("audio", None)


def audio_segment(values, spec):
    """分段對嘴：回傳 (start, dur) 或 None。dur 會限制在秒數欄位的範圍內。"""
    if values.get("audio_dur") in (None, ""):
        return None
    try:
        start, dur = float(values.get("audio_start") or 0), float(values["audio_dur"])
    except (TypeError, ValueError):
        raise ValueError("分段時間格式錯誤")
    if start < 0 or start > 3600 or not (0.3 <= dur <= float(spec.get("max", 8)) + 0.01):
        raise ValueError(f"每段音檔需介於 0.3–{float(spec.get('max', 8)):g} 秒")
    return round(start, 3), round(dur, 3)


def apply_audio_trim(workflow, mapping, seg):
    """在 LoadAudio 後面插入 TrimAudioDuration，讓這次只用整段音檔的其中一段。"""
    if not seg or not isinstance(mapping.get("audio"), str):
        return
    nid = mapping["audio"].split(".", 1)[0]
    trim_id = "60"
    while trim_id in workflow:
        trim_id = str(int(trim_id) + 1)
    for node in workflow.values():
        for k, v in node.get("inputs", {}).items():
            if v == [nid, 0]:
                node["inputs"][k] = [trim_id, 0]
    workflow[trim_id] = {"class_type": "TrimAudioDuration", "inputs": {"audio": [nid, 0], "start_index": seg[0], "duration": seg[1]}}


# ---------- Pika H3 Flex（MiniMax H3 的 6 步蒸餾 LoRA）／首尾幀／角色參考 ----------
# 官方工作流：UNET → LoraLoaderModelOnly(1.0) → BasicGuider，lcm 取樣器 + ManualSigmas，6 步、cfg 1。
PIKA_SIGMAS = "1.0, 0.972973, 0.923077, 0.8, 0.571429, 0.333333, 0.0"
PIKA_LORAS = {"fl2va": ("pika_h3_flex_fl2va_v1_bf16.safetensors", "pika_h3_flex_fl2va_comfy_bf16.safetensors"),
              "ref2va": ("pika_h3_flex_ref2va_v1_bf16.safetensors", "pika_h3_flex_ref2va_comfy_bf16.safetensors")}


def _choices(info, cls, inp):
    node = (info or {}).get(cls) or {}
    for sect in ("required", "optional"):
        try:
            v = node["input"][sect][inp][0]
            if isinstance(v, list):
                return v
        except (KeyError, IndexError, TypeError):
            pass
    return []


def find_pika_lora(kind, loras):
    base = {l.replace("\\", "/").split("/")[-1].lower(): l for l in loras}
    for c in PIKA_LORAS[kind]:
        if c in base:
            return base[c]
    return next((l for l in loras if "pika" in l.lower() and kind in l.lower()), None)


def h3_caps(info):
    """這台 ComfyUI 有沒有 Pika LoRA、ref2va 主模型、首尾幀與角色參考節點。"""
    loras = _choices(info, "LoraLoaderModelOnly", "lora_name") or _choices(info, "LoraLoader", "lora_name")
    unets = _choices(info, "UNETLoader", "unet_name")
    i2v = ((info or {}).get("MiniMaxH3ImageToVideo") or {}).get("input") or {}
    has = lambda c: c in (info or {})
    ref_unet = next((u for u in unets if "ref2va" in u.lower()), None)
    caps = {
        "lora_fl2va": find_pika_lora("fl2va", loras),
        "lora_ref2va": find_pika_lora("ref2va", loras),
        "ref2va_unet": ref_unet,
        "last_frame": "last_frame" in (i2v.get("optional") or {}) or "last_frame" in (i2v.get("required") or {}),
        "manual_sigmas": has("ManualSigmas") and has("SamplerCustomAdvanced") and has("LoraLoaderModelOnly"),
        "ref_node": has("MiniMaxH3ReferenceToVideo"),
    }
    caps["pika"] = bool(caps["lora_fl2va"] and caps["manual_sigmas"])
    caps["ref_ready"] = bool(caps["lora_ref2va"] and ref_unet and caps["ref_node"] and caps["manual_sigmas"])
    return caps


def _new_id(wf, start):
    i = start
    while str(i) in wf:
        i += 1
    return str(i)


def _rewire(wf, old, new):
    for n in wf.values():
        for k, v in n.get("inputs", {}).items():
            if isinstance(v, list) and len(v) == 2 and v[0] == old[0] and v[1] == old[1]:
                n["inputs"][k] = list(new)


def prune_unused(wf):
    """刪掉輸出節點用不到的節點（例如換成 Pika 後不再需要的 SigmaShift、負向提示）。"""
    outs = [k for k, n in wf.items() if str(n.get("class_type", "")).startswith(("Save", "Preview"))]
    keep, stack = set(), list(outs)
    while stack:
        k = stack.pop()
        if k in keep or k not in wf:
            continue
        keep.add(k)
        for v in wf[k].get("inputs", {}).values():
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str):
                stack.append(v[0])
    for k in list(wf):
        if k not in keep:
            del wf[k]


def apply_pika_flex(wf, lora):
    """把 MiniMax H3 影片工作流換成 Pika H3 Flex 取樣（LoRA + lcm + ManualSigmas）。"""
    unet = next((k for k, n in wf.items() if n.get("class_type") == "UNETLoader"), None)
    if not unet:
        raise ValueError("工作流裡找不到 UNETLoader，無法套用 Pika")
    L = _new_id(wf, 70)
    wf[L] = {"class_type": "LoraLoaderModelOnly", "inputs": {"model": [unet, 0], "lora_name": lora, "strength_model": 1.0}}
    M = _new_id(wf, 71)
    wf[M] = {"class_type": "ManualSigmas", "inputs": {"sigmas": PIKA_SIGMAS}}
    ks = next((k for k, n in wf.items() if n.get("class_type") == "KSampler"), None)
    if ks:
        k = wf[ks]["inputs"]
        N = _new_id(wf, 72); wf[N] = {"class_type": "RandomNoise", "inputs": {"noise_seed": k.get("seed", 0)}}
        G = _new_id(wf, 73); wf[G] = {"class_type": "BasicGuider", "inputs": {"model": [L, 0], "conditioning": k["positive"]}}
        S = _new_id(wf, 74); wf[S] = {"class_type": "KSamplerSelect", "inputs": {"sampler_name": "lcm"}}
        A = _new_id(wf, 75); wf[A] = {"class_type": "SamplerCustomAdvanced", "inputs": {
            "noise": [N, 0], "guider": [G, 0], "sampler": [S, 0], "sigmas": [M, 0], "latent_image": k["latent_image"]}}
        _rewire(wf, [ks, 0], [A, 0])
        del wf[ks]
    else:
        adv = next((k for k, n in wf.items() if n.get("class_type") == "SamplerCustomAdvanced"), None)
        if not adv:
            raise ValueError("工作流裡找不到取樣節點，無法套用 Pika")
        a = wf[adv]["inputs"]
        a["sigmas"] = [M, 0]
        wf[a["guider"][0]]["inputs"]["model"] = [L, 0]
        wf[a["sampler"][0]] = {"class_type": "KSamplerSelect", "inputs": {"sampler_name": "lcm"}}
    prune_unused(wf)


def apply_last_frame(wf, image):
    """首尾幀：把結尾圖接到 MiniMaxH3ImageToVideo 的 last_frame（跟起始圖用一樣的裁切）。"""
    i2v = next((k for k, n in wf.items() if n.get("class_type") == "MiniMaxH3ImageToVideo"), None)
    if not i2v:
        raise ValueError("這個工作流不支援結尾畫面")
    li = _new_id(wf, 80)
    wf[li] = {"class_type": "LoadImage", "inputs": {"image": image}}
    first = wf[i2v]["inputs"].get("first_frame")
    src = [li, 0]
    if isinstance(first, list) and wf.get(first[0], {}).get("class_type") == "ImageScale":
        sc = _new_id(wf, 81)
        wf[sc] = copy.deepcopy(wf[first[0]])
        wf[sc]["inputs"]["image"] = [li, 0]
        src = [sc, 0]
    wf[i2v]["inputs"]["last_frame"] = src


def drop_empty_images(wf, mapping, fields, values):
    """選填的圖片欄位（optional: true）沒上傳時，連同引用它的輸入一起拿掉。"""
    for field, spec in (fields or {}).items():
        if spec.get("type") != "image" or not spec.get("optional") or values.get(field):
            continue
        t = mapping.get(field)
        nid = (t if isinstance(t, str) else (t or [""])[0]).split(".", 1)[0]
        if nid not in wf:
            continue
        del wf[nid]
        for n in wf.values():
            for k in [k for k, v in n.get("inputs", {}).items() if isinstance(v, list) and len(v) == 2 and v[0] == nid]:
                del n["inputs"][k]
    # Autogrow 的參考圖要從 0 開始連號（ref_image_0、ref_image_1…）
    for n in wf.values():
        refs = sorted(k for k in n.get("inputs", {}) if k.startswith("ref_images.ref_image_"))
        if refs:
            vals = [n["inputs"].pop(k) for k in refs]
            for i, v in enumerate(vals):
                n["inputs"][f"ref_images.ref_image_{i}"] = v


_OBJ_INFO = {"t": 0, "info": None}


def h3_missing_text(caps, what):
    need = []
    if not caps["manual_sigmas"] or (what == "ref2v" and not caps["ref_node"]):
        need.append("更新 ComfyUI 到最新版")
    if what == "pika" and not caps["lora_fl2va"]:
        need.append("models/loras/pika_h3_flex_fl2va_v1_bf16.safetensors")
    if what == "ref2v":
        if not caps["ref2va_unet"]:
            need.append("models/diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors")
        if not caps["lora_ref2va"]:
            need.append("models/loras/pika_h3_flex_ref2va_v1_bf16.safetensors")
    return "這台電腦還沒裝好 Pika H3 Flex：" + "、".join(need or ["請檢查模型"]) + "。請老師依「安裝說明」下載後重新啟動 ComfyUI。"


def apply_mapping(prompt, mapping, fields, values):
    """把 values 依 mapping 寫入工作流（深拷貝）。回傳 (workflow, used_seed)。
    mapping 值可為 "節點ID.inputs.欄位" 或其列表（一個值寫入多處）。"""
    workflow = copy.deepcopy(prompt)
    used_seed = None
    for field, targets in mapping.items():
        spec = fields.get(field) or {}
        ftype = spec.get("type", "text")
        if field in values and values[field] not in (None, ""):
            v = values[field]
        elif "default" in spec:
            v = spec["default"]
        else:
            if spec.get("required") and ftype not in ("ckpt", "lora"):
                raise ValueError(f"欄位「{spec.get('label', field)}」為必填")
            continue  # 未提供 → 保留工作流原本的值
        if ftype == "seconds":
            v = seconds_to_frames(v, spec, values)
        elif ftype in ("int", "float") or field == "seed":
            try:
                v = coerce(v, "int" if field == "seed" else ftype)
            except (TypeError, ValueError):
                raise ValueError(f"欄位 {field} 需為數字")
        if field == "seed":
            if v < 0:
                v = random.randint(0, 2**48)
            used_seed = v
        if isinstance(targets, str):
            targets = [targets]
        for target in targets:
            node_id, rest = target.split(".", 1)
            if node_id not in workflow:
                raise ValueError(f"對應錯誤：節點 {node_id} 不存在於工作流中（欄位 {field}）")
            keys = rest.split(".")
            obj = workflow[node_id]
            for k in keys[:-1]:
                obj = obj[k]
            obj[keys[-1]] = v
    return workflow, used_seed


# ---------- 看得懂的錯誤訊息 ----------
def friendly_error(msg):
    m = str(msg or "")
    low = m.lower()
    if "out of memory" in low or "outofmemory" in low or "allocation on device" in low:
        return "顯示卡記憶體不足。請改用「標準」畫質、較短的秒數或較小的比例；如果其他人也在生成，等他們完成再試。"
    if "interrupt" in low:
        return "已取消。"
    if "value_not_in_list" in low or "not in list" in low:
        f = re.search(r"([\w.\-]+\.(?:safetensors|ckpt|pt|pth|gguf))", m)
        return f"這台電腦缺少需要的模型檔{('：' + f.group(1)) if f else ''}。請老師確認模型已經放進 ComfyUI 的 models 資料夾。"
    if "invalid image file" in low or "cannot identify image" in low:
        return "圖片讀不出來，請換一張 jpg 或 png 再試。"
    if "node does not exist" in low or ("class_type" in low and "not found" in low):
        return "這台 ComfyUI 少了需要的自訂節點，請老師確認 custom_nodes 是否完整。"
    return m[:300] if m else "ComfyUI 執行失敗"


def comfy_error_text(entry):
    st = (entry or {}).get("status") or {}
    for kind, data in st.get("messages", []) or []:
        if kind == "execution_interrupted":
            return "interrupted"
        if kind == "execution_error":
            return f"{data.get('node_type', '')}：{data.get('exception_message', '')}".strip("：")
    return ""


# ---------- ComfyUI 即時進度（WebSocket，純標準函式庫） ----------
def _ws_recv_exact(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("websocket closed")
        buf += chunk
    return buf


def _ws_send(sock, opcode, payload=b""):
    mask = os.urandom(4)
    head = bytes([0x80 | opcode])
    n = len(payload)
    if n < 126:
        head += bytes([0x80 | n])
    elif n < 65536:
        head += bytes([0x80 | 126]) + struct.pack("!H", n)
    else:
        head += bytes([0x80 | 127]) + struct.pack("!Q", n)
    sock.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))


def _ws_messages(sock):
    """逐一產生文字訊息（略過預覽圖等二進位訊息）。"""
    parts, kind = [], None
    while True:
        b0, b1 = _ws_recv_exact(sock, 2)
        op, n = b0 & 0x0F, b1 & 0x7F
        if n == 126:
            n = struct.unpack("!H", _ws_recv_exact(sock, 2))[0]
        elif n == 127:
            n = struct.unpack("!Q", _ws_recv_exact(sock, 8))[0]
        mask = _ws_recv_exact(sock, 4) if b1 & 0x80 else None
        data = _ws_recv_exact(sock, n) if n else b""
        if mask:
            data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        if op == 8:
            raise ConnectionError("websocket closed")
        if op == 9:
            _ws_send(sock, 10, data)
            continue
        if op in (1, 2):
            kind, parts = op, [data]
        elif op == 0:
            parts.append(data)
        else:
            continue
        if b0 & 0x80:
            if kind == 1:
                yield b"".join(parts).decode("utf-8", "replace")
            parts = []


def _on_comfy_event(msg):
    t, d = msg.get("type"), msg.get("data") or {}
    pid = d.get("prompt_id")
    if not pid:
        return
    with PROGRESS_LOCK:
        p = PROGRESS.setdefault(pid, {"value": 0, "max": 0, "node": None, "done": 0, "total": JOB_NODES.get(pid, 0), "t": time.time()})
        p["t"] = time.time()
        if t == "execution_cached":
            p["done"] += len(d.get("nodes") or [])
        elif t == "executing":
            if d.get("node") is None:
                p["finished"] = True
            else:
                if p.get("node") is not None:
                    p["done"] += 1
                p["node"], p["value"], p["max"] = d.get("node"), 0, 0
        elif t == "progress":
            p["value"], p["max"] = int(d.get("value") or 0), int(d.get("max") or 0)
            p["node"] = d.get("node") or p.get("node")
        elif t in ("execution_error", "execution_interrupted", "execution_success"):
            p["finished"] = True
        if len(PROGRESS) > 200:  # 清掉一小時前的舊紀錄
            for k in [k for k, v in PROGRESS.items() if time.time() - v["t"] > 3600]:
                PROGRESS.pop(k, None)
                JOB_NODES.pop(k, None)


def comfy_ws_loop():
    """背景執行緒：連 ComfyUI 的 /ws 收進度；斷線就每 3 秒重連。"""
    u = urllib.parse.urlparse(COMFY_URL)
    while True:
        sock = None
        try:
            sock = socket.create_connection((u.hostname, u.port or 80), timeout=10)
            key = base64.b64encode(os.urandom(16)).decode()
            path = (u.path.rstrip("/") or "") + "/ws?clientId=" + AURA_CLIENT_ID
            sock.sendall((f"GET {path} HTTP/1.1\r\nHost: {u.hostname}:{u.port or 80}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                          f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
            head = b""
            while b"\r\n\r\n" not in head:
                chunk = sock.recv(1)
                if not chunk:
                    raise ConnectionError("no handshake")
                head += chunk
            if b" 101 " not in head.split(b"\r\n", 1)[0]:
                raise ConnectionError("handshake refused")
            sock.settimeout(None)
            for text in _ws_messages(sock):
                try:
                    _on_comfy_event(json.loads(text))
                except (ValueError, TypeError, AttributeError):
                    pass
        except (OSError, ConnectionError, ValueError):
            pass
        finally:
            if sock:
                try:
                    sock.close()
                except OSError:
                    pass
        time.sleep(3)


def teacher_token():
    return hmac.new(TEACHER_PIN.encode("utf-8"), b"aura-teacher", "sha256").hexdigest() if TEACHER_PIN else ""


# ---------- 作品庫（SQLite，存在 data/aura.db；作品檔案本身仍在 ComfyUI output） ----------
def db_connect():
    DB_PATH.parent.mkdir(exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with DB_LOCK, db_connect() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt_id TEXT UNIQUE NOT NULL,
            created REAL NOT NULL,
            user TEXT NOT NULL DEFAULT '',
            flow TEXT NOT NULL DEFAULT '',
            flow_name TEXT NOT NULL DEFAULT '',
            icon TEXT NOT NULL DEFAULT '',
            main_model TEXT NOT NULL DEFAULT '',
            values_json TEXT NOT NULL DEFAULT '{}',
            seed INTEGER,
            status TEXT NOT NULL DEFAULT 'pending',
            outputs_json TEXT NOT NULL DEFAULT '[]',
            error TEXT NOT NULL DEFAULT '',
            starred INTEGER NOT NULL DEFAULT 0,
            hidden INTEGER NOT NULL DEFAULT 0)""")
        con.execute("CREATE INDEX IF NOT EXISTS jobs_user ON jobs(user, id)")
        con.execute("""CREATE TABLE IF NOT EXISTS series (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created REAL NOT NULL,
            user TEXT NOT NULL DEFAULT '',
            job_ids TEXT NOT NULL,
            durs TEXT NOT NULL,
            transition INTEGER NOT NULL DEFAULT 4,
            status TEXT NOT NULL DEFAULT 'waiting',
            error TEXT NOT NULL DEFAULT '',
            gallery_id INTEGER)""")
        if "title" not in {r[1] for r in con.execute("PRAGMA table_info(series)")}:
            con.execute("ALTER TABLE series ADD COLUMN title TEXT NOT NULL DEFAULT ''")  # 舊資料庫升級：漫劇分鏡用的作品名稱


def record_job(prompt_id, user, flow, flow_data, values, seed):
    keep = {k: v for k, v in values.items() if isinstance(v, (str, int, float, bool)) and k != "teacher"}
    try:
        with DB_LOCK, db_connect() as con:
            cur = con.execute(
                "INSERT OR IGNORE INTO jobs(prompt_id, created, user, flow, flow_name, icon, main_model, values_json, seed) VALUES (?,?,?,?,?,?,?,?,?)",
                (prompt_id, time.time(), user, flow, str(flow_data.get("name") or flow), str(flow_data.get("icon") or ""),
                 str(values.get("main_model") or ""), json.dumps(keep, ensure_ascii=False), seed if isinstance(seed, int) else None))
            return cur.lastrowid
    except sqlite3.Error as e:
        sys.stderr.write(f"作品庫寫入失敗: {e}\n")
        return None


def collect_outputs(outputs):
    out = []
    for node in (outputs or {}).values():
        for key in OUTPUT_KEYS:
            for it in node.get(key) or []:
                if isinstance(it, dict) and it.get("filename") and it.get("type") != "temp":
                    out.append({"filename": it["filename"], "subfolder": it.get("subfolder", ""), "type": it.get("type", "output")})
    return out


def finalize_job(prompt_id, entry):
    """依 ComfyUI history 的一筆紀錄更新作品庫；entry 為 None 表示還沒完成。"""
    if not entry:
        return
    st = entry.get("status") or {}
    if st.get("status_str") == "error":
        raw = comfy_error_text(entry)
        status, outs, err = ("cancelled" if raw == "interrupted" else "error"), [], friendly_error(raw)
    elif st.get("completed") is False:
        return
    else:
        outs = collect_outputs(entry.get("outputs"))
        status, err = ("done", "") if outs else ("empty", "")
    try:
        with DB_LOCK, db_connect() as con:
            con.execute("UPDATE jobs SET status=?, outputs_json=?, error=? WHERE prompt_id=? AND status='pending'",
                        (status, json.dumps(outs, ensure_ascii=False), err[:500], prompt_id))
    except sqlite3.Error as e:
        sys.stderr.write(f"作品庫更新失敗: {e}\n")


def merge_series(sid):
    """背景執行：把各段影片接起來，存到 output/aura_series，並記進作品庫。"""
    import aura_merge
    ids = []
    try:
        with db_connect() as con:
            sr = con.execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
            ids, durs = json.loads(sr["job_ids"]), json.loads(sr["durs"])
            jobs = {r["id"]: r for r in con.execute(f"SELECT * FROM jobs WHERE id IN ({','.join('?' * len(ids))})", ids)}
        segs = []
        for jid, dur in zip(ids, durs):
            outs = json.loads(jobs[jid]["outputs_json"])
            vid = next((o for o in outs if o["filename"].lower().endswith((".mp4", ".webm", ".mov", ".mkv"))), None)
            if not vid:
                raise ValueError("有一段沒有影片檔")
            path = (OUTPUT_DIR / vid.get("subfolder", "") / vid["filename"]).resolve()
            if OUTPUT_DIR not in path.parents or not path.is_file():
                raise ValueError(f"找不到片段檔案：{vid['filename']}")
            segs.append((path, float(dur) if dur else None))
        out_dir = OUTPUT_DIR / "aura_series"
        out_dir.mkdir(exist_ok=True)
        fname = f"AURA_Series_{sid:05d}_{datetime.now():%Y%m%d_%H%M%S}.mp4"
        aura_merge.merge(segs, out_dir / fname, int(sr["transition"]))
        first = jobs[ids[0]]
        vals = json.loads(first["values_json"] or "{}")
        vals.pop("audio_start", None); vals.pop("audio_dur", None)
        with DB_LOCK, db_connect() as con:
            cur = con.execute(
                "INSERT INTO jobs(prompt_id, created, user, flow, flow_name, icon, main_model, values_json, seed, status, outputs_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (f"series-{sid}", time.time(), sr["user"], first["flow"], (f"{sr['title']}（{len(ids)} 格分鏡）" if sr["title"] else f"分段對嘴（{len(ids)} 段合成）"), first["icon"], first["main_model"],
                 json.dumps(vals, ensure_ascii=False), first["seed"], "done",
                 json.dumps([{"filename": fname, "subfolder": "aura_series", "type": "output"}], ensure_ascii=False)))
            con.execute("UPDATE series SET status='done', gallery_id=? WHERE id=?", (cur.lastrowid, sid))
    except Exception as e:  # noqa: BLE001 背景執行緒：錯誤寫回資料庫給前端顯示
        sys.stderr.write(f"分段合併失敗 #{sid}: {e}\n")
        with DB_LOCK, db_connect() as con:
            con.execute("UPDATE series SET status='error', error=? WHERE id=?", (str(e)[:500], sid))
            con.execute(f"UPDATE jobs SET hidden=0 WHERE id IN ({','.join('?' * len(ids))})", ids)  # 合併失敗：至少讓各段看得到


def job_row(r):
    v = json.loads(r["values_json"] or "{}")
    return {"id": r["id"], "prompt_id": r["prompt_id"], "created": r["created"], "flow": r["flow"], "flow_name": r["flow_name"],
            "icon": r["icon"], "main_model": r["main_model"], "seed": r["seed"], "status": r["status"], "starred": bool(r["starred"]),
            "text": v.get("positive") or v.get("speech_text") or "", "values": v, "outputs": json.loads(r["outputs_json"] or "[]"),
            "mine": False}


class AURAHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # 簡潔日誌
        sys.stderr.write("%s - %s\n" % (self.address_string(), format % args))

    def _check_access(self):
        if ACCESS_CODE is None:
            return True
        # 檢查 query 或 header
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        if _code_ok(qs.get("code", [None])[0]):
            self._set_cookie = True
            return True
        if _code_ok(self.headers.get("X-Access-Code")):
            return True
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "aura_code" and _code_ok(urllib.parse.unquote(v)):
                return True
        return False

    def end_headers(self):
        if getattr(self, "_set_cookie", False):
            self._set_cookie = False
            self.send_header("Set-Cookie", "aura_code=%s; Path=/; HttpOnly; SameSite=Strict"
                             % urllib.parse.quote(ACCESS_CODE))
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()

    def _send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_error_json(self, message, status=400):
        self._send_json({"error": message}, status)

    def _proxy_to_comfy(self, method, path, body=None, headers=None, timeout=30):
        url = COMFY_URL + path
        req = urllib.request.Request(url, data=body, method=method)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                content_type = resp.headers.get("Content-Type", "application/octet-stream")
                return resp.status, content_type, data
        except urllib.error.HTTPError as e:
            return e.code, e.headers.get("Content-Type", "text/plain"), e.read()
        except Exception as e:
            raise RuntimeError(f"無法連線本機 ComfyUI ({COMFY_URL}): {e}")

    def _is_teacher(self):
        """有設老師密碼：要先登入；沒設：維持舊行為（誰都可以開老師模式）。"""
        if not TEACHER_PIN:
            return True
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "aura_teacher" and hmac.compare_digest(v, teacher_token()):
                return True
        return False

    def _user(self):
        u = self.headers.get("X-Aura-User") or ""
        return u if USER_RE.fullmatch(u) else ""

    def do_OPTIONS(self):
        # 前端與 API 同源，不開放跨網域
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        if not self._check_access():
            self._send_error_json("需要課堂存取碼", 403)
            return

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        qs = urllib.parse.parse_qs(parsed.query)

        if path == "/api/status":
            self.handle_status()
        elif path == "/api/hardware":
            self.handle_hardware(qs)
        elif path == "/api/flows":
            self.handle_list_flows()
        elif path == "/api/models":
            self.handle_models()
        elif path == "/api/presets":
            self.handle_presets()
        elif path.startswith("/api/history/"):
            prompt_id = path.split("/")[-1]
            if not re.fullmatch(r"[A-Za-z0-9-]{1,64}", prompt_id):
                self._send_error_json("prompt_id 格式錯誤")
                return
            self.handle_history(prompt_id)
        elif path == "/api/gallery":
            self.handle_gallery(qs)
        elif path == "/api/teacher":
            self._send_json({"pin_required": bool(TEACHER_PIN), "is_teacher": bool(TEACHER_PIN) and self._is_teacher()})
        elif re.fullmatch(r"/api/progress/[A-Za-z0-9-]{1,64}", path):
            self.handle_progress(path.rsplit("/", 1)[1])
        elif re.fullmatch(r"/api/series/\d{1,9}", path):
            self.handle_series_status(int(path.rsplit("/", 1)[1]))
        elif path == "/api/model-preview":
            self.handle_model_preview(qs)
        elif path == "/api/lora-preview":
            self.handle_lora_preview(qs)
        elif path == "/api/view":
            self.handle_view(qs)
        elif path.startswith("/api/flows/") and path.endswith(".json"):
            # 取得單一 flow
            name = path.split("/")[-1]
            self.handle_get_flow(name)
        else:
            # 靜態檔案
            self.serve_static(path)

    def do_POST(self):
        if not self._check_access():
            self._send_error_json("需要課堂存取碼", 403)
            return

        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        try:
            content_length = int(self.headers.get("Content-Length", 0))
        except ValueError:
            content_length = 0
        if content_length > MAX_BODY:
            self._send_error_json("上傳內容過大（上限 25MB）", 413)
            return
        body = self.rfile.read(content_length) if content_length else b""

        if path == "/api/flows":
            if not self._is_teacher():
                self._send_error_json("匯入或修改工作流需要老師模式（請先輸入老師密碼）", 403)
                return
            self.handle_import_flow(body)
        elif path == "/api/generate":
            self.handle_generate(body)
        elif path == "/api/upload":
            self.handle_upload(body)
        elif path == "/api/open-output":
            self.handle_open_output(body)
        elif path == "/api/gallery/update":
            self.handle_gallery_update(body)
        elif path == "/api/series":
            self.handle_series_create(body)
        elif path == "/api/cancel":
            self.handle_cancel(body)
        elif path == "/api/teacher":
            self.handle_teacher_login(body)
        else:
            self._send_error_json("未知的 API", 404)

    def serve_static(self, path):
        if path == "/" or path == "":
            path = "/index.html"
        file_path = (STATIC_DIR / urllib.parse.unquote(path).lstrip("/")).resolve()
        if STATIC_DIR not in file_path.parents or not file_path.is_file():
            self.send_error(404, "File not found")
            return
        # 簡單 MIME
        ext = file_path.suffix.lower()
        mime = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".json": "application/json",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".svg": "image/svg+xml",
            ".ico": "image/x-icon",
        }.get(ext, "application/octet-stream")
        try:
            data = file_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            if ext in (".html", ".js", ".css"):
                self.send_header("Cache-Control", "no-cache")  # 每次都向伺服器確認，更新後不會卡在舊版
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self.send_error(500, str(e))

    def _object_info(self, max_age=30):
        if _OBJ_INFO["info"] is None or time.time() - _OBJ_INFO["t"] > max_age:
            st, _, d = self._proxy_to_comfy("GET", "/object_info")
            if st != 200:
                raise ValueError("無法取得 ComfyUI 節點資訊")
            _OBJ_INFO.update(t=time.time(), info=json.loads(d.decode("utf-8")))
        return _OBJ_INFO["info"]

    def _components(self, info=None):
        if info is None:
            st, _, d = self._proxy_to_comfy("GET", "/object_info")
            info = json.loads(d.decode("utf-8"))

        def ch(cls, inp):
            try:
                v = info[cls]["input"]["required"][inp][0]
                return v if isinstance(v, list) else []
            except Exception:
                return []
        return {"checkpoints": ch("CheckpointLoaderSimple", "ckpt_name"), "unet": ch("UNETLoader", "unet_name"),
                "clip": ch("CLIPLoader", "clip_name"), "vae": ch("VAELoader", "vae_name")}

    def handle_model_preview(self, qs):
        name = (qs.get("id") or [""])[0]
        p = find_model_preview(name) if name and ".." not in name and len(name) < 300 else None
        if p is None:
            self._send_error_json("沒有預覽圖", 404)
            return
        data = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "image/png" if p.suffix.lower() == ".png" else "image/jpeg")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=300")
        self.end_headers()
        self.wfile.write(data)

    def handle_lora_preview(self, qs):
        name = (qs.get("name") or [""])[0]
        if not name or ".." in name or len(name) > 300:
            self._send_error_json("名稱不合法")
            return
        p = find_lora_preview(name)
        if p is None:
            self._send_error_json("沒有預覽圖", 404)
            return
        data = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", {".png": "image/png", ".webp": "image/webp"}.get(p.suffix.lower(), "image/jpeg"))
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=300")
        self.end_headers()
        self.wfile.write(data)

    def _is_local_client(self):
        return self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")

    def handle_open_output(self, body):
        """在伺服器電腦上用檔案總管開啟作品資料夾（只允許本機使用者）。"""
        if not self._is_local_client():
            self._send_error_json("「開啟作品資料夾」只能在這台電腦本機使用；其他電腦請用每個作品的「下載」。", 403)
            return
        if self.headers.get("X-Aura-Action") != "open-output":  # 擋跨站請求（自訂標頭需 CORS 預檢）
            self._send_error_json("請從 AURA FRAME 頁面操作", 403)
            return
        if OUTPUT_DIR is None or not OUTPUT_DIR.is_dir():
            self._send_error_json("找不到 ComfyUI 作品資料夾，請用 --output-dir 指定", 404)
            return
        if os.name != "nt":
            self._send_error_json("只支援 Windows 檔案總管", 400)
            return
        try:
            req = json.loads(body.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            req = {}
        fn, sub = req.get("filename"), req.get("subfolder") or ""
        try:
            if fn:
                target = (OUTPUT_DIR / sub / fn).resolve()
                if OUTPUT_DIR not in target.parents or not target.is_file():
                    self._send_error_json("檔案不在作品資料夾內", 400)
                    return
                subprocess.Popen(["explorer", "/select,", str(target)])
            else:
                os.startfile(str(OUTPUT_DIR))
        except OSError as e:
            self._send_error_json(f"無法開啟資料夾: {e}", 500)
            return
        self._send_json({"ok": True, "path": str(OUTPUT_DIR)})

    def handle_hardware(self, qs):
        """硬體偵測結果（偵測一次後快取；ComfyUI 啟動後會以它回報的 VRAM 為準）。"""
        global HW_CACHE
        fresh = qs.get("refresh", ["0"])[0] == "1"
        if HW_CACHE is None or fresh or (HW_CACHE.get("gpu") or {}).get("source") != "ComfyUI" and comfy_alive(1):
            try:
                HW_CACHE = aura_hw.detect(COMFY_URL if comfy_alive(1) else None, COMFY_STATE.get("dir"))
            except Exception as e:
                self._send_json({"ok": False, "error": f"硬體偵測失敗：{e}"}, 500)
                return
        self._send_json({"ok": True, **HW_CACHE, "local_client": self._is_local_client()})

    def handle_status(self):
        try:
            status, ctype, data = self._proxy_to_comfy("GET", "/queue")
            if status == 200:
                queue = json.loads(data.decode("utf-8"))
                remaining = len(queue.get("queue_running", [])) + len(queue.get("queue_pending", []))
                self._send_json({
                    "ok": True,
                    "comfy_url": COMFY_URL,
                    "queue_remaining": remaining,
                    "running": [q[1] for q in queue.get("queue_running", []) if len(q) > 1],
                    "pending": [q[1] for q in sorted(queue.get("queue_pending", []), key=lambda q: q[0]) if len(q) > 1],
                    "local_client": self._is_local_client(),
                    "can_open_folder": self._is_local_client() and os.name == "nt" and OUTPUT_DIR is not None,
                    "can_merge": OUTPUT_DIR is not None and __import__("aura_merge").available(),
                    "teacher_pin": bool(TEACHER_PIN),
                    "is_teacher": bool(TEACHER_PIN) and self._is_teacher(),
                    "lan_mode": LAN_MODE,
                    "message": "本機 ComfyUI 連線正常"
                })
            else:
                self._send_json({"ok": False, "error": "ComfyUI 回應異常", "status": status}, 502)
        except Exception as e:
            msg = COMFY_STATE["message"] if COMFY_STATE["phase"] in ("starting", "not_found", "failed") else str(e)
            self._send_json({"ok": False, "error": msg, "phase": COMFY_STATE["phase"]}, 503)

    def handle_list_flows(self):
        flows = []
        for f in sorted(p for p in FLOWS_DIR.glob("*.json") if not p.name.lower().startswith(("lora_", "model_"))):
            try:
                meta = json.loads(f.read_text(encoding="utf-8"))
                flows.append({
                    "name": meta.get("name") or f.stem,
                    "filename": f.name,
                    "description": meta.get("description", ""),
                    "preset": bool(meta.get("preset")),
                    "order": meta.get("order", 999),
                    "nodes": len(meta.get("prompt", {})),
                    "has_mapping": bool(meta.get("mapping")),
                    "mapping": meta.get("mapping", {}),
                    "fields": meta.get("fields", {}),
                    "output": meta.get("output", "image"),
                    "icon": meta.get("icon", ""),
                    "tts": bool(meta.get("tts")),
                    "requires": meta.get("requires", []),
                    "imported_at": meta.get("imported_at", "")
                })
            except:
                flows.append({"name": f.stem, "filename": f.name, "error": "無法解析"})
        flows.sort(key=lambda x: (x.get("order", 999), x["filename"]))
        self._send_json({"flows": flows})

    def handle_presets(self):
        """同 /api/flows，但只回傳已完成 mapping、可直接生成的工作流。"""
        flows = []
        for f in sorted(p for p in FLOWS_DIR.glob("*.json") if not p.name.lower().startswith(("lora_", "model_"))):
            try:
                meta = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            if meta.get("prompt") and meta.get("mapping"):
                flows.append({"name": meta.get("name") or f.stem, "filename": f.name,
                              "description": meta.get("description", ""),
                              "preset": bool(meta.get("preset")), "order": meta.get("order", 999),
                              "mapping": meta["mapping"], "fields": meta.get("fields", {})})
        flows.sort(key=lambda x: (x["order"], x["filename"]))
        self._send_json({"flows": flows})

    def handle_get_flow(self, name):
        fp = safe_flow_path(name)
        if not fp or not fp.is_file():
            self._send_error_json("工作流不存在", 404)
            return
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            self._send_json(data)
        except Exception as e:
            self._send_error_json(f"讀取失敗: {e}", 500)

    def handle_import_flow(self, body):
        try:
            payload = json.loads(body.decode("utf-8"))
            # 預期 { "name": "xxx", "prompt": {node_id: {...}}, "mapping": {...} 可選 }
            if "prompt" not in payload:
                self._send_error_json("缺少 prompt 欄位（ComfyUI API 格式工作流）")
                return
            name = payload.get("name") or f"flow_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            name = "".join(c for c in name if c.isalnum() or c in "._- ")[:80]
            if not name:
                name = "unnamed"
            filename = f"{name}.json"
            data = {
                "name": str(payload.get("title") or name)[:80],
                "order": payload.get("order", 999),
                "preset": bool(payload.get("preset", False)),
                "prompt": payload["prompt"],
                "mapping": payload.get("mapping", {}),
                "fields": payload.get("fields", {}),
                "description": str(payload.get("description", ""))[:300],
                "imported_at": datetime.now().isoformat()
            }
            fp = FLOWS_DIR / filename
            fp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            self._send_json({"ok": True, "filename": filename, "name": name})
        except json.JSONDecodeError:
            self._send_error_json("無效的 JSON")
        except Exception as e:
            self._send_error_json(str(e), 500)

    def handle_models(self):
        try:
            # 取得 object_info 以了解可用模型相關節點
            status, ctype, data = self._proxy_to_comfy("GET", "/object_info")
            if status != 200:
                self._send_error_json("無法取得 ComfyUI object_info", 502)
                return
            info = json.loads(data.decode("utf-8"))
            models = {
                "checkpoints": [],
                "loras": [],
                "vae": [],
                "upscale": [],
                "controlnets": [],
                "embeddings": []
            }
            # 簡單抽取常見模型資料夾（實際可依 object_info 更精準，但這裡提供基礎）
            # 使用者可從 object_info 自行查看
            for node_class, node_data in info.items():
                if "Checkpoint" in node_class or "ckpt" in node_class.lower():
                    # 嘗試找 models 清單
                    pass
            # 更好的方式：呼叫 /models/ 系列
            def _choices(cls, inp):
                try:
                    v = info[cls]["input"]["required"][inp][0]
                    return v if isinstance(v, list) else []
                except Exception:
                    return []
            models["checkpoints"] = _choices("CheckpointLoaderSimple", "ckpt_name")
            models["loras"] = _choices("LoraLoader", "lora_name")
            all_loras = list(models["loras"])
            for folder, key in [("checkpoints", "checkpoints"), ("loras", "loras"),
                                ("vae", "vae"), ("upscale_models", "upscale"),
                                ("controlnet", "controlnets")]:
                try:
                    st, _, d = self._proxy_to_comfy("GET", f"/models/{folder}")
                    if st == 200 and not models[key]:
                        lst = json.loads(d.decode("utf-8"))
                        if isinstance(lst, list):
                            models[key] = lst
                except:
                    pass
            # embeddings
            try:
                st, _, d = self._proxy_to_comfy("GET", "/embeddings")
                if st == 200:
                    models["embeddings"] = json.loads(d.decode("utf-8"))
            except:
                pass
            try:
                info_l = filter_loras(models["loras"] or all_loras)
            except re.error as e:
                info_l = [{"name": n, "label": n, "preview": False} for n in models["loras"] if "elara" not in n.lower()]
                print("lora_filter.json 規則錯誤:", e)
            models["loras"] = [x["name"] for x in info_l]
            models["lora_info"] = info_l
            try:
                comps = self._components(info)
                mm, mi = list_main_models(info, comps)
                models["main_models"] = mm
                models["main_default"] = mi.get("default")
                models["sizes"] = mi.get("sizes", {})
            except Exception as e:  # 不影響其他功能
                print("main_models 失敗:", e)
            try:
                _OBJ_INFO.update(t=time.time(), info=info)
                models["h3"] = h3_caps(info)
            except Exception as e:
                print("h3_caps 失敗:", e)
            self._send_json({"models": models, "note": "模型清單來自本機 ComfyUI。內建工作流已預先對應；若你的節點不同，可修改 flows/ 內的 mapping。"})
        except Exception as e:
            self._send_json({"error": str(e), "models": {}}, 503)

    def handle_generate(self, body):
        try:
            payload = json.loads(body.decode("utf-8"))
            filename = payload.get("flow")
            values = payload.get("values", {})  # { "positive": "...", "negative": "...", "seed": 123, "ckpt": "xxx.safetensors", ... }
            if not filename:
                self._send_error_json("缺少 flow 檔名")
                return
            fp = safe_flow_path(filename)
            if not fp or not fp.is_file():
                self._send_error_json("工作流不存在，請先匯入", 404)
                return
            flow_data = json.loads(fp.read_text(encoding="utf-8"))
            prompt = flow_data.get("prompt")
            mapping = flow_data.get("mapping", {})
            if not prompt:
                self._send_error_json("工作流格式不完整（缺少 prompt）")
                return
            if not mapping:
                self._send_error_json("此工作流尚未設定欄位對應（mapping）。請在前端完成節點對應後再生成。工作流節點因模型和自訂節點而異，系統不會猜測。")
                return

            if not isinstance(values, dict):
                self._send_error_json("values 必須是物件")
                return
            if values.get("teacher") and not self._is_teacher():
                values.pop("teacher", None)
            orig_values = copy.deepcopy(values)
            if LAN_MODE and not payload.get("series_index") and self._user_busy():
                self._send_error_json("你已經有一件作品在排隊或生成中，等它完成再送下一件，讓大家輪流使用。", 429)
                return
            mi = load_model_info()
            text_all = " ".join(str(values.get(k) or "") for k in ("positive", "speech_text")).lower()
            bad = [w for w in mi.get("blocked_words", []) if w and w.lower() in text_all]
            if bad:
                self._send_error_json("描述裡有不適合校園的字詞，請修改後再試。", 400)
                return
            for k in ("positive",):
                if isinstance(values.get(k), str):
                    values[k] = strip_mj_flags(values[k])
            quality = str(values.pop("quality", "") or "std")
            sd_mode = None
            mm = str(values.pop("main_model", "") or "")
            kind = {"text": "txt2img", "lora": "lora", "img2img": "img2img"}.get(flow_data.get("icon"))
            if mm.startswith("photo:") and kind:
                fid = mm.split(":", 1)[1]
                if fid not in (mi.get("photo") or {}):
                    self._send_error_json("找不到這個主模型", 400)
                    return
                prompt, mapping, sp = build_photo_flow(fid, kind, self._components(), mi)
                fields = dict(flow_data.get("fields", {}))
                flow_data = dict(flow_data, prompt=prompt, mapping=mapping, fields=fields)
                values["steps"], values["cfg"] = int(sp.get("steps", 8)), float(sp.get("cfg", 1))
                if kind == "lora" and not values.get("lora"):
                    prompt["20"]["inputs"]["strength_model"] = 0.0
                    values.pop("lora", None)
                    prompt["20"]["inputs"]["lora_name"] = ""
                    del prompt["20"]; mapping.pop("lora", None); mapping.pop("lora_strength", None)
                    for n in prompt.values():
                        for k2, v2 in n["inputs"].items():
                            if v2 == ["20", 0]:
                                n["inputs"][k2] = ["1", 0]
                values.pop("ckpt", None)
                suffix = mi.get("photo_suffix", "")
                if suffix:
                    values["positive"] = f"{values.get('positive', '')}, {suffix}"
            elif mm and "ckpt" in mapping:
                values["ckpt"] = mm
            if not mm.startswith("photo:") and "ckpt" in mapping and flow_data.get("icon") in ("text", "lora", "img2img"):
                ck = values.get("ckpt") or ""
                fam = model_family(OUTPUT_DIR.parent / "models" / "checkpoints" / ck, "ckpt") if (OUTPUT_DIR is not None and ck) else "sd15"
                sd_mode = {"family": fam, "hires": quality == "fine" and fam == "sd15" and flow_data.get("icon") != "img2img"}
                q = mi.get("sd_quality", {})
                if not values.get("teacher"):
                    values["steps"], values["cfg"] = int(q.get("steps", 25)), float(q.get("cfg", 6.5))
                if q.get("negative") and "negative" in mapping:
                    values["negative"] = ", ".join(x for x in (str(values.get("negative") or "").strip(), q["negative"]) if x)
            values.pop("teacher", None)
            if mi.get("safety_negative") and "negative" in mapping:
                values["negative"] = ", ".join(x for x in (str(values.get("negative") or "").strip(), mi["safety_negative"]) if x)
            if mi.get("safety_positive") and "positive" in mapping and not flow_data.get("tts"):
                values["positive"] = f"{values.get('positive', '')}, {mi['safety_positive']}"
            tts_info = None
            tts_cfg = flow_data.get("tts")
            try:
                seg = audio_segment(values, flow_data.get("fields", {}).get("seconds", {})) if values.get("audio") else None
            except ValueError as e:
                self._send_error_json(str(e))
                return
            values.pop("audio_start", None); values.pop("audio_dur", None)
            if seg:
                values["seconds"] = max(float(flow_data.get("fields", {}).get("seconds", {}).get("min", 1)), seg[1])
            if tts_cfg:
                af, tf, secf = tts_cfg.get("audio_field", "audio"), tts_cfg.get("text_field", "speech_text"), tts_cfg.get("seconds_field", "seconds")
                text = str(values.get(tf) or "").strip()
                if not values.get(af):
                    if not text:
                        self._send_error_json("請輸入要說的台詞，或上傳一個音檔")
                        return
                    style = VOICE_STYLES.get(str(values.get("voice_style") or ""), None)
                    voice, pitch, rate = style or (tts_cfg.get("voice", "Zhiwei"), tts_cfg.get("pitch", "+30%"), tts_cfg.get("rate", "0.95"))
                    try:
                        wav = synthesize_tts(text, voice, pitch, rate)
                    except (RuntimeError, ValueError, OSError) as e:
                        self._send_error_json(str(e))
                        return
                    bd = uuid.uuid4().hex
                    fname = f"aura_tts_{bd[:10]}.wav"
                    mp = (f"--{bd}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{fname}\"\r\nContent-Type: audio/wav\r\n\r\n").encode() + wav + f"\r\n--{bd}--\r\n".encode()
                    st, _, d = self._proxy_to_comfy("POST", "/upload/image", body=mp, headers={"Content-Type": f"multipart/form-data; boundary={bd}"})
                    if st != 200:
                        self._send_error_json("TTS 音檔上傳到 ComfyUI 失敗", 502)
                        return
                    u = json.loads(d.decode("utf-8"))
                    values[af] = (u["subfolder"] + "/" if u.get("subfolder") else "") + u["name"]
                    dur = wav_seconds(wav)
                    tts_info = {"audio": values[af], "seconds": round(dur, 2) if dur else None}
                    if dur and tts_cfg.get("follow_audio", True):
                        spec = flow_data.get("fields", {}).get(secf, {})
                        values[secf] = min(float(spec.get("max", 8)), max(float(spec.get("min", 1)), round(dur + 0.3, 2)))
            try:
                workflow, used_seed = apply_mapping(prompt, mapping, flow_data.get("fields", {}), values)
                frames_used = None
                for t in ([mapping["seconds"]] if isinstance(mapping.get("seconds"), str) else mapping.get("seconds") or []):
                    nid, rest = t.split(".", 1)
                    frames_used = workflow.get(nid, {}).get("inputs", {}).get(rest.split(".", 1)[1])
                apply_av_options(workflow, flow_data, values, frames_used)
                apply_audio_trim(workflow, mapping, seg)
                drop_empty_images(workflow, mapping, flow_data.get("fields", {}), values)
                h3 = flow_data.get("h3")
                want_pika = str(values.get("pika", "")).lower() in ("1", "true", "on", "yes")
                last_img = values.get("last_image") if h3 == "i2v" else None
                if h3 and (want_pika or last_img or h3 == "ref2v"):
                    caps = h3_caps(self._object_info())
                    if h3 == "ref2v":
                        if not caps["ref_ready"]:
                            raise ValueError(h3_missing_text(caps, "ref2v"))
                        for n in workflow.values():
                            if n.get("class_type") == "LoraLoaderModelOnly":
                                n["inputs"]["lora_name"] = caps["lora_ref2va"]
                            if n.get("class_type") == "UNETLoader":
                                n["inputs"]["unet_name"] = caps["ref2va_unet"]
                    if last_img:
                        if not caps["last_frame"]:
                            raise ValueError("這台電腦的 ComfyUI 版本太舊，不支援結尾畫面。請先更新 ComfyUI。")
                        if not isinstance(last_img, str) or ".." in last_img or len(last_img) > 300:
                            raise ValueError("結尾圖檔名不合法")
                        apply_last_frame(workflow, last_img)
                    if want_pika and h3 == "i2v":
                        if not caps["pika"]:
                            raise ValueError(h3_missing_text(caps, "pika"))
                        apply_pika_flex(workflow, caps["lora_fl2va"])
                if sd_mode:
                    apply_sd_quality(workflow, mapping, mi, sd_mode)
            except (ValueError, KeyError, TypeError) as e:
                m = str(e)
                self._send_error_json(m if m.startswith(("這台電腦", "這個工作流", "結尾圖")) else f"套用欄位失敗: {m}")
                return

            # 提交到 ComfyUI
            submit_body = json.dumps({"prompt": workflow, "client_id": AURA_CLIENT_ID}).encode("utf-8")
            status, ctype, data = self._proxy_to_comfy("POST", "/prompt", body=submit_body,
                                                      headers={"Content-Type": "application/json"})
            if status != 200:
                err = data.decode("utf-8", errors="ignore")
                sys.stderr.write(f"ComfyUI 拒絕工作流: {err[:2000]}\n")
                self._send_error_json(friendly_error(err) if friendly_error(err) != err[:300] else f"ComfyUI 拒絕工作流: {err[:300]}", 502)
                return
            result = json.loads(data.decode("utf-8"))
            prompt_id = result.get("prompt_id")
            if prompt_id:
                JOB_NODES[prompt_id] = len(workflow)
            if not prompt_id:
                self._send_error_json("ComfyUI 未回傳 prompt_id", 502)
                return
            job_id = record_job(prompt_id, self._user(), filename, flow_data, orig_values, used_seed)
            self._send_json({
                "ok": True,
                "job_id": job_id,
                "prompt_id": prompt_id,
                "number": result.get("number"),
                "seed": used_seed,
                "tts": tts_info,
                "frames": next((workflow[t.split(".")[0]]["inputs"][t.split(".")[-1]] for f, sp in flow_data.get("fields", {}).items()
                                if sp.get("type") == "seconds" for t in ([mapping.get(f)] if isinstance(mapping.get(f), str) else (mapping.get(f) or []))), None),
                "message": "已提交到本機 ComfyUI 佇列"
            })
        except json.JSONDecodeError:
            self._send_error_json("無效的 JSON")
        except Exception as e:
            self._send_error_json(str(e), 500)

    def _refresh_pending(self, con_rows):
        """瀏覽器若在生成途中被關掉，作品仍會在這裡補記進作品庫。"""
        now = time.time()
        for r in con_rows[:20]:
            try:
                st, _, data = self._proxy_to_comfy("GET", f"/history/{r['prompt_id']}", timeout=5)
            except RuntimeError:
                return
            entry = json.loads(data.decode("utf-8")).get(r["prompt_id"]) if st == 200 else None
            if entry:
                finalize_job(r["prompt_id"], entry)
            elif now - r["created"] > 6 * 3600:  # ComfyUI 重開後 history 會清空
                with DB_LOCK, db_connect() as con:
                    con.execute("UPDATE jobs SET status='lost' WHERE id=? AND status='pending'", (r["id"],))

    def handle_gallery(self, qs):
        user = self._user()
        scope = (qs.get("scope") or ["mine"])[0]
        try:
            limit = max(1, min(100, int((qs.get("limit") or ["40"])[0])))
            before = int((qs.get("before") or ["0"])[0])
        except ValueError:
            self._send_error_json("參數格式錯誤")
            return
        if scope == "all" and not self._is_teacher():
            scope = "mine"
        where, args = ["hidden=0"], []
        if scope in ("mine", "starred"):
            where.append("user=?"); args.append(user)
        if scope == "starred":
            where.append("starred=1")
        with db_connect() as con:
            pend = con.execute("SELECT id, prompt_id, created FROM jobs WHERE status='pending' AND " + " AND ".join(where) + " ORDER BY id DESC", args).fetchall()
        if pend:
            self._refresh_pending(pend)
        if scope in ("mine", "starred") and user:
            with db_connect() as con:
                waiting = con.execute("SELECT * FROM series WHERE user=? AND status='waiting' ORDER BY id DESC LIMIT 5", (user,)).fetchall()
            for sr in waiting:
                self._advance_series(sr)
        where.append("status='done'")
        if before > 0:
            where.append("id<?"); args.append(before)
        with db_connect() as con:
            rows = con.execute("SELECT * FROM jobs WHERE " + " AND ".join(where) + " ORDER BY id DESC LIMIT ?", args + [limit + 1]).fetchall()
        items = []
        for r in rows[:limit]:
            it = job_row(r)
            it["mine"] = bool(user) and r["user"] == user
            items.append(it)
        self._send_json({"items": items, "more": len(rows) > limit})

    def _user_busy(self):
        """這個使用者是否還有作品在排隊或生成中（先向 ComfyUI 更新狀態）。"""
        user = self._user()
        with db_connect() as con:
            pend = con.execute("SELECT id, prompt_id, created FROM jobs WHERE user=? AND status='pending' ORDER BY id DESC", (user,)).fetchall()
        if not pend:
            return False
        try:
            st, _, d = self._proxy_to_comfy("GET", "/queue", timeout=5)
            q = json.loads(d.decode("utf-8")) if st == 200 else {}
        except (RuntimeError, ValueError):
            return False
        live = {it[1] for it in q.get("queue_running", []) + q.get("queue_pending", []) if len(it) > 1}
        if any(r["prompt_id"] in live for r in pend):
            return True
        self._refresh_pending(pend)
        return False

    def handle_progress(self, pid):
        with PROGRESS_LOCK:
            p = dict(PROGRESS.get(pid) or {})
        if not p:
            self._send_json({"known": False})
            return
        total = max(p.get("total") or 0, p.get("done", 0) + 1)
        self._send_json({"known": True, "value": p.get("value", 0), "max": p.get("max", 0), "node": p.get("node"),
                         "done": p.get("done", 0), "total": total, "finished": bool(p.get("finished"))})

    def _job_owned(self, prompt_id):
        with db_connect() as con:
            r = con.execute("SELECT id, user, status FROM jobs WHERE prompt_id=?", (prompt_id,)).fetchone()
        if r and (r["user"] == self._user() or self._is_local_client() and TEACHER_PIN is None or (TEACHER_PIN and self._is_teacher())):
            return r
        return None

    def _cancel_prompt(self, prompt_id):
        """排隊中 → 從佇列刪掉；生成中 → 中斷。回傳 True 表示有處理到。"""
        st, _, d = self._proxy_to_comfy("GET", "/queue", timeout=5)
        q = json.loads(d.decode("utf-8")) if st == 200 else {}
        running = {it[1] for it in q.get("queue_running", []) if len(it) > 1}
        pending = {it[1] for it in q.get("queue_pending", []) if len(it) > 1}
        if prompt_id in pending:
            self._proxy_to_comfy("POST", "/queue", body=json.dumps({"delete": [prompt_id]}).encode(), headers={"Content-Type": "application/json"})
        elif prompt_id in running:
            # 新版 ComfyUI 只中斷指定的 prompt_id；舊版會中斷目前這件（已確認就是它）
            self._proxy_to_comfy("POST", "/interrupt", body=json.dumps({"prompt_id": prompt_id}).encode(), headers={"Content-Type": "application/json"})
        else:
            return False
        with DB_LOCK, db_connect() as con:
            con.execute("UPDATE jobs SET status='cancelled', error='已取消。' WHERE prompt_id=? AND status='pending'", (prompt_id,))
        with PROGRESS_LOCK:
            if prompt_id in PROGRESS:
                PROGRESS[prompt_id]["finished"] = True
        return True

    def handle_cancel(self, body):
        try:
            req = json.loads(body.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            self._send_error_json("參數格式錯誤")
            return
        if not self._user():
            self._send_error_json("請從 AURA FRAME 頁面操作", 403)
            return
        pids = []
        if req.get("series_id"):
            with db_connect() as con:
                sr = con.execute("SELECT * FROM series WHERE id=?", (int(req["series_id"]),)).fetchone()
            if not sr or (sr["user"] != self._user() and not self._is_local_client()):
                self._send_error_json("找不到這個分段作品", 404)
                return
            ids = json.loads(sr["job_ids"])
            with db_connect() as con:
                pids = [r["prompt_id"] for r in con.execute(f"SELECT prompt_id FROM jobs WHERE status='pending' AND id IN ({','.join('?' * len(ids))})", ids)]
            with DB_LOCK, db_connect() as con:
                con.execute("UPDATE series SET status='error', error='已取消。' WHERE id=? AND status='waiting'", (sr["id"],))
                con.execute(f"UPDATE jobs SET hidden=0 WHERE id IN ({','.join('?' * len(ids))})", ids)
        else:
            pid = str(req.get("prompt_id") or "")
            if not re.fullmatch(r"[A-Za-z0-9-]{1,64}", pid) or not self._job_owned(pid):
                self._send_error_json("只能取消自己的作品", 403)
                return
            pids = [pid]
        try:
            # 先刪排隊中的，最後才中斷正在跑的，避免中斷後下一件剛好開始
            n = sum(1 for pid in reversed(pids) if self._cancel_prompt(pid))
        except RuntimeError as e:
            self._send_error_json(str(e), 503)
            return
        self._send_json({"ok": True, "cancelled": n})

    def handle_teacher_login(self, body):
        try:
            req = json.loads(body.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            req = {}
        if not TEACHER_PIN:
            self._send_json({"ok": True, "pin_required": False})
            return
        if req.get("logout"):
            self.send_response(200)
            self.send_header("Set-Cookie", "aura_teacher=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict")
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(b'{"ok": true}')
            return
        time.sleep(0.5)  # 減慢猜密碼
        if not hmac.compare_digest(str(req.get("pin") or ""), TEACHER_PIN):
            self._send_error_json("老師密碼不對", 403)
            return
        out = b'{"ok": true}'
        self.send_response(200)
        self.send_header("Set-Cookie", f"aura_teacher={teacher_token()}; Path=/; HttpOnly; SameSite=Strict")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def handle_series_create(self, body):
        try:
            req = json.loads(body.decode("utf-8") or "{}")
            ids = [int(x) for x in req.get("job_ids") or []]
            durs = [float(x) if x not in (None, "") else None for x in req.get("durs") or []]
            transition = max(0, min(12, int(req.get("transition", 4))))
            title = re.sub(r"[\x00-\x1f]", "", str(req.get("title") or "")).strip()[:30]
        except (ValueError, TypeError, UnicodeDecodeError):
            self._send_error_json("參數格式錯誤")
            return
        if not (2 <= len(ids) <= 40) or len(durs) != len(ids):
            self._send_error_json("分段數量需介於 2–40 段")
            return
        import aura_merge
        if not aura_merge.available():
            self._send_error_json("這台電腦的 Python 沒有影片合併元件（av、numpy）。請用「啟動AURA.bat」開啟 AURA，它會使用 ComfyUI 內建的 Python。", 400)
            return
        if OUTPUT_DIR is None:
            self._send_error_json("找不到 ComfyUI 作品資料夾，無法合併影片（可用 --output-dir 指定）", 400)
            return
        with db_connect() as con:
            n = con.execute(f"SELECT COUNT(*) FROM jobs WHERE user=? AND id IN ({','.join('?' * len(ids))})", [self._user()] + ids).fetchone()[0]
        if n != len(set(ids)) or len(set(ids)) != len(ids):
            self._send_error_json("找不到這些片段", 404)
            return
        with DB_LOCK, db_connect() as con:
            cur = con.execute("INSERT INTO series(created, user, job_ids, durs, transition, title) VALUES (?,?,?,?,?,?)",
                              (time.time(), self._user(), json.dumps(ids), json.dumps(durs), transition, title))
            con.execute(f"UPDATE jobs SET hidden=1 WHERE id IN ({','.join('?' * len(ids))})", ids)  # 作品庫只顯示合成好的一支
        self._send_json({"ok": True, "series_id": cur.lastrowid})

    def handle_series_status(self, sid):
        with db_connect() as con:
            sr = con.execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
        if not sr:
            self._send_error_json("找不到這個分段作品", 404)
            return
        status, err, ids, rows, states = self._advance_series(sr)
        item = None
        if status == "done":
            with db_connect() as con:
                g = con.execute("SELECT * FROM jobs WHERE id=(SELECT gallery_id FROM series WHERE id=?)", (sid,)).fetchone()
            if g:
                item = job_row(g)
                item["mine"] = bool(self._user()) and g["user"] == self._user()
        self._send_json({"status": status, "error": err, "total": len(ids), "done": states.count("done"),
                         "prompt_ids": [rows[i]["prompt_id"] for i in ids], "states": states, "item": item})

    def _advance_series(self, sr):
        """檢查各段狀態；全部完成就開始合併。學生關掉分頁也會在下次開作品庫時繼續。"""
        sid = sr["id"]
        with db_connect() as con:
            ids = json.loads(sr["job_ids"])
            rows = {r["id"]: r for r in con.execute(f"SELECT id, prompt_id, created, status FROM jobs WHERE id IN ({','.join('?' * len(ids))})", ids)}
        pend = [rows[i] for i in ids if rows[i]["status"] == "pending"]
        if pend:
            self._refresh_pending(pend)
            with db_connect() as con:
                rows = {r["id"]: r for r in con.execute(f"SELECT id, prompt_id, created, status FROM jobs WHERE id IN ({','.join('?' * len(ids))})", ids)}
        states = [rows[i]["status"] for i in ids]
        status, err = sr["status"], sr["error"]
        if status == "waiting":
            bad = [n + 1 for n, st in enumerate(states) if st in ("error", "lost", "empty")]
            if bad:
                status, err = "error", f"第 {'、'.join(map(str, bad))} 段生成失敗"
                with DB_LOCK, db_connect() as con:
                    con.execute("UPDATE series SET status='error', error=? WHERE id=? AND status='waiting'", (err, sid))
                    con.execute(f"UPDATE jobs SET hidden=0 WHERE id IN ({','.join('?' * len(ids))})", ids)
            elif all(st == "done" for st in states):
                with DB_LOCK, db_connect() as con:
                    claimed = con.execute("UPDATE series SET status='merging' WHERE id=? AND status='waiting'", (sid,)).rowcount
                if claimed:
                    threading.Thread(target=merge_series, args=(sid,), daemon=True).start()
                status = "merging"
        return status, err, ids, rows, states

    def handle_gallery_update(self, body):
        try:
            req = json.loads(body.decode("utf-8") or "{}")
            jid = int(req.get("id"))
        except (ValueError, TypeError, UnicodeDecodeError):
            self._send_error_json("參數格式錯誤")
            return
        with db_connect() as con:
            r = con.execute("SELECT user FROM jobs WHERE id=?", (jid,)).fetchone()
        if not r:
            self._send_error_json("找不到這件作品", 404)
            return
        if not self._user():  # 自訂標頭需 CORS 預檢，可擋跨站請求
            self._send_error_json("請從 AURA FRAME 頁面操作", 403)
            return
        if r["user"] != self._user() and not self._is_local_client():
            self._send_error_json("只能整理自己的作品", 403)
            return
        sets, args = [], []
        for k in ("starred", "hidden"):
            if k in req:
                sets.append(f"{k}=?"); args.append(1 if req[k] else 0)
        if not sets:
            self._send_error_json("沒有要更新的欄位")
            return
        with DB_LOCK, db_connect() as con:
            con.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id=?", args + [jid])
        self._send_json({"ok": True})

    def handle_history(self, prompt_id):
        try:
            status, ctype, data = self._proxy_to_comfy("GET", f"/history/{prompt_id}")
            if status != 200:
                self._send_error_json("查詢 history 失敗", status)
                return
            hist = json.loads(data.decode("utf-8"))
            entry = hist.get(prompt_id)
            finalize_job(prompt_id, entry)
            if entry and (entry.get("status") or {}).get("status_str") == "error":
                raw = comfy_error_text(entry)
                entry["aura_error"] = friendly_error(raw)
                entry["aura_cancelled"] = raw == "interrupted"
            self._send_json(hist)
        except Exception as e:
            self._send_error_json(str(e), 503)

    def _serve_output_file(self, params):
        """作品在本機 output 資料夾時直接從硬碟分段讀取（影片可拖曳、不必整支讀進記憶體）。"""
        if OUTPUT_DIR is None or params.get("type", "output") != "output" or "preview" in params:
            return False
        fn, sub = params.get("filename") or "", params.get("subfolder") or ""
        if not fn or "\x00" in fn + sub:
            return False
        fp = (OUTPUT_DIR / sub / fn).resolve()
        if OUTPUT_DIR.resolve() not in fp.parents or not fp.is_file():
            return False
        total = fp.stat().st_size
        ctype = {".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime", ".png": "image/png", ".jpg": "image/jpeg",
                 ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif", ".wav": "audio/wav", ".mp3": "audio/mpeg",
                 ".flac": "audio/flac"}.get(fp.suffix.lower()) or mimetypes.guess_type(fp.name)[0] or "application/octet-stream"
        start, end = 0, total - 1
        mt = re.fullmatch(r"bytes=(\d*)-(\d*)", (self.headers.get("Range") or "").strip())
        if mt and (mt.group(1) or mt.group(2)):
            if mt.group(1):
                start = int(mt.group(1)); end = min(int(mt.group(2)) if mt.group(2) else total - 1, total - 1)
            else:
                start = max(0, total - int(mt.group(2)))
            if start > end:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{total}")
                self.end_headers()
                return True
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "private, max-age=86400")
        self.end_headers()
        try:
            with open(fp, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass
        return True

    def handle_view(self, qs):
        # 代理 /view?filename=...&subfolder=...&type=...
        params = {k: v[0] for k, v in qs.items() if v and k in ("filename", "subfolder", "type", "preview")}
        if self._serve_output_file(params):
            return
        query = urllib.parse.urlencode(params)
        try:
            status, ctype, data = self._proxy_to_comfy("GET", f"/view?{query}", timeout=120)
            # 影片支援 Range（讓 <video> 可拖曳進度）
            rng = self.headers.get("Range", "")
            mt = re.fullmatch(r"bytes=(\d*)-(\d*)", rng.strip()) if status == 200 and rng else None
            total = len(data)
            if mt and (mt.group(1) or mt.group(2)):
                if mt.group(1):
                    start = int(mt.group(1)); end = int(mt.group(2)) if mt.group(2) else total - 1
                else:
                    start = max(0, total - int(mt.group(2))); end = total - 1
                end = min(end, total - 1)
                if start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{total}")
                    self.end_headers()
                    return
                self.send_response(206)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Range", f"bytes {start}-{end}/{total}")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(end - start + 1))
                self.end_headers()
                self.wfile.write(data[start:end + 1])
                return
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._send_error_json(str(e), 503)

    def handle_upload(self, body):
        # 簡單代理 multipart 到 ComfyUI /upload/image
        # 注意：這裡假設前端已正確組裝 multipart，或我們只支援 JSON 描述
        # 為簡化，支援前端先上傳到本機暫存再轉發，但為純 stdlib 我們直接轉發 Content-Type
        content_type = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in content_type:
            self._send_error_json("上傳需使用 multipart/form-data")
            return
        try:
            status, ctype, data = self._proxy_to_comfy("POST", "/upload/image", body=body,
                                                      headers={"Content-Type": content_type})
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._send_error_json(str(e), 503)


def main():
    global HOST, PORT, ACCESS_CODE, COMFY_URL, OUTPUT_DIR, LORAS_DIR
    parser = argparse.ArgumentParser(description="AURA FRAME Local Server")
    parser.add_argument("--host", default="127.0.0.1", help="監聽位址（預設僅本機）")
    parser.add_argument("--port", type=int, default=8000, help="埠號")
    parser.add_argument("--comfy", default=COMFY_URL, help="ComfyUI 位址")
    parser.add_argument("--access-code", default=None, help="校內區網模式時的課堂存取碼（必填才開放非本機）")
    parser.add_argument("--output-dir", default=None, help="ComfyUI output 資料夾（預設自動偵測）")
    parser.add_argument("--loras-dir", default=None, help="ComfyUI models/loras 資料夾（預設自動偵測）")
    parser.add_argument("--comfy-dir", default=None, help="ComfyUI 安裝資料夾（預設自動尋找，也可寫在 config/comfy_path.txt）")
    parser.add_argument("--no-auto-comfy", action="store_true", help="不要自動啟動 ComfyUI")
    parser.add_argument("--open", action="store_true", help="啟動後自動開啟瀏覽器")
    parser.add_argument("--no-hw-popup", action="store_true", help="硬體不足時不要跳出 Windows 提醒視窗（網頁仍會提醒）")
    args = parser.parse_args()
    COMFY_URL = args.comfy.rstrip("/")

    # 找 ComfyUI；沒在執行就自動啟動（只限本機位址）
    layout = None
    is_local_comfy = urllib.parse.urlparse(COMFY_URL).hostname in LOCAL_HOSTS
    if args.no_auto_comfy or not is_local_comfy:
        COMFY_STATE.update(phase="disabled")
    else:
        layout = find_comfy_dir(args.comfy_dir)
        if comfy_alive():
            COMFY_STATE.update(phase="running")
            print("偵測到 ComfyUI 已在執行，直接連線。")
        elif layout is None:
            COMFY_STATE.update(phase="not_found", message="找不到 ComfyUI：請把 ComfyUI 資料夾路徑寫進 AURA 的 config/comfy_path.txt，或先手動開啟 ComfyUI")
            print(COMFY_STATE["message"])
        if layout is not None:
            COMFY_STATE["dir"] = str(layout[2])
            try:  # 記住找到的位置，下次不用再找
                saved = COMFY_PATH_FILE.read_text(encoding="utf-8-sig") if COMFY_PATH_FILE.exists() else ""
                if not any(l.strip() and not l.strip().startswith("#") for l in saved.splitlines()):
                    COMFY_PATH_FILE.write_text("# ComfyUI 安裝資料夾（AURA 自動偵測後寫入，可自行修改）\n" + str(layout[0]) + "\n", encoding="utf-8")
            except OSError:
                pass

    if args.output_dir:
        OUTPUT_DIR = Path(args.output_dir).resolve()
    elif layout is not None and (layout[2] / "output").is_dir():
        OUTPUT_DIR = (layout[2] / "output").resolve()
    else:
        OUTPUT_DIR = detect_output_dir()
    if args.loras_dir:
        LORAS_DIR = Path(args.loras_dir).resolve()
    elif OUTPUT_DIR is not None and (OUTPUT_DIR.parent / "models" / "loras").is_dir():
        LORAS_DIR = (OUTPUT_DIR.parent / "models" / "loras").resolve()

    HOST = args.host
    PORT = args.port
    global TEACHER_PIN, LAN_MODE
    LAN_MODE = HOST not in LOCAL_HOSTS
    try:
        TEACHER_PIN = str(json.loads((BASE_DIR / "config" / "teacher.json").read_text(encoding="utf-8-sig")).get("pin") or "").strip() or None
    except (OSError, ValueError, AttributeError):
        TEACHER_PIN = None
    threading.Thread(target=comfy_ws_loop, daemon=True).start()
    global HW_CACHE
    try:  # 啟動時先檢查硬體；不適合就跳出提醒視窗（不會擋住程式）
        HW_CACHE = aura_hw.detect(COMFY_URL if comfy_alive(1) else None, COMFY_STATE.get("dir"))
        print("-" * 60 + "\n硬體檢查\n" + aura_hw.summary_text(HW_CACHE) + "\n" + "-" * 60)
        if HW_CACHE["overall"] != "ok" and not args.no_hw_popup:
            threading.Thread(target=aura_hw.popup, args=(HW_CACHE,), daemon=True).start()
    except Exception as e:
        print(f"硬體檢查失敗（不影響使用）：{e}")
    try:
        init_db()
    except sqlite3.Error as e:
        print(f"警告：作品庫無法建立（{DB_PATH}）：{e}")
    ACCESS_CODE = args.access_code or None
    if ACCESS_CODE is not None and len(ACCESS_CODE) < 4:
        print("錯誤：--access-code 至少 4 個字元。")
        sys.exit(1)
    try:
        cu = urllib.parse.urlparse(COMFY_URL)
        if cu.hostname not in LOCAL_HOSTS:
            print(f"警告：--comfy 指向非本機位址 {cu.hostname}。AURA FRAME 設計為只代理本機 ComfyUI。")
    except Exception:
        pass

    if HOST not in LOCAL_HOSTS and not ACCESS_CODE:
        print("錯誤：提供校內區網模式時必須設定 --access-code 課堂存取碼。")
        print("ComfyUI 仍只監聽本機，請勿公開 8188 或做 Port Forwarding。")
        sys.exit(1)

    print("=" * 60)
    print("AURA FRAME Local Server")
    print(f"前端與 API: http://{HOST}:{PORT}")
    print(f"代理 ComfyUI: {COMFY_URL}")
    print(f"ComfyUI 資料夾: {COMFY_STATE['dir'] or '未偵測到（可寫在 config/comfy_path.txt）'}")
    print(f"作品資料夾: {OUTPUT_DIR or '未偵測到（可用 --output-dir 指定）'}")
    if ACCESS_CODE:
        print(f"課堂存取碼已啟用: {ACCESS_CODE}")
        print("請在網址加上 ?code=你的存取碼 或設定 Header")
    else:
        print("模式: 僅本機使用（127.0.0.1）")
    print("注意：Canvas 預覽無法代表本機連線成功，請以 /api/status 為準。")
    print("按 Ctrl+C 停止")
    print("=" * 60)

    socketserver.ThreadingTCPServer.allow_reuse_address = True
    socketserver.ThreadingTCPServer.daemon_threads = True
    try:
        httpd = socketserver.ThreadingTCPServer((HOST, PORT), AURAHandler)
    except OSError as e:
        print(f"錯誤：埠 {PORT} 無法使用（可能 AURA 已經開著，或被其他程式占用）：{e}")
        sys.exit(1)
    if COMFY_STATE["phase"] not in ("running", "disabled") and layout is not None:
        threading.Thread(target=start_comfy, args=(layout,), daemon=True).start()
    if args.open:
        import webbrowser
        webbrowser.open(f"http://127.0.0.1:{PORT}/")
    with httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n已停止")
        finally:
            stop_comfy()


if __name__ == "__main__":
    main()
