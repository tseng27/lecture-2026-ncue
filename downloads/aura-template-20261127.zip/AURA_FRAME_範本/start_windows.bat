@echo off
chcp 65001 >nul
rem 舊的啟動檔名稱，與「啟動AURA.bat」相同
call "%~dp0啟動AURA.bat" %*
