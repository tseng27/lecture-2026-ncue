// AURA FRAME Local Frontend（開箱即用版）
// 所有功能透過本機 /api/* 代理到 ComfyUI，不呼叫雲端。
"use strict";

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// 區網模式：網址 ?code=xxx 會由伺服器設成 Cookie；這裡也同時用 Header 帶上
const ACCESS_CODE = new URLSearchParams(location.search).get("code") || sessionStorage.getItem("aura_code") || "";
if (ACCESS_CODE) sessionStorage.setItem("aura_code", ACCESS_CODE);
// 作品庫用的瀏覽器代號（不是帳號，只用來分辨「我的作品」）
const AURA_UID = (() => {
  let u = ""; try { u = localStorage.getItem("aura_uid") || ""; } catch { }
  if (!/^[A-Za-z0-9-]{8,64}$/.test(u)) {
    u = (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + "-" + Math.random().toString(36).slice(2));
    try { localStorage.setItem("aura_uid", u); } catch { }
  }
  return u;
})();
const authHeaders = () => ({ "X-Aura-User": AURA_UID, ...(ACCESS_CODE ? { "X-Access-Code": ACCESS_CODE } : {}) });

const state = { flows: [], models: { checkpoints: [], loras: [] }, current: null };

async function api(path, options = {}) {
  const isForm = options.body instanceof FormData;
  const res = await fetch(path, {
    ...options,
    headers: { ...(isForm ? {} : { "Content-Type": "application/json" }), ...authHeaders(), ...(options.headers || {}) }
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  const ct = res.headers.get("content-type") || "";
  return ct.includes("application/json") ? res.json() : res;
}

async function refreshStatus() {
  const ind = $("status-indicator"), txt = $("status-text");
  try {
    const s = await api("/api/status");
    ind.className = "dot online";
    state.canOpen = !!s.can_open_folder; state.canMerge = !!s.can_merge; const ob = $("open-output"); if (ob) ob.hidden = !state.canOpen;
    txt.textContent = s.queue_remaining ? `ComfyUI 已連線，佇列 ${s.queue_remaining} 件` : "ComfyUI 已連線，可以開始";
    if (state.comfyWasDown) {  // ComfyUI 剛啟動完成：重新載入模型與工作流
      state.comfyWasDown = false;
      await loadModels(); await loadFlows(true);
    }
    if (!state.busy) { $("generate-btn").disabled = false; const r = $("generate-result"); if (r && r.dataset.wait) { r.textContent = ""; delete r.dataset.wait; } }
    return s;
  } catch (e) {
    state.comfyWasDown = true;
    ind.className = "dot offline";
    if (!state.busy) $("generate-btn").disabled = true;  // ComfyUI 還沒好之前不能按生成
    // AURA 會自動啟動 ComfyUI；啟動中或找不到時，顯示伺服器給的說明
    txt.textContent = /^(ComfyUI|找不到)/.test(e.message || "") ? e.message : "ComfyUI 未啟動：請先開啟 ComfyUI";
    return null;
  }
}

// ---------- 每種創作方式的「點選式」設定 ----------
const ICONS = {
  text: '<svg viewBox="0 0 32 32" fill="none" stroke="#7A68F5" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="6" width="24" height="20" rx="3"/><path d="M4 21l7-7 6 6 4-4 7 7"/><circle cx="21.5" cy="12" r="2.2"/></svg>',
  lora: '<svg viewBox="0 0 32 32" fill="none" stroke="#F06C9B" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 26c4-1 6-3 7-7l9-9a3 3 0 0 0-4-4l-9 9c-4 1-6 3-7 7"/><path d="M6 26l2-6"/><path d="M22 4l6 6"/></svg>',
  img2img: '<svg viewBox="0 0 32 32" fill="none" stroke="#19B3A3" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="12" height="14" rx="2"/><rect x="17" y="10" width="12" height="14" rx="2"/><path d="M13 4c4 0 7 2 8 5M21 9l1-4M21 9l-4-1"/></svg>',
  i2v: '<svg viewBox="0 0 32 32" fill="none" stroke="#5C8DF6" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="7" width="20" height="18" rx="3"/><path d="M23 13l6-4v14l-6-4"/><path d="M11 12l5 4-5 4z"/></svg>',
  ref2v: '<svg viewBox="0 0 32 32" fill="none" stroke="#8B5CF6" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="10" r="4"/><path d="M3 22c0-4 3-6 6-6s6 2 6 6"/><rect x="17" y="9" width="12" height="14" rx="2"/><path d="M21 13l4 3-4 3z"/></svg>',
  talk: '<svg viewBox="0 0 32 32" fill="none" stroke="#F59E0B" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13" cy="14" r="8"/><path d="M10 17c2 2 4 2 6 0"/><path d="M24 9c2 2 2 8 0 10M27 6c4 4 4 12 0 16"/></svg>',
};
// 直式 9:16、橫式 16:9、方形 1:1。圖片：SD1.5 需 8 的倍數；影片：MiniMax H3 需 32 的倍數，且控制在 16GB VRAM 內
const IMG_SIZES = [{ k: "pt", t: "直式 9:16", w: 432, h: 768 }, { k: "ls", t: "橫式 16:9", w: 768, h: 432 }, { k: "sq", t: "方形 1:1", w: 512, h: 512 }];
const VID_RES = {
  sd: [{ w: 544, h: 960 }, { w: 960, h: 544 }, { w: 736, h: 736 }],    // 標準 ≈540p
  hd: [{ w: 704, h: 1280 }, { w: 1280, h: 704 }, { w: 960, h: 960 }],  // 高清 720p
};
const VID_SIZES = [{ k: "pt", t: "直式 9:16" }, { k: "ls", t: "橫式 16:9" }, { k: "sq", t: "方形 1:1" }];
const CLARITY = [{ k: "sd", t: "標準 540p" }, { k: "hd", t: "高清 720p（建議 3 秒內）" }];
const DEFAULT_CLARITY = "sd";
function applyVidSize() {
  const i = VID_SIZES.findIndex(x => x.k === (state.ratio || "pt")), r = VID_RES[state.clarity || DEFAULT_CLARITY][i];
  setVal("width", r.w); setVal("height", r.h);
}
const IMG_Q = [{ t: "標準", q: "std" }, { t: "精細（放大兩階段，約慢 2 倍）", q: "fine" }];
const TEACHER = new URLSearchParams(location.search).has("teacher") || localStorage.getItem("aura_teacher") === "1";
const VID_Q = [{ t: "快速", steps: 4 }, { t: "標準", steps: 6 }, { t: "精細", steps: 8 }];
const PROFILES = {
  text: { tag: "圖片", est: () => 10, ideas: ["水彩風格的校園", "可愛的貓咪插畫", "未來城市夜景，霓虹燈", "溫暖陽光的美術教室", "奇幻森林裡的小屋"] },
  lora: { tag: "圖片", est: () => 12, ideas: ["一位女孩站在美術教室微笑", "全身人物，乾淨背景", "時尚穿搭街拍"] },
  img2img: { tag: "圖片", est: () => 10, ideas: ["改成油畫風格", "變成夜晚，月光", "改成水彩插畫", "日系動畫風格"] },
  i2v: { tag: "影片", video: true, est: (v) => vidEst(v, 0), ideas: ["鏡頭慢慢推近", "頭髮和衣服被風吹動", "角色眨眼並微笑", "翅膀輕輕拍動", "背景雲朵緩緩飄動"] },
  ref2v: { tag: "影片", video: true, est: (v) => vidEst(v, 20), ideas: ["她走進下雨的街道，撐開紅色雨傘，回頭對鏡頭微笑", "他在美術教室畫畫，抬頭看向窗外", "角色在森林裡奔跑，跳過一根倒下的樹幹"] },
  talk: { tag: "會說話", video: true, est: (v) => vidEst(v, 15), ideas: ["來 AURORA VITA 找你的夢", "大家好，歡迎來到美術教室！", "今天也要開心畫畫喔"] },
};
const VOICES = [{ k: "cartoon_m", t: "卡通男聲" }, { k: "natural_m", t: "自然男聲" }, { k: "female", t: "女聲" }, { k: "kid", t: "童聲" }];
const SECONDS = [2, 3, 5, 8];
function vidEst(v, extra) {
  const px = ((+v.width || 576) * (+v.height || 576)) / (576 * 576), st = v.pika ? 1 : (+v.steps || 6) / 6;
  return extra + 30 + (+v.seconds || 3) * 55 * Math.pow(px, 0.8) * st; // 實測 RTX 5060 Ti 16GB：540p 3 秒 ≈ 5 分、720p 3 秒 ≈ 6.5 分
}
const DENOISE = [{ t: "像原圖", v: 0.35 }, { t: "平衡", v: 0.55 }, { t: "大改", v: 0.75 }];
const STRENGTH = [{ t: "輕", v: 0.4 }, { t: "中", v: 0.7 }, { t: "強", v: 1.0 }];
const MAIN_KEYS = new Set(["positive", "image", "audio", "speech_text", "lora", "lora_strength", "denoise", "width", "height", "steps", "cfg", "seconds", "seed", "ckpt", "negative"]);

state.vals = {}; state.history = []; state.lastSeed = null; state.busy = false;

function pickCkpt(list) {
  const notXL = list.filter(m => !/xl|flux|sd3|pony|illustrious|z[-_]?image|qwen|hidream/i.test(m));
  return list.find(m => /dreamshaper/i.test(m)) || notXL.find(m => /realistic|anything|counterfeit|v1-5|sd15|1\.5|majic|rev/i.test(m)) || notXL[0] || list[0] || "";
}
const prettyName = (f) => f.replace(/\.(safetensors|ckpt|pt)$/i, "").replace(/[_-]+/g, " ");

function setVal(k, v) {
  state.vals[k] = v;
  const a = document.querySelector(`[data-adv="${k}"]`);
  if (a && a.value !== String(v)) a.value = v;
}

function chipGroup(items, isOn, onPick, label) {
  const g = document.createElement("div");
  g.className = "chips"; g.setAttribute("role", "group"); if (label) g.setAttribute("aria-label", label);
  const draw = () => g.querySelectorAll(".chip").forEach((b, i) => b.setAttribute("aria-pressed", String(isOn(items[i]))));
  items.forEach(it => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "chip"; b.innerHTML = it.html || esc(it.t);
    b.onclick = () => { onPick(it); draw(); };
    g.appendChild(b);
  });
  draw(); g.redraw = draw;
  return g;
}

function stepBlock(n, title, hint) {
  const s = document.createElement("div");
  s.className = "step";
  s.innerHTML = `<h2><span class="num">${n}</span>${esc(title)}</h2>`;
  if (hint) { const p = document.createElement("p"); p.className = "hint"; p.textContent = hint; s.appendChild(p); }
  return s;
}

function dropZone(kind, field, opts = {}) {
  const isAudio = kind === "audio", crop = opts.crop !== false;
  const z = document.createElement("div");
  z.className = "drop"; z.tabIndex = 0; z.setAttribute("role", "button");
  z.setAttribute("aria-label", isAudio ? "上傳人聲音檔" : "上傳圖片");
  const input = document.createElement("input");
  input.type = "file"; input.hidden = true; input.accept = isAudio ? "audio/*,.wav,.mp3,.m4a,.flac" : "image/*";
  const idle = isAudio
    ? `<div class="ph" aria-hidden="true">♪</div><div><p><strong>拖曳音檔到這裡</strong>，或點一下選擇</p><p class="sub">wav / mp3，人聲越乾淨，嘴型越準</p></div>`
    : `<div class="ph" aria-hidden="true">＋</div><div><p><strong>拖曳圖片到這裡</strong>，或點一下選擇</p><p class="sub">jpg / png，主角清楚、正面效果最好</p></div>`;
  z.innerHTML = idle; z.appendChild(input);
  const handle = async (file) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    z.innerHTML = `${isAudio ? '<div class="ph">♪</div>' : (crop ? `<img class="crop-prev" src="${url}" alt="已選擇的圖片（虛線框內為會用到的範圍）">` : `<img src="${url}" alt="已選擇的圖片">`)}<div style="flex:1"><p><strong>${esc(file.name)}</strong></p><p class="sub" data-s>上傳中…</p>${isAudio ? `<audio controls src="${url}"></audio>` : ""}</div>`; updateCrop();
    z.appendChild(input);
    const st = z.querySelector("[data-s]");
    if (isAudio) {
      const a = new Audio(url);
      a.onloadedmetadata = () => { if (isFinite(a.duration)) { state.audioSec = a.duration; setVal("seconds", Math.min(8, Math.max(1, Math.round((a.duration + 0.3) * 10) / 10))); st.dataset.d = `長度 ${a.duration.toFixed(1)} 秒`; } };
    }
    const fd = new FormData(); fd.append("image", file); fd.append("overwrite", "true");
    try {
      const r = await api("/api/upload", { method: "POST", body: fd });
      setVal(field, r.subfolder ? `${r.subfolder}/${r.name}` : r.name);
      st.textContent = "已上傳到本機 ComfyUI，點一下可更換" + (st.dataset.d ? `（${st.dataset.d}）` : "");
    } catch (e) {
      setVal(field, ""); st.innerHTML = `<span class="err">上傳失敗：${esc(e.message)}</span>`;
    }
  };
  z.onclick = (e) => { if (e.target.tagName !== "AUDIO") input.click(); };
  z.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } };
  input.onchange = () => handle(input.files[0]);
  z.useFile = handle;
  z.ondragover = (e) => { e.preventDefault(); z.classList.add("over"); };
  z.ondragleave = () => z.classList.remove("over");
  z.ondrop = (e) => { e.preventDefault(); z.classList.remove("over"); handle(e.dataTransfer.files[0]); };
  return z;
}

// ---------- 工作流 ----------
async function loadFlows(keepSelection) {
  const prev = keepSelection && state.current ? state.current.filename : "";
  try {
    const data = await api("/api/flows");
    state.flows = data.flows || [];
  } catch (e) {
    $("flow-cards").innerHTML = `<p class="err">讀取工作流失敗：${esc(e.message)}</p>`;
    return;
  }
  const ready = state.flows.filter(f => f.has_mapping && !f.error);
  const box = $("flow-cards");
  box.innerHTML = ready.length ? "" : '<p class="err">flows/ 資料夾裡沒有可用的工作流。</p>';
  ready.forEach(f => {
    const p = PROFILES[f.icon] || { tag: "自訂" };
    const b = document.createElement("button");
    b.type = "button"; b.className = "flow-card"; b.setAttribute("role", "radio");
    b.dataset.file = f.filename;
    b.innerHTML = `${ICONS[f.icon] || ICONS.text}<strong>${esc(f.name.replace(/\s*\(.*\)\s*$/, ""))}</strong><small>${esc(f.description || "")}</small><span class="tag">${esc(p.tag)}</span>`;
    b.onclick = () => selectFlow(f.filename);
    box.appendChild(b);
  });
  renderAdvancedList();
  const want = prev || decodeURIComponent((location.hash.match(/flow=([^&]+)/) || [])[1] || "");
  const first = (want && ready.find(f => f.filename === want)) || ready[0];
  if (first) selectFlow(first.filename);
}

async function selectFlow(filename) {
  document.querySelectorAll(".flow-card").forEach(c => c.setAttribute("aria-checked", String(c.dataset.file === filename)));
  let flow;
  try { flow = await api(`/api/flows/${encodeURIComponent(filename)}`); } catch (e) { $("generate-result").innerHTML = `<span class="err">${esc(e.message)}</span>`; return; }
  const meta = state.flows.find(f => f.filename === filename) || {};
  state.current = { ...flow, filename, icon: meta.icon || "" };
  state.vals = {}; state.audioSec = null; state.segs = []; state.story = null; state.refMode = "char"; state.refRoles = { ref2: "scene", ref3: "char" }; state.boardPanels = 0;
  renderSteps();
}

function renderSteps() {
  const flow = state.current, f = flow.fields || {}, m = flow.mapping || {}, has = (k) => k in m || k in f;
  const prof = PROFILES[flow.icon] || { est: () => 15, ideas: [] };
  const steps = $("steps"); steps.innerHTML = "";
  let n = 2;
  // 預設值
  Object.entries(f).forEach(([k, s]) => { if (s.default !== undefined && s.default !== "") state.vals[k] = s.default; });
  const mains = has("ckpt") ? (state.models.main || []) : [];
  if (mains.length && !mains.find(x => x.id === state.mainModel)) state.mainModel = (mains.find(x => x.id === state.models.mainDefault) || mains.find(x => x.kind === "ckpt") || mains[0]).id;
  const mainM = mains.find(x => x.id === state.mainModel) || null;
  const fam = mainM ? mainM.family : "sd15";
  state.family = fam;
  if (has("ckpt")) state.vals.ckpt = mainM && mainM.kind === "ckpt" ? mainM.id : (pickCkpt(state.models.checkpoints) || state.vals.ckpt);
  if (mains.length > 1) {
    const s = stepBlock(n++, "選主模型", "寫實攝影適合真實人像、照片；插畫·藝術風格適合卡通、繪畫。");
    const g = document.createElement("div"); g.className = "lora-cards model-cards";
    mains.forEach(mm => {
      const b = document.createElement("button"); b.type = "button"; b.className = "lora-card"; b.title = mm.id;
      b.setAttribute("aria-pressed", String(mm.id === state.mainModel));
      const h = [...mm.label].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
      const thumb = mm.preview ? `<img class="lc-thumb" loading="lazy" alt="" src="/api/model-preview?id=${encodeURIComponent(mm.id)}">`
        : `<span class="lc-thumb" aria-hidden="true" style="background:linear-gradient(135deg,hsl(${h} 60% 70%),hsl(${(h + 60) % 360} 55% 50%))">${esc(mm.tag)}</span>`;
      b.innerHTML = `${thumb}<span class="lc-tag ${mm.kind === "photo" ? "photo" : ""}">${esc(mm.group)} · ${esc(mm.tag)}</span><span class="lc-name">${esc(mm.label.replace(/^寫實攝影\s*·\s*/, ""))}</span>`;
      b.onclick = () => { if (state.mainModel === mm.id) return; const keep = { positive: state.vals.positive, image: state.vals.image }; state.mainModel = mm.id; renderSteps(); Object.assign(state.vals, keep); const ta = $("main-text"); if (ta && keep.positive) ta.value = keep.positive; };
      g.appendChild(b);
    });
    s.appendChild(g); steps.appendChild(s);
  }
  if (has("seed")) state.vals.seed = -1;

  const h3 = state.models.h3 || {};
  if (has("image") && flow.icon === "ref2v") steps.appendChild(refStep(n++, h3));
  else if (has("image")) {
    const s = stepBlock(n++, flow.icon === "talk" ? "選角色圖" : flow.icon === "i2v" ? "選起始畫面" : "選參考圖");
    s.appendChild(dropZone("image", "image"));
    if (flow.icon === "i2v" && h3.last_frame) {
      const d = document.createElement("details"); d.className = "advanced"; d.id = "last-frame-box";
      d.innerHTML = "<summary>加上結尾畫面（首尾幀：AI 自動補出中間的過渡）</summary>";
      d.appendChild(optZone("last_image"));
      d.insertAdjacentHTML("beforeend", '<p class="hint">適合變身、換裝、從白天到晚上這類轉場。兩張圖的角色和構圖越接近，過渡越自然。</p>');
      s.appendChild(d);
    }
    steps.appendChild(s);
  }
  // 唯一需要打字的地方
  const textKey = flow.tts ? "speech_text" : "positive";
  {
    const s = stepBlock(n++, flow.tts ? "要說什麼？" : flow.icon === "ref2v" ? "影片裡發生什麼事？" : flow.icon === "i2v" ? "畫面要怎麼動？" : flow.icon === "img2img" ? "想改成什麼樣子？" : "描述你想要的畫面");
    const ta = document.createElement("textarea");
    ta.id = "main-text"; ta.maxLength = flow.tts ? 200 : 1000;
    ta.placeholder = (f[textKey] && f[textKey].placeholder) || (flow.tts ? "例如：來 AURORA VITA 找你的夢" : flow.icon === "ref2v" ? "例如：她走進下雨的街道，撐開紅色雨傘，回頭對鏡頭微笑。可以寫好幾個動作，依序發生。" : flow.icon === "i2v" ? "例如：翅膀輕輕拍動，圍巾被風吹動，鏡頭不動" : flow.icon === "img2img" ? "例如：改成水彩插畫風格" : "例如：可愛的貓咪插畫，柔和光線");
    ta.setAttribute("aria-label", flow.tts ? "台詞" : "畫面描述");
    ta.value = flow.tts ? "" : "";
    const flagHint = document.createElement("p"); flagHint.className = "hint"; flagHint.hidden = true; flagHint.textContent = "「--ar」「--v」這類指令在這裡沒有作用，會自動移除；比例請用下方按鈕。";
    ta.oninput = () => { state.vals[textKey] = ta.value; flagHint.hidden = !/(^|\s)--[a-z]/i.test(ta.value); };
    const clr = document.createElement("button");
    clr.type = "button"; clr.className = "btn-clear"; clr.textContent = flow.tts ? "清空台詞" : "清空提示詞";
    clr.onclick = () => { ta.value = ""; state.vals[textKey] = ""; flagHint.hidden = true; ta.focus(); };
    s.querySelector("h2").appendChild(clr);
    s.appendChild(ta); s.appendChild(flagHint);
    if (flow.icon === "i2v") {
      const one = document.createElement("p"); one.className = "hint"; one.textContent = "動作直接寫在這裡，例如「貓咪向鏡頭揮手」「慢慢轉身」「鏡頭慢慢推近」。";
      const sb = storyboardWidget();
      const sync = () => { const on = !!state.story; ta.hidden = one.hidden = clr.hidden = on; sb.hidden = !on; const lf = $("last-frame-box"); if (lf) lf.hidden = on; if (on) flagHint.hidden = true; s.querySelector("h2 .t").textContent = on ? "寫分鏡（每格一段影片）" : "畫面要怎麼動？"; updEst(); };
      const h2 = s.querySelector("h2"); h2.childNodes[1].replaceWith(Object.assign(document.createElement("span"), { className: "t", textContent: "畫面要怎麼動？" }));
      const mode = chipGroup([{ t: "單一鏡頭", v: false }, { t: "漫劇分鏡（多格接成一支）", v: true }], it => !!state.story === it.v,
        it => { if (it.v && !state.story) state.story = { shared: "", shots: [newShot(), newShot(), newShot()] }; if (!it.v) state.story = null; sb.rebuild(); sync(); }, "創作方式");
      s.insertBefore(mode, ta); s.append(one, sb); sync();
    }
    if (flow.tts) {
      s.insertAdjacentHTML("beforeend", '<p class="sub-label">聲音</p>');
      state.vals.voice_style = "cartoon_m";
      s.appendChild(chipGroup(VOICES, it => state.vals.voice_style === it.k, it => { state.vals.voice_style = it.k; }, "聲音"));

      const d = document.createElement("details"); d.className = "advanced";
      d.innerHTML = "<summary>改用自己的音檔（可上傳好幾段，或一整首歌）</summary>";
      d.appendChild(segmentWidget((f.seconds || {}).max || 8));
      s.appendChild(d);
    }
    steps.appendChild(s);
  }
  // 風格（LoRA）
  const famLoras = (state.models.loraInfo || []).filter(l => l.family === fam || (l.family === "unknown" && fam === "sd15"));
  if (has("lora") && !famLoras.length) { const s = stepBlock(n++, "選一種風格", "這個主模型目前沒有可用的風格，會直接生成。"); steps.appendChild(s); state.vals.lora = ""; }
  if (has("lora") && famLoras.length) {
    const s = stepBlock(n++, "選一種風格", "點一下套用，再點一次取消。");
    const g = document.createElement("div"); g.className = "lora-cards";
    const draw = () => g.querySelectorAll(".lora-card").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.v === (state.vals.lora || ""))));
    const hue = (t) => [...t].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
    const initials = (t) => { const w = t.replace(/^角色\s*/, "").trim().split(/\s+/); return (/[\u4e00-\u9fff]/.test(w[0]) ? w[0].slice(0, 2) : w.slice(0, 2).map(x => x[0]).join("")).toUpperCase(); };
    [{ v: "", t: "不套用風格", none: true }, ...famLoras.map(l => ({ v: l.name, t: l.label, p: l.preview }))].forEach(it => {
      const b = document.createElement("button"); b.type = "button"; b.className = "lora-card"; b.dataset.v = it.v; b.title = it.v || it.t;
      const h = hue(it.t);
      const thumb = it.none ? `<span class="lc-thumb lc-none" aria-hidden="true">⦸</span>`
        : it.p ? `<img class="lc-thumb" loading="lazy" alt="" src="/api/lora-preview?name=${encodeURIComponent(it.v)}">`
        : `<span class="lc-thumb" aria-hidden="true" style="background:linear-gradient(135deg,hsl(${h} 70% 72%),hsl(${(h + 50) % 360} 65% 55%))">${esc(initials(it.t))}</span>`;
      b.innerHTML = `${thumb}<span class="lc-name">${esc(it.t)}</span>`;
      if (it.v && (state.models.loraInfo.find(l => l.name === it.v) || {}).featured) b.classList.add("featured");
      b.onclick = () => { setVal("lora", state.vals.lora === it.v ? "" : it.v); draw(); };
      g.appendChild(b);
    });
    state.vals.lora = (famLoras.find(l => l.featured) || famLoras[0]).name;
    s.appendChild(g); draw();
    if (has("lora_strength")) { s.insertAdjacentHTML("beforeend", '<p class="sub-label">風格強度</p>'); state.vals.lora_strength = 0.7; s.appendChild(chipGroup(STRENGTH, it => +state.vals.lora_strength === it.v, it => setVal("lora_strength", it.v), "風格強度")); }
    steps.appendChild(s);
  }
  // 調整：尺寸 / 品質 / 秒數 / 變化幅度
  {
    const s = stepBlock(n++, prof.video ? "比例與長度" : "畫面比例");
    const tune = $("tuning-chips"); tune.innerHTML = "";
    if (flow.icon === "i2v" && h3.pika) {
      if (state.vals.pika === undefined) state.vals.pika = true;
      s.insertAdjacentHTML("beforeend", '<p class="sub-label">影片引擎</p>');
      s.appendChild(chipGroup([{ t: "Pika Flex（人物更穩，建議）", v: true }, { t: "原版 H3", v: false }], it => !!state.vals.pika === it.v, it => { setVal("pika", it.v); syncVidQ(); updEst(); }, "影片引擎"));
      s.insertAdjacentHTML("beforeend", '<p class="sub-label">畫面比例</p>');
    } else if (flow.icon === "i2v") state.vals.pika = false;
    if (has("denoise")) {
      tune.insertAdjacentHTML("beforeend", '<p class="sub-label">要改多少</p>'); state.vals.denoise = 0.55;
      tune.appendChild(chipGroup(DENOISE, it => +state.vals.denoise === it.v, it => setVal("denoise", it.v), "變化幅度"));
    }
    if (has("width") && has("height")) {
      const sizes = prof.video ? VID_SIZES : IMG_SIZES;
      if (prof.video) { VID_SIZES.forEach((x, i) => { x.w = VID_RES.sd[i].w; x.h = VID_RES.sd[i].h; }); state.ratio = "pt"; state.clarity = state.clarity || DEFAULT_CLARITY; applyVidSize(); }
      else {
        const fs = (state.models.sizes || {})[fam];
        if (fs) IMG_SIZES.forEach(x => { if (fs[x.k]) { x.w = fs[x.k][0]; x.h = fs[x.k][1]; } });
        setVal("width", sizes[0].w); setVal("height", sizes[0].h);
      }
      updateCrop();
      sizes.forEach(x => { const r = x.w / x.h; x.html = `<span class="shape" style="width:${Math.round(14 * Math.min(1, r))}px;height:${Math.round(14 * Math.min(1, 1 / r))}px"></span>${x.t}`; });
      if (prof.video) {
        s.appendChild(chipGroup(sizes, it => state.ratio === it.k, it => { state.ratio = it.k; applyVidSize(); updateCrop(); updEst(); }, "畫面比例"));
        s.insertAdjacentHTML("beforeend", '<p class="sub-label">清晰度</p>');
        s.appendChild(chipGroup(CLARITY, it => state.clarity === it.k, it => { state.clarity = it.k; applyVidSize(); updEst(); }, "清晰度"));
      } else
      s.appendChild(chipGroup(sizes, it => +state.vals.width === it.w && +state.vals.height === it.h, it => { setVal("width", it.w); setVal("height", it.h); updateCrop(); updEst(); }, "畫面比例"));
      if (has("image") && flow.icon !== "ref2v") s.insertAdjacentHTML("beforeend", '<p class="hint">圖片比例不同時會自動置中裁切，上方預覽即為實際範圍。</p>');
    }
    if (has("steps") && !(mainM && mainM.kind === "photo")) {
      const q = prof.video ? VID_Q : IMG_Q;
      tune.insertAdjacentHTML("beforeend", '<p class="sub-label" id="vidq-label">品質</p>');
      if (prof.video) {
        const pick = (it) => { setVal("steps", it.steps); if (it.cfg && has("cfg")) setVal("cfg", it.cfg); updEst(); };
        pick(q[1]);
        const qg = chipGroup(q, it => +state.vals.steps === it.steps, pick, "品質"); qg.id = "vidq-chips";
        tune.appendChild(qg);
      } else if (fam === "sd15" && flow.icon !== "img2img") {
        state.vals.quality = state.vals.quality || "std";
        tune.appendChild(chipGroup(q, it => state.vals.quality === it.q, it => setVal("quality", it.q), "品質"));
      }
    }
    if (has("seconds") && !flow.tts) {
      const sp = f.seconds || {}; const max = sp.max || 8, min = sp.min || 1;
      s.insertAdjacentHTML("beforeend", `<p class="sub-label">影片長度（最長 ${max} 秒）</p>`);
      if (!state.vals.seconds) state.vals.seconds = 3;
      const out = document.createElement("output"); const range = document.createElement("input");
      const g = chipGroup(SECONDS.filter(x => x <= max).map(x => ({ t: x + " 秒", v: x })), it => +state.vals.seconds === it.v, it => { setVal("seconds", it.v); range.value = it.v; out.textContent = it.v + " 秒"; updEst(); }, "影片長度");
      s.appendChild(g);
      const sl = document.createElement("div"); sl.className = "slider";
      range.type = "range"; range.min = min; range.max = max; range.step = sp.step || 0.5; range.value = state.vals.seconds || 3; range.setAttribute("aria-label", "影片秒數");
      out.textContent = range.value + " 秒";
      range.oninput = () => { setVal("seconds", +range.value); out.textContent = range.value + " 秒"; g.redraw(); updEst(); };
      sl.append(range, out); s.appendChild(sl);
    }
    if (flow.av) {
      s.insertAdjacentHTML("beforeend", '<p class="sub-label">聲音（AI 依描述產生音效；描述裡用「」寫台詞會說話）</p>');
      if (state.vals.sound === undefined) state.vals.sound = true;
      s.appendChild(chipGroup([{ t: "聲音：開", v: true }, { t: "聲音：關", v: false }], it => state.vals.sound === it.v, it => setVal("sound", it.v), "聲音"));
      s.insertAdjacentHTML("beforeend", '<p class="sub-label">背景音樂</p>');
      const mi = document.createElement("input"); mi.type = "file"; mi.hidden = true; mi.accept = "audio/*,.mp3,.wav,.m4a,.flac,.ogg";
      const mopts = [{ t: "無", k: "none" }, { t: "上傳音樂", k: "up" }];
      const mg = chipGroup(mopts, it => (it.k === "up") === !!state.vals.music, it => { if (it.k === "none") { setVal("music", ""); mn.textContent = ""; } else mi.click(); }, "背景音樂");
      const mn = document.createElement("p"); mn.className = "hint";
      mi.onchange = async () => {
        const file = mi.files[0]; if (!file) return; mn.textContent = `上傳中：${file.name}…`;
        const fd = new FormData(); fd.append("image", file); fd.append("overwrite", "true");
        try { const r = await api("/api/upload", { method: "POST", body: fd }); setVal("music", r.subfolder ? `${r.subfolder}/${r.name}` : r.name); mn.textContent = `♪ ${file.name}（自動裁成影片長度，音量放低混入）`; }
        catch (e) { setVal("music", ""); mn.innerHTML = `<span class="err">音樂上傳失敗：${esc(e.message)}</span>`; }
        mg.redraw(); mi.value = "";
      };
      s.append(mg, mi, mn);
    }
    if (prof.video) { s.insertAdjacentHTML("beforeend", '<p class="hint" id="est-hint"></p>'); }
    if (s.children.length > 1) steps.appendChild(s);
    updEst();
  }
  syncVidQ();
  renderAdvancedFields();
  $("generate-btn").textContent = prof.video ? "開始生成影片" : "開始生成";
}

// ---------- Pika H3 Flex：品質開關、選填圖片、角色參考／故事板 ----------
function syncVidQ() {
  const on = !!state.vals.pika && state.current && state.current.icon === "i2v";
  ["vidq-label", "vidq-chips"].forEach(id => { const el = $(id); if (el) el.hidden = on; });
}
function optZone(field, opts) {
  const wrap = document.createElement("div"); wrap.className = "opt-zone";
  const put = () => {
    wrap.innerHTML = "";
    const z = dropZone("image", field, opts);
    const x = document.createElement("button"); x.type = "button"; x.className = "btn-clear"; x.textContent = "移除這張";
    x.onclick = () => { setVal(field, ""); put(); };
    wrap.append(z, x);
  };
  put(); return wrap;
}
const REF_ROLES = [{ k: "char", t: "另一個角色" }, { k: "scene", t: "場景" }, { k: "prop", t: "道具／物品" }];
function refMissing(h3) {
  const need = [];
  if (!h3.manual_sigmas || !h3.ref_node) need.push("更新 ComfyUI 到最新版");
  if (!h3.ref2va_unet) need.push("diffusion_models/minimax_h3_ref2va_pruned_int8_convrot.safetensors（約 19.5GB）");
  if (!h3.lora_ref2va) need.push("loras/pika_h3_flex_ref2va_v1_bf16.safetensors（約 2GB）");
  return `這台電腦還沒裝好角色參考模型：${need.join("、") || "請檢查模型"}。請老師依「安裝說明」下載後重新啟動 ComfyUI。`;
}
function refStep(num, h3) {
  const s = stepBlock(num, "放參考圖");
  const t = s.querySelector("h2"); t.childNodes[1].replaceWith(Object.assign(document.createElement("span"), { className: "t", textContent: "放參考圖" }));
  if (!h3.ref_ready) s.insertAdjacentHTML("beforeend", `<p class="err">${esc(refMissing(h3))}</p>`);
  const mode = chipGroup([{ t: "角色參考（換場景臉不跑掉）", v: "char" }, { t: "故事板長鏡頭（照分鏡自動換機位）", v: "board" }], it => state.refMode === it.v,
    it => { state.refMode = it.v; sync(); }, "參考方式");
  const lab1 = document.createElement("p"); lab1.className = "sub-label";
  const main = dropZone("image", "image", { crop: false });
  // 故事板：選 2–6 張圖，自動拼成一張
  const board = document.createElement("div"); board.className = "board-maker";
  const bi = document.createElement("input"); bi.type = "file"; bi.accept = "image/*"; bi.multiple = true; bi.hidden = true;
  const bb = document.createElement("button"); bb.type = "button"; bb.className = "btn-clear"; bb.textContent = "還沒有故事板？選 2–6 張分鏡圖自動拼成一張";
  const bh = document.createElement("p"); bh.className = "hint";
  bb.onclick = () => bi.click();
  bi.onchange = async () => {
    const files = [...bi.files].slice(0, 6); bi.value = "";
    if (files.length < 2) { bh.innerHTML = '<span class="err">至少要選 2 張圖。</span>'; return; }
    bh.textContent = "拼接中…";
    try { const f = await makeStoryboard(files); state.boardPanels = files.length; main.useFile(f); bh.textContent = `已拼成 ${files.length} 格故事板（照選取順序：由左到右、由上到下）。`; }
    catch (e) { bh.innerHTML = `<span class="err">拼接失敗：${esc(e.message)}</span>`; }
  };
  board.append(bb, bi, bh);
  const extra = document.createElement("details"); extra.className = "advanced";
  extra.innerHTML = "<summary>加更多參考（第二個角色、場景、道具，選填）</summary>";
  ["ref2", "ref3"].forEach((k, i) => {
    const row = document.createElement("div"); row.className = "ref-extra";
    row.insertAdjacentHTML("beforeend", `<p class="sub-label">參考圖 ${i + 2} 是…</p>`);
    row.appendChild(chipGroup(REF_ROLES, it => state.refRoles[k] === it.k, it => { state.refRoles[k] = it.k; }, `參考圖 ${i + 2} 的角色`));
    row.appendChild(optZone(k, { crop: false }));
    extra.appendChild(row);
  });
  const tip = document.createElement("p"); tip.className = "hint";
  const sync = () => {
    const b = state.refMode === "board";
    t.querySelector(".t").textContent = b ? "放故事板" : "放主角參考圖";
    lab1.textContent = b ? "故事板（一張圖裡有好幾格分鏡）" : "主角（臉清楚、正面或半身最好）";
    board.hidden = !b;
    tip.textContent = b ? "故事板的每一格會依序變成一個鏡頭；可以在「更多參考」放一張主角大圖，臉會更穩。建議 5–8 秒。"
      : "AI 會鎖定這個角色的五官、髮型和服裝，換場景、換動作都不跑掉。想指定地點，可以在「更多參考」放一張場景圖。";
  };
  s.append(mode, lab1, main, board, extra, tip); sync();
  return s;
}
async function makeStoryboard(files) {
  const n = files.length, cols = n <= 3 ? n : n === 4 ? 2 : 3, rows = Math.ceil(n / cols);
  const vw = +state.vals.width || 544, vh = +state.vals.height || 960, k = 512 / Math.max(vw, vh);
  const cw = Math.round(vw * k), ch = Math.round(vh * k), gap = 12;
  const cv = document.createElement("canvas"); cv.width = cols * cw + (cols + 1) * gap; cv.height = rows * ch + (rows + 1) * gap;
  const g = cv.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, cv.width, cv.height);
  for (let i = 0; i < n; i++) {
    const img = await createImageBitmap(files[i]);
    const x = gap + (i % cols) * (cw + gap), y = gap + Math.floor(i / cols) * (ch + gap);
    const sc = Math.max(cw / img.width, ch / img.height), sw = cw / sc, sh = ch / sc;
    g.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, cw, ch);
    g.fillStyle = "rgba(0,0,0,.65)"; g.beginPath(); g.arc(x + 20, y + 20, 14, 0, 7); g.fill();
    g.fillStyle = "#fff"; g.font = "bold 16px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(String(i + 1), x + 20, y + 21);
  }
  const blob = await new Promise(r => cv.toBlob(r, "image/png"));
  return new File([blob], `storyboard_${Date.now()}.png`, { type: "image/png" });
}
function buildRefPrompt(values) {
  const text = String(values.positive || "").trim(), lines = [];
  let pic = 1, subj = 1;
  if (state.refMode === "board") {
    lines.push(`<Picture 1> is a storyboard sheet with ${state.boardPanels || "several"} panels, read left to right, top to bottom. Generate one continuous video that plays the panels in order as consecutive shots, cutting between camera angles (wide, medium, close-up) to match each panel. The same characters appear in every panel; keep their faces, hairstyles and outfits identical in every shot. Do not show panel borders or panel numbers.`);
  } else {
    lines.push("subject_definitions:", "<Subject 1> is the main character in <Picture 1>. Keep the face, hairstyle, outfit and body shape exactly as in <Picture 1> in every frame, even when the scene, pose or camera angle changes.");
    subj = 2;
  }
  ["ref2", "ref3"].filter(k => values[k]).forEach(k => {
    pic++;
    const r = state.refRoles[k];
    if (r === "scene") lines.push(`<Picture ${pic}> is the location reference; the video takes place in this place.`);
    else if (r === "prop") lines.push(`<Subject ${subj++}> is the object in <Picture ${pic}>; keep its shape and colors exactly.`);
    else lines.push(state.refMode === "board" && pic === 2 ? `<Subject ${subj++}> is the character in <Picture ${pic}>; every figure in the storyboard who looks like this is the same person, keep the face, hair and outfit identical.` : `<Subject ${subj++}> is another character in <Picture ${pic}>; keep this character's look exactly.`);
  });
  lines.push("", `story: ${text}`);
  return lines.join("\n");
}

// ---------- 分段對嘴：多段音檔或長音檔自動切段，固定同一張角色圖 ----------
const fmtT = (t) => `${Math.floor(t / 60)}:${(t % 60).toFixed(1).padStart(4, "0")}`;
function splitAudio(buf, maxLen, minLen = 2) {
  const sr = buf.sampleRate, win = Math.round(sr * 0.02), n = Math.floor(buf.length / win), rms = new Float32Array(n);
  const chans = Array.from({ length: buf.numberOfChannels }, (_, c) => buf.getChannelData(c));
  for (let i = 0; i < n; i++) {
    let acc = 0;
    for (const ch of chans) for (let j = i * win; j < (i + 1) * win; j++) acc += ch[j] * ch[j];
    rms[i] = Math.sqrt(acc / (win * chans.length));
  }
  const total = buf.duration, out = [];
  let start = 0;
  while (total - start > maxLen) {
    const a = Math.ceil((start + minLen) / 0.02), b = Math.floor((start + maxLen - 0.05) / 0.02);
    let lo = Infinity; for (let i = a; i <= b && i < n; i++) lo = Math.min(lo, rms[i]);
    let cut = b; // 在最安靜的地方附近、盡量靠後切，段數最少
    for (let i = Math.min(b, n - 1); i >= a; i--) if (rms[i] <= lo * 1.5 + 0.002) { cut = i; break; }
    const t = (cut + 0.5) * 0.02;
    out.push({ start: +start.toFixed(3), dur: +(t - start).toFixed(3) }); start = t;
  }
  if (total - start >= 0.3) out.push({ start: +start.toFixed(3), dur: +(total - start).toFixed(3) });
  return out;
}
function segmentWidget(maxLen) {
  const box = document.createElement("div"); box.className = "segs";
  const input = document.createElement("input"); input.type = "file"; input.hidden = true; input.multiple = true; input.accept = "audio/*,.wav,.mp3,.m4a,.flac";
  const z = document.createElement("div"); z.className = "drop"; z.tabIndex = 0; z.setAttribute("role", "button"); z.setAttribute("aria-label", "上傳音檔");
  z.innerHTML = `<div class="ph" aria-hidden="true">♪</div><div><p><strong>拖曳音檔到這裡</strong>，或點一下選擇（可一次選好幾個）</p><p class="sub">超過 ${maxLen} 秒會在停頓處自動切段，每段都用同一張角色圖，最後接成一支影片。人聲越乾淨，嘴型越準。</p></div>`;
  const list = document.createElement("div"); list.className = "seg-list";
  const player = new Audio(); let stopAt = 0;
  player.ontimeupdate = () => { if (stopAt && player.currentTime >= stopAt) { player.pause(); stopAt = 0; } };
  const sync = () => {
    const segs = state.segs;
    setVal("audio", segs.length ? segs[0].audio : "");
    if (segs.length === 1) setVal("seconds", Math.min(maxLen, Math.max(1, segs[0].dur)));
    const tot = segs.reduce((a, x) => a + x.dur, 0);
    const est = segs.reduce((a, x) => a + vidEst({ ...state.vals, seconds: x.dur }, 15), 0);
    list.innerHTML = segs.length ? `<p class="hint">共 <strong>${segs.length}</strong> 段，總長 ${tot.toFixed(1)} 秒，預估約 ${Math.max(1, Math.round(est / 60))} 分鐘${segs.length > 1 ? "，完成後自動接成一支影片" : ""}。</p>` : "";
    segs.forEach((x, i) => {
      const row = document.createElement("div"); row.className = "seg-row";
      row.innerHTML = `<span class="seg-n">${i + 1}</span><span class="seg-name" title="${esc(x.name)}">${esc(x.name)}</span><span class="seg-t">${fmtT(x.start)}–${fmtT(x.start + x.dur)}（${x.dur.toFixed(1)} 秒）</span>`
        + `<button type="button" class="seg-b" data-k="play" aria-label="試聽第 ${i + 1} 段">▶</button><button type="button" class="seg-b" data-k="up" aria-label="往前移" ${i ? "" : "disabled"}>↑</button><button type="button" class="seg-b" data-k="down" aria-label="往後移" ${i < segs.length - 1 ? "" : "disabled"}>↓</button><button type="button" class="seg-b" data-k="del" aria-label="刪除第 ${i + 1} 段">✕</button>`;
      row.onclick = (e) => {
        const k = e.target.dataset && e.target.dataset.k; if (!k) return;
        if (k === "play") { player.src = x.url; player.currentTime = x.start; stopAt = x.start + x.dur; player.play(); return; }
        if (k === "up") [segs[i - 1], segs[i]] = [segs[i], segs[i - 1]];
        if (k === "down") [segs[i + 1], segs[i]] = [segs[i], segs[i + 1]];
        if (k === "del") segs.splice(i, 1);
        sync();
      };
      list.appendChild(row);
    });
    if (segs.length > 1) {
      list.insertAdjacentHTML("beforeend", '<p class="sub-label">段落銜接</p>');
      if (state.segTransition === undefined) state.segTransition = 4;
      list.appendChild(chipGroup([{ t: "淡入（建議）", v: 4 }, { t: "直接切換", v: 0 }], it => state.segTransition === it.v, it => { state.segTransition = it.v; }, "段落銜接"));
    }
  };
  const handle = async (files) => {
    files = [...files].filter(f => f && (/^audio\//.test(f.type) || /\.(wav|mp3|m4a|flac|ogg)$/i.test(f.name)));
    if (!files.length) return;
    const st = document.createElement("p"); st.className = "hint"; list.prepend(st);
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    for (const file of files) {
      st.textContent = `處理中：${file.name}…`;
      try {
        const buf = await ctx.decodeAudioData(await file.arrayBuffer());
        const fd = new FormData(); fd.append("image", file); fd.append("overwrite", "true");
        const r = await api("/api/upload", { method: "POST", body: fd });
        const name = r.subfolder ? `${r.subfolder}/${r.name}` : r.name, url = URL.createObjectURL(file);
        splitAudio(buf, maxLen).forEach(x => state.segs.push({ ...x, audio: name, name: file.name, url }));
      } catch (e) {
        st.innerHTML = `<span class="err">${esc(file.name)} 無法使用：${esc(e.message || "格式不支援")}</span>`; ctx.close(); return;
      }
    }
    ctx.close(); sync(); updEst();
  };
  z.onclick = () => input.click();
  z.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } };
  input.onchange = () => { handle(input.files); input.value = ""; };
  z.ondragover = (e) => { e.preventDefault(); z.classList.add("over"); };
  z.ondragleave = () => z.classList.remove("over");
  z.ondrop = (e) => { e.preventDefault(); z.classList.remove("over"); handle(e.dataTransfer.files); };
  box.append(z, input, list); sync();
  return box;
}

// ---------- 漫劇分鏡：同一個角色、同一個種子，每格一段影片，最後接成一支 ----------
const SHOT_TYPES = [{ k: "", t: "鏡頭：不指定", p: "" }, { k: "wide", t: "遠景", p: "遠景鏡頭，wide shot" }, { k: "mid", t: "中景", p: "中景鏡頭，medium shot" },
  { k: "close", t: "特寫", p: "臉部特寫，close-up shot" }, { k: "push", t: "推近", p: "鏡頭慢慢推近，slow push-in" }, { k: "pull", t: "拉遠", p: "鏡頭慢慢拉遠，slow pull-out" },
  { k: "pan", t: "橫移", p: "鏡頭水平橫移，slow pan" }, { k: "orbit", t: "環繞", p: "鏡頭環繞角色，orbit shot" }, { k: "static", t: "固定", p: "固定鏡頭，static camera" }];
const STORY_TEMPLATES = [
  { t: "三幕故事", shots: [["wide", "開場：角色出現在場景中，四處張望"], ["mid", "事件：角色發現了什麼，露出驚訝的表情"], ["close", "結尾：角色開心地笑了"]] },
  { t: "角色介紹", shots: [["wide", "角色慢慢走進畫面"], ["orbit", "角色轉身展示全身造型"], ["close", "角色看向鏡頭眨眼微笑"]] },
  { t: "情緒轉折", shots: [["mid", "角色低頭，看起來有點難過"], ["push", "角色抬起頭，眼睛亮了起來"], ["wide", "角色張開雙手，開心地轉圈"]] },
];
const STORY_MAX = 6, STORY_MIN = 2;
const newShot = (type = "", text = "") => ({ type, text, image: "", imageName: "", url: "" });
const shotPrompt = (st, shot) => [st.shared.trim(), (SHOT_TYPES.find(x => x.k === shot.type) || {}).p, shot.text.trim()].filter(Boolean).join("，");
function storyboardWidget() {
  const box = document.createElement("div"); box.className = "story"; box.hidden = true;
  const shared = document.createElement("input"); shared.type = "text"; shared.maxLength = 200; shared.className = "story-shared";
  shared.placeholder = "例如：紅圍巾的小狐狸，日系動畫風格，溫暖午後光線"; shared.setAttribute("aria-label", "每格共用的角色與畫風");
  shared.oninput = () => { if (state.story) state.story.shared = shared.value; };
  const tpl = chipGroup(STORY_TEMPLATES, () => false, it => { if (!state.story) return; if (state.story.shots.some(x => x.text.trim()) && !confirm(`套用「${it.t}」範本？目前寫的分鏡文字會被取代。`)) return;
    state.story.shots = it.shots.map(([k, t], i) => Object.assign(newShot(k, t), { image: (state.story.shots[i] || {}).image || "", imageName: (state.story.shots[i] || {}).imageName || "", url: (state.story.shots[i] || {}).url || "" })); draw(); }, "分鏡範本");
  const list = document.createElement("div"); list.className = "story-list";
  const foot = document.createElement("div");
  const add = document.createElement("button"); add.type = "button"; add.className = "btn-clear story-add"; add.textContent = "＋ 加一格";
  add.onclick = () => { if (state.story && state.story.shots.length < STORY_MAX) { state.story.shots.push(newShot()); draw(); list.lastElementChild.querySelector("textarea").focus(); } };
  const sum = document.createElement("p"); sum.className = "hint";
  const trans = chipGroup([{ t: "淡入（建議）", v: 4 }, { t: "直接切換", v: 0 }], it => (state.segTransition ?? 4) === it.v, it => { state.segTransition = it.v; }, "格與格銜接");
  foot.append(add, sum);
  const draw = () => {
    const st = state.story; list.innerHTML = ""; if (!st) return;
    shared.value = st.shared;
    st.shots.forEach((shot, i) => {
      const row = document.createElement("div"); row.className = "shot";
      const sel = document.createElement("select"); sel.setAttribute("aria-label", `第 ${i + 1} 格鏡頭`);
      sel.innerHTML = SHOT_TYPES.map(x => `<option value="${x.k}"${x.k === shot.type ? " selected" : ""}>${esc(x.t)}</option>`).join("");
      sel.onchange = () => { shot.type = sel.value; };
      const ta = document.createElement("textarea"); ta.maxLength = 400; ta.value = shot.text; ta.rows = 2;
      ta.placeholder = i === 0 ? "這一格發生什麼事？例如：小狐狸在雪地裡醒來，伸懶腰" : "接下來發生什麼事？"; ta.setAttribute("aria-label", `第 ${i + 1} 格內容`);
      ta.oninput = () => { shot.text = ta.value; };
      const pic = document.createElement("input"); pic.type = "file"; pic.accept = "image/*"; pic.hidden = true;
      const pb = document.createElement("button"); pb.type = "button"; pb.className = "shot-img";
      pb.innerHTML = shot.url ? `<img alt="" src="${shot.url}"><span>換圖</span>` : "<span>用上方角色圖</span><small>點一下換成這格專用的圖</small>";
      pb.title = shot.imageName || "預設使用上方的角色圖";
      pb.onclick = () => { if (shot.image && confirm("改回使用上方的角色圖？")) { Object.assign(shot, { image: "", imageName: "", url: "" }); draw(); return; } pic.click(); };
      pic.onchange = async () => {
        const file = pic.files[0]; if (!file) return; pb.innerHTML = "<span>上傳中…</span>";
        const fd = new FormData(); fd.append("image", file); fd.append("overwrite", "true");
        try { const r = await api("/api/upload", { method: "POST", body: fd }); Object.assign(shot, { image: r.subfolder ? `${r.subfolder}/${r.name}` : r.name, imageName: file.name, url: URL.createObjectURL(file) }); }
        catch (e) { alert(`圖片上傳失敗：${e.message}`); }
        draw();
      };
      const ctl = document.createElement("div"); ctl.className = "shot-ctl";
      ctl.innerHTML = `<button type="button" class="seg-b" data-k="up" aria-label="第 ${i + 1} 格往前移" ${i ? "" : "disabled"}>↑</button><button type="button" class="seg-b" data-k="down" aria-label="第 ${i + 1} 格往後移" ${i < st.shots.length - 1 ? "" : "disabled"}>↓</button><button type="button" class="seg-b" data-k="del" aria-label="刪除第 ${i + 1} 格" ${st.shots.length > STORY_MIN ? "" : "disabled"}>✕</button>`;
      ctl.onclick = (e) => {
        const k = e.target.dataset && e.target.dataset.k; if (!k || e.target.disabled) return;
        if (k === "up") [st.shots[i - 1], st.shots[i]] = [st.shots[i], st.shots[i - 1]];
        if (k === "down") [st.shots[i + 1], st.shots[i]] = [st.shots[i], st.shots[i + 1]];
        if (k === "del") st.shots.splice(i, 1);
        draw();
      };
      const head = document.createElement("div"); head.className = "shot-head";
      head.innerHTML = `<span class="seg-n">${i + 1}</span>`; head.append(sel, ctl);
      const body = document.createElement("div"); body.className = "shot-body"; body.append(ta, pb, pic);
      row.append(head, body); list.appendChild(row);
    });
    add.disabled = st.shots.length >= STORY_MAX;
    const est = st.shots.length * vidEst(state.vals, 0);
    sum.textContent = `共 ${st.shots.length} 格（最多 ${STORY_MAX} 格），每格 ${state.vals.seconds || 3} 秒，全部用同一個種子，完成後自動接成一支約 ${Math.round(st.shots.length * (+state.vals.seconds || 3))} 秒的影片。預估約 ${Math.max(1, Math.round(est / 60))} 分鐘。`;
  };
  box.innerHTML = '<p class="sub-label">角色與畫風（每格都會加上，讓角色保持一致）</p>';
  box.appendChild(shared);
  box.insertAdjacentHTML("beforeend", '<p class="sub-label">快速範本</p>'); box.appendChild(tpl);
  box.insertAdjacentHTML("beforeend", '<p class="sub-label">分鏡</p>'); box.append(list, foot);
  box.insertAdjacentHTML("beforeend", '<p class="sub-label">格與格銜接</p>'); box.appendChild(trans);
  box.insertAdjacentHTML("beforeend", '<p class="hint">小技巧：每格只寫一個動作效果最好。想讓角色換場景，可以先用「文生圖」畫好同一角色的不同場景圖，再放進各格。</p>');
  box.rebuild = draw; box.redrawSummary = draw;
  return box;
}

async function runSeries(flow, values, est, parts, title) {
  const segs = parts || state.segs.map(x => ({ v: { audio: x.audio, audio_start: x.start, audio_dur: x.dur }, dur: x.dur })), res = $("generate-result");
  const unit = title ? "格" : "段";
  const bar = $("progress"), fill = $("progress-fill"), lab = $("progress-label"), tm = $("progress-time");
  if (!state.canMerge) throw new Error("這台電腦無法合併影片：請用「啟動AURA.bat」開啟 AURA（會使用 ComfyUI 內建的 Python）。也可以一次只上傳一段。");
  if (!(+values.seed >= 0)) values.seed = Math.floor(Math.random() * 2 ** 31); // 每段同一個種子，角色更一致
  const jobs = [];
  for (let i = 0; i < segs.length; i++) {
    res.textContent = `送出第 ${i + 1}／${segs.length} ${unit}…`;
    let r;
    try { r = await api("/api/generate", { method: "POST", body: JSON.stringify({ flow: flow.filename, series_index: i, values: { ...values, ...segs[i].v } }) }); }
    catch (e) { for (const j of jobs) await api("/api/cancel", { method: "POST", body: JSON.stringify({ prompt_id: j.prompt_id }) }).catch(() => { }); throw new Error(`第 ${i + 1} ${unit}：${e.message}`); }
    jobs.push(r);
  }
  state.lastSeed = jobs[0].seed;
  if (jobs.some(j => !j.job_id)) throw new Error("作品庫無法記錄片段，請看 AURA 視窗的錯誤訊息");
  const { series_id } = await api("/api/series", { method: "POST", body: JSON.stringify({ job_ids: jobs.map(j => j.job_id), durs: segs.map(x => x.dur ?? null), transition: state.segTransition ?? 4, title: title || "" }) });
  res.textContent = `已送出 ${segs.length} ${unit}，全部完成後會自動接成一支影片。可以先離開，完成後會出現在作品庫。`;
  bar.hidden = false; fill.style.width = "2%";
  state.cancel = { series_id }; state.cancelled = false; $("cancel-btn").hidden = false;
  try {
  const t0 = Date.now(), per = est / segs.length;
  let lastDone = -1, segStart = Date.now();
  for (let i = 0; i < 7200; i++) {
    await sleep(3000);
    if (state.cancelled) throw new Error("已取消。已經完成的片段會留在作品庫。");
    let s; try { s = await api(`/api/series/${series_id}`); } catch { continue; }
    const el = Math.round((Date.now() - t0) / 1000);
    if (s.status === "error") throw new Error(s.error || "分段生成失敗");
    if (s.status === "done" && s.item) {
      fill.style.width = "100%"; lab.textContent = "完成"; tm.textContent = `用時 ${Math.round(el / 60)} 分鐘`;
      const j = s.item;
      j.outputs.forEach(o => addHistory({ ...o, id: j.id, flow: j.flow_name, seed: j.seed, text: j.text, values: j.values, flowFile: j.flow, mainModel: j.main_model, starred: j.starred, mine: j.mine, created: j.created }));
      res.textContent = `完成！${s.total} ${unit}已接成一支影片。`;
      setTimeout(() => { bar.hidden = true; }, 2500);
      return;
    }
    if (s.done !== lastDone) { lastDone = s.done; segStart = Date.now(); }
    if (s.status === "merging") { lab.textContent = "正在把各段接成一支影片…"; fill.style.width = "97%"; tm.textContent = `已用 ${Math.round(el / 60)} 分鐘`; continue; }
    const frac = Math.min(0.95, (Date.now() - segStart) / 1000 / per);
    fill.style.width = Math.min(96, 3 + ((s.done + frac) / s.total) * 93) + "%";
    lab.textContent = `第 ${Math.min(s.done + 1, s.total)}／${s.total} ${unit}生成中（已完成 ${s.done} ${unit}）`;
    tm.textContent = `已用 ${Math.round(el / 60)} 分鐘／預估約 ${Math.round(est / 60)} 分鐘`;
  }
  throw new Error("等待太久，請稍後到作品庫查看");
  } finally { $("cancel-btn").hidden = true; state.cancel = null; }
}

function updateCrop() {
  const w = +state.vals.width, h = +state.vals.height;
  document.querySelectorAll("img.crop-prev").forEach(i => { if (w && h) i.style.aspectRatio = `${w} / ${h}`; });
}
function updEst() {
  const el = $("est-hint"); if (!el || !state.current) return;
  const prof = PROFILES[state.current.icon]; if (!prof || !prof.est) return;
  const t = prof.est(state.vals) * (state.story && state.current.icon === "i2v" ? state.story.shots.length : 1);
  const sb = document.querySelector(".story"); if (sb && sb.redrawSummary && !sb.hidden) { const sum = sb.querySelector(".story-add + .hint"); if (sum) sum.textContent = sum.textContent.replace(/每格 [\d.]+ 秒/, `每格 ${state.vals.seconds || 3} 秒`).replace(/約 \d+ 秒的影片/, `約 ${Math.round(state.story.shots.length * (+state.vals.seconds || 3))} 秒的影片`).replace(/預估約 \d+ 分鐘/, `預估約 ${Math.max(1, Math.round(t / 60))} 分鐘`); }
  el.textContent = `預估生成時間：約 ${t < 90 ? Math.round(t) + " 秒" : Math.round(t / 60 * 2) / 2 + " 分鐘"}（第一次要載入模型，會再多 1–3 分鐘）`;
}

function renderAdvancedFields() {
  const flow = state.current, f = flow.fields || {}, m = flow.mapping || {};
  const box = $("advanced-fields"); box.innerHTML = "";
  box.hidden = !TEACHER; if (!TEACHER) return;
  const keys = [...new Set([...Object.keys(m), ...Object.keys(f)])].filter(k => !["image", "ref2", "ref3", "audio", "speech_text", "lora", "lora_strength", "denoise"].includes(k) && !(k === "positive" && !flow.tts));
  keys.forEach(k => {
    const spec = f[k] || {};
    const label = document.createElement("label");
    if (k === "negative" || k === "positive") label.className = "wide";
    label.append(spec.label || k);
    let el;
    if (k === "ckpt" || spec.type === "ckpt") {
      el = document.createElement("select");
      el.innerHTML = state.models.checkpoints.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join("");
    } else {
      el = document.createElement("input");
      el.type = ["int", "float", "seconds"].includes(spec.type) || k === "seed" ? "number" : "text";
      if (spec.step) el.step = spec.step;
      if (spec.min !== undefined) el.min = spec.min;
      if (spec.max !== undefined) el.max = spec.max;
    }
    el.dataset.adv = k;
    const v = state.vals[k];
    el.value = v === undefined ? "" : v;
    el.onchange = () => { state.vals[k] = el.value; };
    label.appendChild(el);
    box.appendChild(label);
  });
  box.insertAdjacentHTML("beforeend", '<p class="note wide">種子 -1 = 每次隨機。負向提示詞已預先填好。</p>');
}

// ---------- 生成 ----------
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

$("generate-btn").onclick = async () => {
  if (state.busy || !state.current) return;
  if (state.comfyWasDown) {
    const r = $("generate-result"); r.dataset.wait = "1";
    r.innerHTML = '<span class="err">ComfyUI 還在啟動中，等上方狀態變成「已連線」再按。</span>'; return;
  }
  const flow = state.current, m = flow.mapping || {}, f = flow.fields || {};
  const prof = PROFILES[flow.icon] || { est: () => 15 };
  const res = $("generate-result");
  const textKey = flow.tts ? "speech_text" : "positive";
  if (state.story && flow.icon === "i2v") return runStory(flow, m, f, prof, res);
  if (!(state.vals[textKey] || "").trim() && !(flow.tts && state.vals.audio)) {
    res.innerHTML = `<span class="err">${flow.tts ? "請輸入要說的台詞，或上傳音檔。" : "請先寫一句畫面描述。"}</span>`; $("main-text").focus(); return;
  }
  if ("image" in m && !state.vals.image) { res.innerHTML = '<span class="err">請先選一張圖片。</span>'; return; }
  const values = {};
  for (const k of new Set([...Object.keys(m), ...Object.keys(f), "voice_style", "quality", ...(flow.av ? ["sound", "music"] : [])])) {
    if (state.vals[k] !== undefined && state.vals[k] !== "") values[k] = state.vals[k];
  }
  if (flow.tts && values.audio) delete values.speech_text;
  if (flow.icon === "i2v" && state.vals.pika && (state.models.h3 || {}).pika) values.pika = 1;
  if (flow.icon === "i2v" && state.vals.last_image) values.last_image = state.vals.last_image;
  if (flow.icon === "ref2v") {
    const h3 = state.models.h3 || {};
    if (!h3.ref_ready) { res.innerHTML = `<span class="err">${esc(refMissing(h3))}</span>`; return; }
    values.positive = buildRefPrompt(values);
  }
  if (state.mainModel && "ckpt" in m) values.main_model = state.mainModel;
  if (TEACHER) values.teacher = 1;
  if (values.lora && values.positive) { // 課堂風格 LoRA：自動加上觸發詞
    const li = (state.models.loraInfo || []).find(l => l.name === values.lora);
    if (li && li.trigger && !values.positive.toLowerCase().includes(li.trigger.split(",")[0].trim().toLowerCase())) values.positive = `${li.trigger}, ${values.positive}`;
  }
  // SD1.5 主模型：自動在最前面補上品質詞（已經寫了就不重複）
  if (values.positive && "ckpt" in m && state.family === "sd15" && !/masterpiece|best quality/i.test(values.positive)) values.positive = `masterpiece, best quality, ${values.positive}`;
  if (flow.tts && !values.audio) delete values.seconds; // 由伺服器依語音長度決定
  if ("seed" in m) values.seed = $("lock-seed").checked && state.lastSeed != null ? state.lastSeed : (+state.vals.seed >= 0 ? +state.vals.seed : -1);
  if (flow.tts && !values.audio) state.vals.seconds = Math.min(8, Math.max(2, (values.speech_text || "").length / 4 + 0.5));
  state.busy = true; $("generate-btn").disabled = true;
  res.textContent = flow.tts && !values.audio ? "正在產生語音並送出…" : "送出中…";
  const segs = flow.tts && values.audio ? (state.segs || []) : [];
  if (segs.length === 1) { values.audio_start = segs[0].start; values.audio_dur = segs[0].dur; }
  if (segs.length > 1) {
    try { await runSeries(flow, values, segs.reduce((a, x) => a + prof.est({ ...state.vals, seconds: x.dur }), 0)); }
    catch (e) { if (/^已取消/.test(e.message)) res.textContent = e.message; else res.innerHTML = `<span class="err">無法完成：${esc(e.message)}</span>`; }
    finally { state.busy = false; $("generate-btn").disabled = !!state.comfyWasDown; }
    return;
  }
  try {
    const r = await api("/api/generate", { method: "POST", body: JSON.stringify({ flow: flow.filename, values }) });
    state.lastSeed = r.seed;
    if (r.tts && r.tts.seconds) state.vals.seconds = r.tts.seconds;
    res.textContent = r.tts ? `語音 ${r.tts.seconds ?? "?"} 秒，已送出（${r.frames ?? "?"} 格）。` : (r.frames ? `已送出（${r.frames} 格影片）。` : "已送出。");
    await track(r.prompt_id, prof.est(state.vals), flow, { id: r.job_id, text: (flow.icon === "ref2v" ? state.vals.positive : values[textKey]) || "", values, flowFile: flow.filename, mainModel: values.main_model || "", mine: true, created: Date.now() / 1000 });
  } catch (e) {
    if (/^已取消/.test(e.message)) res.textContent = e.message;
    else res.innerHTML = `<span class="err">無法生成：${esc(e.message)}</span>`;
  } finally {
    state.busy = false; $("generate-btn").disabled = !!state.comfyWasDown;
  }
};

async function runStory(flow, m, f, prof, res) {
  const st = state.story;
  const empty = st.shots.findIndex(x => !x.text.trim());
  if (empty >= 0) { res.innerHTML = `<span class="err">第 ${empty + 1} 格還沒寫內容。</span>`; const t = document.querySelectorAll(".shot textarea")[empty]; if (t) t.focus(); return; }
  if (!state.vals.image && st.shots.some(x => !x.image)) { res.innerHTML = '<span class="err">請先在上方選一張角色圖（或幫每一格都放一張圖）。</span>'; return; }
  if (!state.canMerge) { res.innerHTML = '<span class="err">這台電腦無法合併影片：請用「啟動AURA.bat」開啟 AURA（會使用 ComfyUI 內建的 Python）。</span>'; return; }
  const values = {};
  for (const k of new Set([...Object.keys(m), ...Object.keys(f), ...(flow.av ? ["sound", "music"] : [])])) if (state.vals[k] !== undefined && state.vals[k] !== "") values[k] = state.vals[k];
  if (TEACHER) values.teacher = 1;
  if (state.vals.pika && (state.models.h3 || {}).pika) values.pika = 1;
  values.seed = $("lock-seed").checked && state.lastSeed != null ? state.lastSeed : (+state.vals.seed >= 0 ? +state.vals.seed : -1);
  const parts = st.shots.map(x => ({ v: { positive: shotPrompt(st, x), image: x.image || state.vals.image }, dur: null }));
  const title = (st.shared.trim() || st.shots[0].text.trim()).replace(/[，,。].*$/, "").slice(0, 16) || "漫劇";
  state.busy = true; $("generate-btn").disabled = true; res.textContent = "送出中…";
  try { await runSeries(flow, values, parts.length * prof.est(state.vals), parts, `漫劇：${title}`); }
  catch (e) { if (/^已取消/.test(e.message)) res.textContent = e.message; else res.innerHTML = `<span class="err">無法完成：${esc(e.message)}</span>`; }
  finally { state.busy = false; $("generate-btn").disabled = !!state.comfyWasDown; }
}

async function track(pid, est, flow, job) {
  const bar = $("progress"), fill = $("progress-fill"), lab = $("progress-label"), tm = $("progress-time");
  bar.hidden = false; fill.style.width = "2%";
  state.cancel = { prompt_id: pid }; state.cancelled = false; $("cancel-btn").hidden = false;
  const t0 = Date.now(); let started = null, pct = 2;
  const setPct = (v) => { pct = Math.max(pct, Math.min(97, v)); fill.style.width = pct + "%"; };
  try {
    for (let i = 0; i < 1800; i++) {
      await sleep(i < 2 ? 800 : 1500);
      if (state.cancelled) throw new Error("已取消。");
      let h = null;
      try { h = (await api(`/api/history/${pid}`))[pid]; } catch (e) { /* 繼續等 */ }
      if (h) {
        const st = h.status || {};
        if (st.status_str === "error") throw new Error(h.aura_error || "ComfyUI 執行失敗");
        const items = collectOutputs(h.outputs || {});
        fill.style.width = "100%"; lab.textContent = "完成"; tm.textContent = `用時 ${Math.round((Date.now() - t0) / 1000)} 秒`;
        if (!items.length) { $("generate-result").textContent = "ComfyUI 已完成，但沒有回傳可預覽的作品。"; return; }
        if (state.scope === "starred") { state.scope = "mine"; drawScope(); await loadGallery(true); }
        items.forEach(it => addHistory({ ...it, ...job, flow: flow.name, seed: state.lastSeed }));
        $("generate-result").textContent = `完成！共 ${items.length} 件作品。`;
        setTimeout(() => { bar.hidden = true; }, 2500);
        return;
      }
      const s = await refreshStatus();
      const el = Math.round((Date.now() - t0) / 1000);
      if (s && s.pending && s.pending.includes(pid)) {
        const ahead = s.pending.indexOf(pid) + (s.running || []).length;
        lab.textContent = `排隊中，前面還有 ${ahead} 件`; tm.textContent = `已等 ${el} 秒`; setPct(3);
        continue;
      }
      if (!started) started = Date.now();
      const run = (Date.now() - started) / 1000;
      let p = null; try { p = await api(`/api/progress/${pid}`); } catch { }
      if (p && p.known && p.max > 0) { // ComfyUI 回報的真實步數
        setPct(5 + 88 * (p.value / p.max));
        lab.textContent = `生成中：第 ${p.value}／${p.max} 步`;
      } else if (p && p.known && p.done > 0 && pct > 50) {
        lab.textContent = prof_video(flow) ? "正在輸出影片…" : "正在輸出圖片…"; setPct(pct + 1);
      } else {
        setPct(4 + (run / est) * 91);
        lab.textContent = run < est ? "準備中（第一次會載入模型，比較久）" : "快好了，正在收尾…";
      }
      tm.textContent = `${Math.round(run)} 秒／預估約 ${Math.round(est)} 秒`;
    }
    throw new Error("等待太久，請到作品庫查看");
  } finally {
    $("cancel-btn").hidden = true; state.cancel = null;
  }
}
const prof_video = (flow) => !!(PROFILES[flow.icon] || {}).video;
$("cancel-btn").onclick = async () => {
  const c = state.cancel; if (!c) return;
  if (!confirm(c.series_id ? "取消這次的分段生成？已經完成的片段會留在作品庫。" : "取消這件作品？")) return;
  $("cancel-btn").disabled = true;
  try { await api("/api/cancel", { method: "POST", body: JSON.stringify(c) }); state.cancelled = true; $("progress-label").textContent = "已取消"; }
  catch (e) { $("generate-result").innerHTML = `<span class="err">取消失敗：${esc(e.message)}</span>`; }
  finally { $("cancel-btn").disabled = false; }
};

function viewUrl(item) {
  return `/api/view?filename=${encodeURIComponent(item.filename)}&subfolder=${encodeURIComponent(item.subfolder || "")}&type=${encodeURIComponent(item.type || "output")}`;
}
function collectOutputs(outputs) {
  const out = [];
  for (const id in outputs) for (const key of ["images", "gifs", "videos", "video", "audio"]) {
    const arr = outputs[id][key];
    if (Array.isArray(arr)) arr.forEach(it => { if (it && it.filename && it.type !== "temp") out.push(it); });
  }
  return out;
}
const kindOf = (fn) => { const e = (fn.split(".").pop() || "").toLowerCase(); return ["mp4", "webm", "mov", "mkv", "m4v"].includes(e) ? "video" : ["wav", "mp3", "flac", "ogg", "opus", "m4a"].includes(e) ? "audio" : "image"; };

function renderMedia(item) {
  const url = viewUrl(item), k = kindOf(item.filename);
  const own = item.id && item.mine;
  const acts = `${item.id ? `<button type="button" class="dl-float ghost" data-act="reuse" title="把這件作品的描述和設定帶回左邊">沿用描述</button>` : ""}`
    + `${own ? `<button type="button" class="dl-float ghost" data-act="star" aria-pressed="${!!item.starred}">${item.starred ? "★ 已收藏" : "☆ 收藏"}</button>` : ""}`
    + `${own ? `<button type="button" class="dl-float ghost" data-act="hide" title="從作品庫移除（檔案仍保留在作品資料夾）">移除</button>` : ""}`;
  const dl = `<span class="dl-float-wrap">${acts}${state.canOpen && (item.type || "output") === "output" ? `<button type="button" class="dl-float ghost" data-reveal="${esc(item.filename)}" data-sub="${esc(item.subfolder || "")}">在資料夾中顯示</button>` : ""}<a class="dl-float" href="${url}" download="${esc(item.filename)}">下載</a></span>`;
  const when = item.created ? new Date(item.created * 1000).toLocaleString("zh-TW", { month: "numeric", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "";
  const cap = (item.text || item.flow) ? `<p class="caption"><strong>${esc(item.flow || "")}</strong>${when ? ` · ${esc(when)}` : ""}${item.text ? `<br>${esc(item.text)}` : ""}</p>` : "";
  if (k === "video") return `<video src="${url}" controls loop autoplay playsinline></video>${dl}${cap}`;
  if (k === "audio") return `<audio src="${url}" controls></audio>${dl}${cap}`;
  return `<img src="${url}" alt="生成的作品">${dl}${cap}`;
}
function show(idx) {
  const it = state.history[idx]; if (!it) return;
  state.shown = idx;
  $("viewer").innerHTML = renderMedia(it);
  document.querySelectorAll(".thumb-btn").forEach(b => b.setAttribute("aria-current", String(+b.dataset.i === idx)));
}
function thumbFor(it, i) {
  const url = viewUrl(it), k = kindOf(it.filename);
  const b = document.createElement("button");
  b.type = "button"; b.className = "thumb-btn"; b.dataset.i = i; b.title = `${it.flow}${it.text ? "：" + it.text : ""}（種子 ${it.seed ?? "-"}）`;
  b.innerHTML = (k === "video" ? `<video src="${url}#t=0.1" muted preload="metadata"></video><span class="badge">影片</span>` : k === "audio" ? `<span class="badge">音訊</span>` : `<img src="${url}" alt="" loading="lazy">`)
    + (it.starred ? '<span class="star" aria-label="已收藏">★</span>' : "");
  b.onclick = () => show(i);
  return b;
}
function updateCount() {
  const n = state.history.filter(h => !h.removed).length;
  $("history-count").textContent = `${n}${state.galleryMore ? "+" : ""} 件`;
}
// 新完成的作品：放在最前面並直接顯示
function addHistory(it) {
  state.history.push(it);
  const i = state.history.length - 1;
  $("gallery-empty").hidden = true;
  $("preview-area").prepend(thumbFor(it, i));
  updateCount(); show(i);
}
// 從作品庫載入（舊的放在後面）
function appendHistory(it) {
  state.history.push(it);
  $("gallery-empty").hidden = true;
  $("preview-area").appendChild(thumbFor(it, state.history.length - 1));
}
async function loadGallery(reset) {
  if (reset) { state.history = []; state.galleryBefore = 0; $("preview-area").innerHTML = ""; }
  const q = new URLSearchParams({ scope: state.scope || "mine", limit: 40 });
  if (state.galleryBefore) q.set("before", state.galleryBefore);
  try {
    const d = await api(`/api/gallery?${q}`);
    d.items.forEach(j => {
      j.outputs.forEach(o => appendHistory({ ...o, id: j.id, flow: (j.flow_name || "").replace(/\s*\(.*\)\s*$/, ""), seed: j.seed, text: j.text, values: j.values, flowFile: j.flow, mainModel: j.main_model, starred: j.starred, mine: j.mine, created: j.created }));
      state.galleryBefore = j.id;
    });
    state.galleryMore = !!d.more;
  } catch (e) { console.warn("作品庫載入失敗", e); state.galleryMore = false; }
  $("gallery-more").hidden = !state.galleryMore;
  $("gallery-empty").hidden = state.history.length > 0;
  $("gallery-empty").textContent = state.scope === "starred" ? "還沒有收藏的作品，看到喜歡的按「☆ 收藏」。" : "還沒有作品，生成後會自動保存在這裡。";
  updateCount();
}
const SCOPES = [{ k: "mine", t: "我的作品" }, { k: "starred", t: "收藏" }, ...(TEACHER ? [{ k: "all", t: "全班" }] : [])];
function drawScope() { document.querySelectorAll("#gallery-scope .chip").forEach((b, i) => b.setAttribute("aria-pressed", String(SCOPES[i].k === (state.scope || "mine")))); }
{
  const g = chipGroup(SCOPES, it => it.k === (state.scope || "mine"), it => { if (state.scope !== it.k) { state.scope = it.k; loadGallery(true); } }, "作品範圍");
  g.id = "gallery-scope"; $("gallery-scope-slot").replaceWith(g);
  $("gallery-more").onclick = () => loadGallery(false);
}
async function galleryAction(act) {
  const it = state.history[state.shown]; if (!it || !it.id) return;
  if (act === "reuse") return reuseSettings(it);
  try {
    if (act === "star") {
      const v = !it.starred;
      await api("/api/gallery/update", { method: "POST", body: JSON.stringify({ id: it.id, starred: v }) });
      state.history.forEach(h => { if (h.id === it.id) h.starred = v; });
      document.querySelectorAll(".thumb-btn").forEach(b => { const h = state.history[+b.dataset.i]; if (h.id === it.id) b.replaceWith(thumbFor(h, +b.dataset.i)); });
      show(state.shown);
    } else if (act === "hide") {
      if (!confirm("從作品庫移除這件作品？（檔案仍會留在電腦的作品資料夾）")) return;
      await api("/api/gallery/update", { method: "POST", body: JSON.stringify({ id: it.id, hidden: true }) });
      state.history.forEach((h, i) => { if (h.id === it.id) { h.removed = true; const b = document.querySelector(`.thumb-btn[data-i="${i}"]`); if (b) b.remove(); } });
      $("viewer").innerHTML = ""; $("viewer").appendChild(viewerEmpty);
      $("gallery-empty").hidden = state.history.some(h => !h.removed);
      updateCount();
    }
  } catch (e) { $("generate-result").innerHTML = `<span class="err">${esc(e.message)}</span>`; }
}
const viewerEmpty = $("viewer-empty");
async function reuseSettings(it) {
  if (!it.flowFile || !state.flows.find(f => f.filename === it.flowFile && f.has_mapping)) {
    $("generate-result").innerHTML = '<span class="err">這件作品用的創作方式已經不在了。</span>'; return;
  }
  if (it.mainModel && (state.models.main || []).find(x => x.id === it.mainModel)) state.mainModel = it.mainModel;
  await selectFlow(it.flowFile);
  const v = it.values || {}, textKey = state.current.tts ? "speech_text" : "positive";
  const ta = $("main-text");
  if (ta && v[textKey]) { ta.value = v[textKey]; state.vals[textKey] = v[textKey]; }
  if (v.lora !== undefined && "lora" in (state.current.mapping || {})) {
    setVal("lora", v.lora);
    document.querySelectorAll(".lora-card[data-v]").forEach(c => c.setAttribute("aria-pressed", String(c.dataset.v === (v.lora || ""))));
  }
  if (it.seed != null) { state.lastSeed = it.seed; }
  $("generate-result").textContent = it.seed != null ? "已帶回描述。勾選「鎖定風格」可沿用同一個種子，做出很接近的作品。" : "已帶回描述。";
  if (ta) { ta.focus(); ta.scrollIntoView({ block: "center", behavior: "smooth" }); }
}

async function loadModels() {
  try {
    const data = await api("/api/models");
    state.models.checkpoints = data.models?.checkpoints || [];
    state.models.loras = data.models?.loras || [];
    state.models.main = data.models?.main_models || [];
    state.models.mainDefault = data.models?.main_default || "dreamshaper_8.safetensors";
    state.models.sizes = data.models?.sizes || {};
    state.models.h3 = data.models?.h3 || {};
    state.models.loraInfo = data.models?.lora_info || state.models.loras.map(n => ({ name: n, label: prettyName(n.split(/[\\/]/).pop()), preview: false }));
  } catch (e) {
    console.warn("模型載入失敗", e);
  }
}

// ---------- 進階：匯入 / 編輯對應 ----------
function renderAdvancedList() {
  const list = $("flows-list");
  list.innerHTML = "";
  if (!state.flows.length) { list.innerHTML = "<p class='note'>flows/ 內沒有工作流。</p>"; return; }
  state.flows.forEach(f => {
    const div = document.createElement("div");
    div.className = "flow-item";
    div.innerHTML = `<strong>${esc(f.name)}</strong> · <code>${esc(f.filename)}</code> · 節點數 ${f.nodes ?? "?"} · ${f.has_mapping ? "已對應" : "<span class='err'>未對應</span>"}`;
    div.onclick = () => loadFlowForMapping(f.filename);
    list.appendChild(div);
  });
}

async function loadFlowForMapping(filename) {
  try {
    const flow = await api(`/api/flows/${encodeURIComponent(filename)}`);
    const container = $("mapping-fields");
    container.innerHTML = "";
    const mapping = flow.mapping || {};
    const keys = [...new Set(["positive", "negative", "ckpt", "seed", "steps", "cfg", "width", "height", "lora", "lora_strength", "image", "denoise", ...Object.keys(mapping)])];
    keys.forEach(field => {
      const v = Array.isArray(mapping[field]) ? mapping[field].join(", ") : (mapping[field] || "");
      const div = document.createElement("div");
      div.innerHTML = `<label>${esc(field)}<input type="text" data-field="${esc(field)}" value="${esc(v)}" placeholder="例: 6.inputs.text（多處用逗號分隔）"></label>`;
      container.appendChild(div);
    });
    $("mapping-area").dataset.filename = filename;
    $("mapping-flow-name").textContent = flow.name || filename;
    $("mapping-area").style.display = "";
  } catch (e) {
    alert("載入工作流失敗: " + e.message);
  }
}

$("save-mapping").onclick = async () => {
  const filename = $("mapping-area").dataset.filename;
  if (!filename) return;
  const mapping = {};
  document.querySelectorAll("#mapping-fields input").forEach(inp => {
    const parts = inp.value.split(",").map(s => s.trim()).filter(Boolean);
    if (parts.length) mapping[inp.dataset.field] = parts.length === 1 ? parts[0] : parts;
  });
  try {
    const flow = await api(`/api/flows/${encodeURIComponent(filename)}`);
    await api("/api/flows", {
      method: "POST",
      body: JSON.stringify({ name: filename.replace(/\.json$/i, ""), prompt: flow.prompt, title: flow.name, order: flow.order, preset: flow.preset, mapping, fields: flow.fields || {}, description: flow.description || "" })
    });
    alert("對應已儲存");
    loadFlows(true);
  } catch (e) {
    alert("儲存失敗: " + e.message);
  }
};

$("import-btn").onclick = async () => {
  const file = $("flow-file").files[0];
  if (!file) return alert("請選擇 JSON 檔");
  let data;
  try { data = JSON.parse(await file.text()); } catch { return alert("不是有效的 JSON"); }
  const prompt = data.prompt || data;
  const name = data.name || file.name.replace(/\.json$/i, "");
  try {
    await api("/api/flows", { method: "POST", body: JSON.stringify({ name, prompt, mapping: data.mapping || {}, fields: data.fields || {} }) });
    alert(data.mapping ? "匯入成功" : "匯入成功，請在下方點選該工作流完成欄位對應");
    loadFlows(true);
  } catch (e) {
    alert("匯入失敗: " + e.message);
  }
};

// ---------- 硬體檢查：不適合時跳出提醒 ----------
const HW_LV = { ok: "✔ 可以", slow: "△ 可以但較慢", no: "✘ 不建議", unknown: "？ 無法判斷" };
async function checkHardware(force, refresh) {
  let r;
  try { r = await api("/api/hardware" + (refresh ? "?refresh=1" : "")); } catch { return; }
  const sig = [r.gpu?.name, r.vram_gb, r.ram_gb].join("|");
  let muted = false; try { muted = localStorage.getItem("aura_hw_mute") === sig; } catch { }
  if (!force && (r.overall === "ok" || muted || !r.local_client)) return;  // 區網學生的電腦不跑 AI，不用提醒
  const g = r.gpu;
  const head = $("hw-head");
  head.className = "hw-head " + (r.overall === "ok" ? "ok" : "no");
  head.textContent = r.overall === "ok" ? "這台電腦可以使用全部功能。" : r.overall === "no" ? "這台電腦可能無法執行 AI 生成功能。" : "這台電腦只適合使用部分功能，請看下面的說明。";
  $("hw-specs").innerHTML = [
    "作業系統：" + esc(r.os),
    "顯示卡：" + (g ? esc(g.name) + (g.vram_gb ? `（${g.vram_gb}GB）` : "") : "未偵測到"),
    "系統記憶體：" + (r.ram_gb ? r.ram_gb + "GB" : "讀不到"),
    "硬碟剩餘：" + (r.disk ? `${r.disk.free_gb}GB（${esc(r.disk.path)}）` : "讀不到"),
  ].map(t => `<li>${t}</li>`).join("");
  $("hw-feats").innerHTML = r.features.map(f => `<li class="${f.level}"><span class="lv">${HW_LV[f.level]}</span>${esc(f.name)}${f.reasons.length ? `<small>${esc(f.reasons.join("；"))}</small>` : ""}</li>`).join("");
  $("hw-tips").innerHTML = r.overall === "ok" ? "" : "硬體不夠時可以：<ul>" + r.tips.map(t => `<li>${esc(t)}</li>`).join("") + "</ul>";
  $("hw-mute").checked = muted;
  $("hw-mute").onchange = () => { try { $("hw-mute").checked ? localStorage.setItem("aura_hw_mute", sig) : localStorage.removeItem("aura_hw_mute"); } catch { } };
  const d = $("hw-dialog");
  if (!d.open) { d.showModal ? d.showModal() : d.setAttribute("open", ""); }
}
$("hw-close").onclick = () => { const d = $("hw-dialog"); d.close ? d.close() : d.removeAttribute("open"); };
$("hw-recheck").onclick = () => checkHardware(true, true);
$("hw-open").onclick = () => checkHardware(true);

// ---------- 初始化 ----------
(async () => {
  refreshStatus();
  checkHardware(false);
  await loadModels();
  await loadFlows();
  loadGallery(true);
  // ComfyUI 未連線時每 3 秒檢查一次（等待自動啟動），連線後每 15 秒
  const tick = async () => { if (!state.busy) await refreshStatus(); setTimeout(tick, state.comfyWasDown ? 3000 : 15000); };
  setTimeout(tick, 3000);
})();

async function openOutput(filename, subfolder) {
  try {
    await api("/api/open-output", { method: "POST", headers: { "Content-Type": "application/json", "X-Aura-Action": "open-output" }, body: JSON.stringify(filename ? { filename, subfolder } : {}) });
  } catch (e) { alert(e.message); }
}
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-reveal]"); if (b) { openOutput(b.dataset.reveal, b.dataset.sub); return; }
  const a = e.target.closest("[data-act]"); if (a) { galleryAction(a.dataset.act); return; }
  if (e.target.closest("#open-output")) openOutput();
});

// 老師模式：伺服器設了老師密碼（config/teacher.json）時，要先輸入密碼
async function teacherLogin() {
  const pin = prompt("請輸入老師密碼"); if (pin === null) return false;
  try { await api("/api/teacher", { method: "POST", body: JSON.stringify({ pin }) }); return true; }
  catch (e) { alert(e.message); return false; }
}
const reloadClean = () => location.replace(location.pathname + location.hash);
(async () => {
  const tm = document.getElementById("teacher-mode"); if (!tm) return;
  let info = { pin_required: false, is_teacher: false };
  try { info = await api("/api/teacher"); } catch { }
  if (TEACHER && info.pin_required && !info.is_teacher) {
    const ok = await teacherLogin();
    localStorage.setItem("aura_teacher", ok ? "1" : "0");
    if (!ok || new URLSearchParams(location.search).has("teacher")) return reloadClean();
    return location.reload();
  }
  tm.checked = TEACHER;
  tm.onchange = async () => {
    if (tm.checked && info.pin_required && !(await teacherLogin())) { tm.checked = false; return; }
    if (!tm.checked && info.pin_required) { try { await api("/api/teacher", { method: "POST", body: JSON.stringify({ logout: true }) }); } catch { } }
    localStorage.setItem("aura_teacher", tm.checked ? "1" : "0");
    reloadClean();
  };
})();

// ---------- 大圖檢視：點作品放大，←→ 切換，Esc 關閉 ----------
function visibleIdx() { return [...document.querySelectorAll("#preview-area .thumb-btn")].map(b => +b.dataset.i); }
function galleryStep(dir) {
  const order = visibleIdx(); if (!order.length) return;
  const k = order.indexOf(state.shown);
  const next = order[Math.max(0, Math.min(order.length - 1, (k < 0 ? 0 : k + dir)))];
  if (next !== undefined && next !== state.shown) { show(next); if (lightbox.open) openLightbox(); }
}
const lightbox = (() => {
  const el = document.createElement("div"); el.className = "lightbox"; el.hidden = true;
  el.setAttribute("role", "dialog"); el.setAttribute("aria-modal", "true"); el.setAttribute("aria-label", "作品大圖");
  el.innerHTML = '<button type="button" class="lb-close" aria-label="關閉">✕</button><button type="button" class="lb-nav lb-prev" aria-label="上一件">‹</button><div class="lb-body"></div><button type="button" class="lb-nav lb-next" aria-label="下一件">›</button><p class="lb-cap"></p>';
  document.body.appendChild(el);
  el.onclick = (e) => {
    if (e.target.closest(".lb-close") || e.target === el) closeLightbox();
    else if (e.target.closest(".lb-prev")) galleryStep(-1);
    else if (e.target.closest(".lb-next")) galleryStep(1);
  };
  return { el, open: false };
})();
function openLightbox() {
  const it = state.history[state.shown]; if (!it) return;
  const url = viewUrl(it), k = kindOf(it.filename);
  lightbox.el.querySelector(".lb-body").innerHTML = k === "video" ? `<video src="${url}" controls autoplay loop playsinline></video>` : k === "audio" ? `<audio src="${url}" controls autoplay></audio>` : `<img src="${url}" alt="作品大圖">`;
  lightbox.el.querySelector(".lb-cap").textContent = [it.flow, it.text].filter(Boolean).join("：");
  lightbox.el.hidden = false; lightbox.open = true; document.body.style.overflow = "hidden";
  lightbox.el.querySelector(".lb-close").focus();
}
function closeLightbox() {
  lightbox.el.hidden = true; lightbox.open = false; document.body.style.overflow = "";
  lightbox.el.querySelector(".lb-body").innerHTML = "";
}
$("viewer").addEventListener("click", (e) => { if (e.target.matches("#viewer > img")) openLightbox(); });
document.addEventListener("keydown", (e) => {
  if (/^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || "")) || e.isComposing) return;
  if (e.key === "Escape" && lightbox.open) { closeLightbox(); return; }
  if (e.key === "ArrowLeft") galleryStep(-1); else if (e.key === "ArrowRight") galleryStep(1);
  else if (e.key === "Enter" && !lightbox.open && e.target === document.body && state.shown != null) openLightbox();
});
