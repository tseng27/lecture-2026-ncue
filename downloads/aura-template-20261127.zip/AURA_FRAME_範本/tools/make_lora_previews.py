# -*- coding: utf-8 -*-
"""老師工具：為每個「會顯示」的 LoRA 產生 512x512 預覽圖，存到 AURA 的 previews/。
用法（ComfyUI 開著時）：  python tools\\make_lora_previews.py   [--force] [--ckpt dreamshaper_8.safetensors]
只連本機 ComfyUI（127.0.0.1:8188），不下載任何模型。"""
import argparse, copy, json, sys, time, urllib.parse, urllib.request, uuid
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))
import server  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--comfy", default="http://127.0.0.1:8188")
ap.add_argument("--ckpt", default=None)
ap.add_argument("--force", action="store_true")
ap.add_argument("--loras-dir", default=None)
a = ap.parse_args()
C = a.comfy.rstrip("/")


def get(p):
    return json.loads(urllib.request.urlopen(C + p, timeout=60).read())


server.OUTPUT_DIR = server.detect_output_dir()
if a.loras_dir:
    server.LORAS_DIR = Path(a.loras_dir)
elif server.OUTPUT_DIR:
    server.LORAS_DIR = server.OUTPUT_DIR.parent / "models" / "loras"
info = get("/object_info/LoraLoader")["LoraLoader"]["input"]["required"]["lora_name"][0]
ckpts = get("/object_info/CheckpointLoaderSimple")["CheckpointLoaderSimple"]["input"]["required"]["ckpt_name"][0]
ckpt = a.ckpt or next((c for c in ckpts if "dreamshaper" in c.lower()), None) or ckpts[0]
flow = json.loads((BASE / "flows" / "文生圖_LoRA.json").read_text(encoding="utf-8"))["prompt"]
out = BASE / "previews"
out.mkdir(exist_ok=True)
vis = [x for x in server.filter_loras(info) if x.get("family") in ("sd15", "unknown") and not x.get("preview")]  # 其他家族/已有預覽圖的略過
print(f"checkpoint: {ckpt}，要處理 {len(vis)} 個 LoRA")
for it in vis:
    stem = it["name"].replace("\\", "/").split("/")[-1].rsplit(".", 1)[0]
    dst = out / f"{stem}.png"
    if dst.exists() and not a.force:
        print("略過（已有）", stem); continue
    w = copy.deepcopy(flow)
    w["4"]["inputs"]["ckpt_name"] = ckpt
    w["10"]["inputs"].update(lora_name=it["name"], strength_model=0.8, strength_clip=0.8)
    w["6"]["inputs"]["text"] = "masterpiece, best quality, a single character, upper body, facing viewer, soft studio light, clean simple background"
    w["7"]["inputs"]["text"] = "lowres, blurry, bad anatomy, text, watermark, nsfw"
    w["5"]["inputs"].update(width=512, height=512)
    w["3"]["inputs"].update(seed=20261028, steps=20, cfg=7)
    w["9"]["inputs"]["filename_prefix"] = "AuraLoraPreview"
    pid = json.loads(urllib.request.urlopen(urllib.request.Request(C + "/prompt", json.dumps({"prompt": w, "client_id": uuid.uuid4().hex}).encode(), {"Content-Type": "application/json"})).read())["prompt_id"]
    t0 = time.time()
    while True:
        h = get(f"/history/{pid}")
        if pid in h and h[pid].get("outputs"):
            img = h[pid]["outputs"]["9"]["images"][0]
            q = urllib.parse.urlencode({"filename": img["filename"], "subfolder": img.get("subfolder", ""), "type": img.get("type", "output")})
            dst.write_bytes(urllib.request.urlopen(f"{C}/view?{q}").read())
            print(f"完成 {stem}（{time.time() - t0:.0f} 秒）")
            break
        if pid in h and h[pid].get("status", {}).get("status_str") == "error":
            print("失敗", stem); break
        if time.time() - t0 > 600:
            print("逾時", stem); break
        time.sleep(2)
print("DONE")
