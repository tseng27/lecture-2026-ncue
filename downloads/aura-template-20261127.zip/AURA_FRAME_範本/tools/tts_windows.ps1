param([string]$Ssml, [string]$Out, [string]$Voice = "Zhiwei")
$x = Get-Content -Raw -Encoding UTF8 $Ssml
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
  [Windows.Media.SpeechSynthesis.SpeechSynthesizer, Windows.Media.SpeechSynthesis, ContentType = WindowsRuntime] | Out-Null
  $s = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer
  $v = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices | Where-Object { $_.DisplayName -match $Voice } | Select-Object -First 1
  if ($v) { $s.Voice = $v }
  "voice: " + $s.Voice.DisplayName
  $task = $asTask.MakeGenericMethod([Windows.Media.SpeechSynthesis.SpeechSynthesisStream]).Invoke($null, @($s.SynthesizeSsmlToStreamAsync($x)))
  $task.Wait(-1) | Out-Null
  $rs = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($task.Result)
  $fs = [System.IO.File]::Create($Out); $rs.CopyTo($fs); $fs.Close()
} catch {
  "WinRT failed: $_ ; fallback SAPI"
  Add-Type -AssemblyName System.Speech
  $s2 = New-Object System.Speech.Synthesis.SpeechSynthesizer
  $s2.SetOutputToWaveFile($Out); $s2.SpeakSsml($x); $s2.Dispose()
}
"tts bytes: " + (Get-Item $Out).Length
