@echo off
chcp 65001 >nul
title AURA FRAME Local
cd /d "%~dp0"
echo ========================================
echo   AURA FRAME Local - 本機工作室
echo ========================================
echo 會自動尋找並啟動本機 ComfyUI（已開著就直接連線）
echo 瀏覽器會自動開啟 http://127.0.0.1:8000
echo 關閉本視窗或按 Ctrl+C 可停止。
echo.

rem ---- 找 Python：優先用 ComfyUI 免安裝版內建的 python_embeded ----
set "PY="
set "CP="
if exist "config\comfy_path.txt" (
  for /f "usebackq eol=# delims=" %%L in ("config\comfy_path.txt") do if not defined CP set "CP=%%~L"
)
if defined CP (
  if exist "%CP%\python_embeded\python.exe" set "PY=%CP%\python_embeded\python.exe"
  if not defined PY if exist "%CP%\..\python_embeded\python.exe" set "PY=%CP%\..\python_embeded\python.exe"
)
if not defined PY for /d %%F in ("%~dp0..\ComfyUI*") do if not defined PY if exist "%%F\python_embeded\python.exe" set "PY=%%F\python_embeded\python.exe"
if not defined PY for %%D in (C D E F G H) do (
  if not defined PY for /d %%F in ("%%D:\ComfyUI*" "%%D:\AI\ComfyUI*") do if not defined PY if exist "%%F\python_embeded\python.exe" set "PY=%%F\python_embeded\python.exe"
)
if not defined PY for /d %%F in ("%USERPROFILE%\ComfyUI*" "%USERPROFILE%\Desktop\ComfyUI*" "%USERPROFILE%\Documents\ComfyUI*" "%USERPROFILE%\Downloads\ComfyUI*") do if not defined PY if exist "%%F\python_embeded\python.exe" set "PY=%%F\python_embeded\python.exe"

rem ---- 退而求其次：系統安裝的 Python ----
if not defined PY (
  where py >nul 2>nul && set "PY=py" && set "PYARG=-3"
)
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo 找不到 Python。請安裝 ComfyUI 免安裝版，或到 https://www.python.org 安裝 Python 3（勾選 Add Python to PATH）。
  pause
  exit /b 1
)

echo 使用 Python：%PY% %PYARG%
"%PY%" %PYARG% server.py --open %*
if errorlevel 1 pause
