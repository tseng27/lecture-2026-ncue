@echo off
chcp 65001 >nul
rem 在桌面建立「AURA FRAME」捷徑，指向本資料夾的 啟動AURA.bat（圖示：static\aura.ico；重新執行會更新舊捷徑的圖示）
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut((Join-Path $d 'AURA FRAME.lnk')); $s.TargetPath=(Get-ChildItem -Filter '*AURA.bat' | Select-Object -First 1).FullName; $s.WorkingDirectory=(Get-Location).Path; $i=Join-Path (Get-Location).Path 'static\aura.ico'; if (Test-Path $i) { $s.IconLocation=$i+',0' }; $s.Description='AURA FRAME'; $s.Save()"
if errorlevel 1 (echo 建立捷徑失敗) else (echo 已在桌面建立「AURA FRAME」捷徑)
pause
