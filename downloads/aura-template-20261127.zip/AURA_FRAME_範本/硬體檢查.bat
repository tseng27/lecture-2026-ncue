@echo off
chcp 65001 >nul
title AURA FRAME 硬體檢查
cd /d "%~dp0"
echo 正在檢查這台電腦能不能自己架設 AURA FRAME（顯示卡、記憶體、硬碟）...
echo.
set "PY="
for /d %%F in ("%~dp0..\ComfyUI*") do if not defined PY if exist "%%F\python_embeded\python.exe" set "PY=%%F\python_embeded\python.exe"
for %%D in (C D E F G H) do (
  if not defined PY for /d %%F in ("%%D:\ComfyUI*" "%%D:\AI\ComfyUI*") do if not defined PY if exist "%%F\python_embeded\python.exe" set "PY=%%F\python_embeded\python.exe"
)
if not defined PY ( where py >nul 2>nul && set "PY=py -3" )
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if defined PY (
  %PY% aura_hw.py
  %PY% aura_hw.py --popup
) else (
  echo 這台電腦還沒有 Python，改用簡易檢查：
  powershell -NoProfile -Command "Get-CimInstance Win32_VideoController | Select-Object Name; \"系統記憶體(GB): \" + [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB,1)"
  where nvidia-smi >nul 2>nul && nvidia-smi --query-gpu=name,memory.total --format=csv
  echo.
  echo 影片與對嘴功能需要 NVIDIA 顯示卡 16GB 以上 VRAM、記憶體 32GB 以上；圖片功能約 6GB VRAM。
)
echo.
pause
